AdvancedFilters_Settings =
{
    ["NA Megaserver"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["Settings"] = 
                {
                    ["debugSpamExcludeDropdownBoxFilters"] = true,
                    ["showDropdownSelectedReminderAnimation"] = true,
                    ["debugSpamExcludeRefreshSubfilterBar"] = true,
                    ["subfilterBarDropdownLastSelectedEntries"] = 
                    {
                    },
                    ["grayOutSubFiltersWithNoItems"] = true,
                    ["doDebugOutput"] = false,
                    ["showIconsInFilterDropdowns"] = true,
                    ["rememberFilterDropdownsLastSelection"] = true,
                    ["hideItemCount"] = false,
                    ["hideCharBoundAtBankDeposit"] = false,
                    ["debugSpam"] = false,
                    ["version"] = 1.5110000000,
                    ["showDropdownLastSelectedEntries"] = true,
                    ["hideSubFilterLabel"] = false,
                    ["itemCountLabelColor"] = 
                    {
                        ["b"] = 1,
                        ["a"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["showFilterDropdownMenuOnRightMouseAtSubFilterButton"] = false,
                },
            },
        },
    },
}
