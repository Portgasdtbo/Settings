ZO_Pregame_SavedVariables =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["ChapterUpgrade"] = 
                {
                    ["version"] = 1,
                    ["chapterUpgradeSeenVersion"] = 7,
                },
                ["CharacterSelect_Manager"] = 
                {
                    ["version"] = 1,
                    ["eventBannerLastSeenTimestamp"] = 0,
                },
            },
        },
    },
}
