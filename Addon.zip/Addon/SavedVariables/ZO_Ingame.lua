ZO_Ingame_SavedVariables =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["Bujin Yamato"] = 
            {
                ["Dyeing"] = 
                {
                    ["sortStyle"] = 1,
                    ["showLocked"] = true,
                    ["version"] = 1,
                },
                ["SmithingExtraction"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["TradingHouseSearchHistory"] = 
                {
                    ["nextSearchOrderId"] = 0,
                    ["searchEntries"] = 
                    {
                    },
                    ["version"] = 2,
                },
                ["SmithingCreation"] = 
                {
                    ["haveKnowledgeChecked"] = true,
                    ["version"] = 3,
                    ["useUniversalStyleItemChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveMaterialChecked"] = false,
                },
                ["Provisioner"] = 
                {
                    ["haveIngredientsChecked"] = true,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = true,
                    ["version"] = 2,
                },
                ["AlchemyCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadProvisioner"] = 
                {
                    ["haveIngredientsChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = false,
                    ["version"] = 3,
                },
                ["WorldMap"] = 
                {
                    [1] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [11] = 1,
                                [1] = false,
                                [6] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["keepSquare"] = true,
                        ["y"] = 0,
                        ["relPoint"] = 128,
                        ["mapSize"] = 2,
                        ["height"] = 550,
                        ["point"] = 128,
                        ["x"] = 0,
                        ["width"] = 488,
                    },
                    [2] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [11] = 1,
                                [1] = false,
                                [6] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                    },
                    [3] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [7] = false,
                                [11] = 1,
                                [4] = false,
                                [5] = false,
                                [3] = false,
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [4] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [3] = false,
                                [11] = 1,
                                [2] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    [5] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [3] = false,
                                [5] = false,
                                [11] = 1,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [6] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [10] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [7] = false,
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [7] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [1] = false,
                                [14] = false,
                                [15] = false,
                            },
                            [2] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [11] = 1,
                                [14] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    ["userMode"] = 2,
                    ["version"] = 4,
                },
                ["AutoComplete"] = 
                {
                    ["RecentInteractions"] = 
                    {
                    },
                    ["version"] = 3,
                },
                ["GamepadEnchantingCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["UniversalDeconstruction"] = 
                {
                    ["craftingTypeFilters"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 2,
                },
                ["EnchantingCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadAlchemyCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["DeathRecap"] = 
                {
                    ["recapOn"] = true,
                    ["version"] = 1,
                },
                ["OutfitSlots"] = 
                {
                    ["showLockedStyles"] = true,
                    ["version"] = 1,
                },
                ["SmithingResearch"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["PerformanceMeters"] = 
                {
                    ["x"] = -20,
                    ["version"] = 1,
                    ["relPoint"] = 6,
                    ["y"] = 20,
                    ["point"] = 6,
                },
                ["ZO_ItemSetCollectionsDataManager"] = 
                {
                    ["equipmentFilterTypes"] = 
                    {
                    },
                    ["showLocked"] = true,
                    ["equipmentFiltersTypes"] = 
                    {
                    },
                    ["version"] = 1,
                },
                ["GamepadSmithingExtraction"] = 
                {
                    ["craftingTypes"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 1,
                },
                ["Chat"] = 
                {
                    ["containers"] = 
                    {
                        [1] = 
                        {
                            ["width"] = 445,
                            ["height"] = 267,
                            ["x"] = 0,
                            ["y"] = -82,
                            ["relPoint"] = 6,
                            ["point"] = 6,
                        },
                    },
                    ["version"] = 4,
                },
            },
            ["Sorc deez Frags"] = 
            {
                ["Dyeing"] = 
                {
                    ["sortStyle"] = 1,
                    ["showLocked"] = true,
                    ["version"] = 1,
                },
                ["SmithingExtraction"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["TradingHouseSearchHistory"] = 
                {
                    ["nextSearchOrderId"] = 0,
                    ["searchEntries"] = 
                    {
                    },
                    ["version"] = 2,
                },
                ["SmithingCreation"] = 
                {
                    ["haveKnowledgeChecked"] = true,
                    ["version"] = 3,
                    ["useUniversalStyleItemChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveMaterialChecked"] = false,
                },
                ["Provisioner"] = 
                {
                    ["haveIngredientsChecked"] = true,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = true,
                    ["version"] = 2,
                },
                ["AlchemyCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadProvisioner"] = 
                {
                    ["haveIngredientsChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = false,
                    ["version"] = 3,
                },
                ["WorldMap"] = 
                {
                    [1] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["keepSquare"] = true,
                        ["y"] = 0,
                        ["relPoint"] = 128,
                        ["mapSize"] = 2,
                        ["height"] = 550,
                        ["point"] = 128,
                        ["x"] = 0,
                        ["width"] = 488,
                    },
                    [2] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                    },
                    [3] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [15] = false,
                                [11] = 1,
                                [4] = false,
                                [5] = false,
                                [3] = false,
                                [7] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [4] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [11] = 1,
                                [2] = false,
                                [3] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    [5] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [3] = false,
                                [5] = false,
                                [11] = 1,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [6] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [10] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [15] = false,
                                [7] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [7] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [1] = false,
                                [14] = false,
                                [15] = false,
                            },
                            [2] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [11] = 1,
                                [14] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    ["userMode"] = 2,
                    ["version"] = 4,
                },
                ["AutoComplete"] = 
                {
                    ["RecentInteractions"] = 
                    {
                    },
                    ["version"] = 3,
                },
                ["GamepadEnchantingCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["UniversalDeconstruction"] = 
                {
                    ["craftingTypeFilters"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 2,
                },
                ["EnchantingCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadAlchemyCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["DeathRecap"] = 
                {
                    ["recapOn"] = true,
                    ["version"] = 1,
                },
                ["OutfitSlots"] = 
                {
                    ["showLockedStyles"] = true,
                    ["version"] = 1,
                },
                ["SmithingResearch"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["PerformanceMeters"] = 
                {
                    ["x"] = -20,
                    ["version"] = 1,
                    ["relPoint"] = 6,
                    ["y"] = 20,
                    ["point"] = 6,
                },
                ["ZO_ItemSetCollectionsDataManager"] = 
                {
                    ["equipmentFilterTypes"] = 
                    {
                    },
                    ["showLocked"] = true,
                    ["equipmentFiltersTypes"] = 
                    {
                    },
                    ["version"] = 1,
                },
                ["GamepadSmithingExtraction"] = 
                {
                    ["craftingTypes"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 1,
                },
                ["Chat"] = 
                {
                    ["containers"] = 
                    {
                        [1] = 
                        {
                            ["width"] = 445,
                            ["height"] = 267,
                            ["x"] = 0,
                            ["y"] = -82,
                            ["relPoint"] = 6,
                            ["point"] = 6,
                        },
                    },
                    ["version"] = 4,
                },
            },
            ["His Swoliness"] = 
            {
                ["Dyeing"] = 
                {
                    ["sortStyle"] = 1,
                    ["showLocked"] = true,
                    ["version"] = 1,
                },
                ["SmithingExtraction"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["TradingHouseSearchHistory"] = 
                {
                    ["nextSearchOrderId"] = 0,
                    ["searchEntries"] = 
                    {
                    },
                    ["version"] = 2,
                },
                ["SmithingCreation"] = 
                {
                    ["haveKnowledgeChecked"] = true,
                    ["version"] = 3,
                    ["useUniversalStyleItemChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveMaterialChecked"] = false,
                },
                ["Provisioner"] = 
                {
                    ["haveIngredientsChecked"] = true,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = true,
                    ["version"] = 2,
                },
                ["AlchemyCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadProvisioner"] = 
                {
                    ["haveIngredientsChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = false,
                    ["version"] = 3,
                },
                ["WorldMap"] = 
                {
                    [1] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["keepSquare"] = true,
                        ["y"] = 0,
                        ["relPoint"] = 128,
                        ["mapSize"] = 2,
                        ["height"] = 550,
                        ["point"] = 128,
                        ["x"] = 0,
                        ["width"] = 488,
                    },
                    [2] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                    },
                    [3] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [15] = false,
                                [11] = 1,
                                [4] = false,
                                [5] = false,
                                [3] = false,
                                [7] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [4] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [11] = 1,
                                [2] = false,
                                [3] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    [5] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [3] = false,
                                [5] = false,
                                [11] = 1,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [6] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [10] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [15] = false,
                                [7] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [7] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [1] = false,
                                [14] = false,
                                [15] = false,
                            },
                            [2] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [11] = 1,
                                [14] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    ["userMode"] = 2,
                    ["version"] = 4,
                },
                ["AutoComplete"] = 
                {
                    ["RecentInteractions"] = 
                    {
                    },
                    ["version"] = 3,
                },
                ["GamepadEnchantingCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["UniversalDeconstruction"] = 
                {
                    ["craftingTypeFilters"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 2,
                },
                ["EnchantingCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadAlchemyCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["DeathRecap"] = 
                {
                    ["recapOn"] = true,
                    ["version"] = 1,
                },
                ["OutfitSlots"] = 
                {
                    ["showLockedStyles"] = true,
                    ["version"] = 1,
                },
                ["SmithingResearch"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["PerformanceMeters"] = 
                {
                    ["x"] = -20,
                    ["version"] = 1,
                    ["relPoint"] = 6,
                    ["y"] = 20,
                    ["point"] = 6,
                },
                ["ZO_ItemSetCollectionsDataManager"] = 
                {
                    ["equipmentFilterTypes"] = 
                    {
                    },
                    ["showLocked"] = true,
                    ["equipmentFiltersTypes"] = 
                    {
                    },
                    ["version"] = 1,
                },
                ["GamepadSmithingExtraction"] = 
                {
                    ["craftingTypes"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 1,
                },
                ["Chat"] = 
                {
                    ["containers"] = 
                    {
                        [1] = 
                        {
                            ["width"] = 445,
                            ["height"] = 267,
                            ["x"] = 0,
                            ["y"] = -82,
                            ["relPoint"] = 6,
                            ["point"] = 6,
                        },
                    },
                    ["version"] = 4,
                },
            },
            ["Sweepy Mcsweeperson"] = 
            {
                ["Dyeing"] = 
                {
                    ["sortStyle"] = 1,
                    ["showLocked"] = true,
                    ["version"] = 1,
                },
                ["SmithingExtraction"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["TradingHouseSearchHistory"] = 
                {
                    ["nextSearchOrderId"] = 0,
                    ["searchEntries"] = 
                    {
                    },
                    ["version"] = 2,
                },
                ["SmithingCreation"] = 
                {
                    ["haveKnowledgeChecked"] = true,
                    ["version"] = 3,
                    ["useUniversalStyleItemChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveMaterialChecked"] = false,
                },
                ["Provisioner"] = 
                {
                    ["haveIngredientsChecked"] = true,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = true,
                    ["version"] = 2,
                },
                ["AlchemyCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadProvisioner"] = 
                {
                    ["haveIngredientsChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = false,
                    ["version"] = 3,
                },
                ["WorldMap"] = 
                {
                    [1] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["keepSquare"] = true,
                        ["y"] = 0,
                        ["relPoint"] = 128,
                        ["mapSize"] = 2,
                        ["height"] = 550,
                        ["point"] = 128,
                        ["x"] = 0,
                        ["width"] = 488,
                    },
                    [2] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                    },
                    [3] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [15] = false,
                                [11] = 1,
                                [4] = false,
                                [5] = false,
                                [3] = false,
                                [7] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [4] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [11] = 1,
                                [2] = false,
                                [3] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    [5] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [3] = false,
                                [5] = false,
                                [11] = 1,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [6] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [10] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [15] = false,
                                [7] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [7] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [1] = false,
                                [14] = false,
                                [15] = false,
                            },
                            [2] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [11] = 1,
                                [14] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    ["userMode"] = 2,
                    ["version"] = 4,
                },
                ["AutoComplete"] = 
                {
                    ["RecentInteractions"] = 
                    {
                    },
                    ["version"] = 3,
                },
                ["GamepadEnchantingCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["UniversalDeconstruction"] = 
                {
                    ["craftingTypeFilters"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 2,
                },
                ["EnchantingCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadAlchemyCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["DeathRecap"] = 
                {
                    ["recapOn"] = true,
                    ["version"] = 1,
                },
                ["OutfitSlots"] = 
                {
                    ["showLockedStyles"] = true,
                    ["version"] = 1,
                },
                ["SmithingResearch"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["PerformanceMeters"] = 
                {
                    ["x"] = -20,
                    ["version"] = 1,
                    ["relPoint"] = 6,
                    ["y"] = 20,
                    ["point"] = 6,
                },
                ["ZO_ItemSetCollectionsDataManager"] = 
                {
                    ["equipmentFilterTypes"] = 
                    {
                    },
                    ["showLocked"] = true,
                    ["equipmentFiltersTypes"] = 
                    {
                    },
                    ["version"] = 1,
                },
                ["GamepadSmithingExtraction"] = 
                {
                    ["craftingTypes"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 1,
                },
                ["Chat"] = 
                {
                    ["containers"] = 
                    {
                        [1] = 
                        {
                            ["width"] = 445,
                            ["height"] = 267,
                            ["x"] = 0,
                            ["y"] = -82,
                            ["relPoint"] = 6,
                            ["point"] = 6,
                        },
                    },
                    ["version"] = 4,
                },
            },
            ["$AccountWide"] = 
            {
                ["RandomRollCommand"] = 
                {
                    ["version"] = 1,
                },
                ["ZO_HousingEditor_Options"] = 
                {
                    ["rotateUnitsRadians"] = 0.2617993878,
                    ["moveUnitsCentimeters"] = 10,
                    ["version"] = 1,
                },
                ["GuildMotD"] = 
                {
                    ["Whispering Fang Syndicate"] = 336500845,
                    ["Fellow Travelers Alliance"] = 553123909,
                    ["version"] = 1,
                },
                ["ZO_GuildRecruitment_ResponseMessage"] = 
                {
                    ["version"] = 1,
                    ["guildResponseTexts"] = 
                    {
                    },
                },
                ["NameChange"] = 
                {
                    ["8796093061464499"] = "His Swoliness",
                    ["8796093057729085"] = "Big depression",
                    ["8796093057561649"] = "Sorc deez Frags",
                    ["8796093058809737"] = "Bujin Yamato",
                    ["8796093059361945"] = "Jesuz and The Beamz",
                    ["8796093060264765"] = "Sweepy Mcsweeperson",
                    ["8796093044580239"] = "Ladyharambe",
                    ["8796093059852051"] = "Sneaky lil Snake",
                    ["8796093064639529"] = "orcyagladididntfrag",
                    ["version"] = 1,
                },
                ["ZO_GuildBrowser_ApplicationMessage"] = 
                {
                    ["reportedGuilds"] = 
                    {
                    },
                    ["applicationText"] = "",
                    ["version"] = 1,
                },
            },
            ["Big depression"] = 
            {
                ["Dyeing"] = 
                {
                    ["sortStyle"] = 1,
                    ["showLocked"] = true,
                    ["version"] = 1,
                },
                ["SmithingExtraction"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["TradingHouseSearchHistory"] = 
                {
                    ["nextSearchOrderId"] = 0,
                    ["searchEntries"] = 
                    {
                    },
                    ["version"] = 2,
                },
                ["SmithingCreation"] = 
                {
                    ["haveKnowledgeChecked"] = true,
                    ["version"] = 3,
                    ["useUniversalStyleItemChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveMaterialChecked"] = false,
                },
                ["Provisioner"] = 
                {
                    ["haveIngredientsChecked"] = true,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = true,
                    ["version"] = 2,
                },
                ["AlchemyCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadProvisioner"] = 
                {
                    ["haveIngredientsChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = false,
                    ["version"] = 3,
                },
                ["WorldMap"] = 
                {
                    [1] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [11] = 1,
                                [1] = false,
                                [6] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["keepSquare"] = true,
                        ["y"] = 0,
                        ["relPoint"] = 128,
                        ["mapSize"] = 2,
                        ["height"] = 550,
                        ["point"] = 128,
                        ["x"] = 0,
                        ["width"] = 488,
                    },
                    [2] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [11] = 1,
                                [1] = false,
                                [6] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                    },
                    [3] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [7] = false,
                                [11] = 1,
                                [4] = false,
                                [5] = false,
                                [3] = false,
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [4] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [3] = false,
                                [11] = 1,
                                [2] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    [5] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [3] = false,
                                [5] = false,
                                [11] = 1,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [6] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [10] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [7] = false,
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [7] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [1] = false,
                                [14] = false,
                                [15] = false,
                            },
                            [2] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [11] = 1,
                                [14] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    ["userMode"] = 2,
                    ["version"] = 4,
                },
                ["AutoComplete"] = 
                {
                    ["RecentInteractions"] = 
                    {
                    },
                    ["version"] = 3,
                },
                ["GamepadEnchantingCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["UniversalDeconstruction"] = 
                {
                    ["craftingTypeFilters"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 2,
                },
                ["EnchantingCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadAlchemyCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["Chat"] = 
                {
                    ["containers"] = 
                    {
                        [1] = 
                        {
                            ["width"] = 445,
                            ["height"] = 267,
                            ["x"] = 0,
                            ["y"] = -82,
                            ["relPoint"] = 6,
                            ["point"] = 6,
                        },
                    },
                    ["version"] = 4,
                },
                ["OutfitSlots"] = 
                {
                    ["showLockedStyles"] = true,
                    ["version"] = 1,
                },
                ["SmithingResearch"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["PerformanceMeters"] = 
                {
                    ["x"] = -20,
                    ["version"] = 1,
                    ["relPoint"] = 6,
                    ["y"] = 20,
                    ["point"] = 6,
                },
                ["DeathRecap"] = 
                {
                    ["recapOn"] = true,
                    ["version"] = 1,
                },
                ["GamepadSmithingExtraction"] = 
                {
                    ["craftingTypes"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 1,
                },
                ["ZO_ItemSetCollectionsDataManager"] = 
                {
                    ["equipmentFilterTypes"] = 
                    {
                    },
                    ["showLocked"] = true,
                    ["equipmentFiltersTypes"] = 
                    {
                    },
                    ["version"] = 1,
                },
            },
            ["Sneaky lil Snake"] = 
            {
                ["Dyeing"] = 
                {
                    ["sortStyle"] = 1,
                    ["showLocked"] = true,
                    ["version"] = 1,
                },
                ["SmithingExtraction"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["TradingHouseSearchHistory"] = 
                {
                    ["nextSearchOrderId"] = 0,
                    ["searchEntries"] = 
                    {
                    },
                    ["version"] = 2,
                },
                ["SmithingCreation"] = 
                {
                    ["haveKnowledgeChecked"] = true,
                    ["version"] = 3,
                    ["useUniversalStyleItemChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveMaterialChecked"] = false,
                },
                ["Provisioner"] = 
                {
                    ["haveIngredientsChecked"] = true,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = true,
                    ["version"] = 2,
                },
                ["AlchemyCreation"] = 
                {
                    ["questsOnlyChecked"] = true,
                    ["version"] = 1,
                },
                ["GamepadProvisioner"] = 
                {
                    ["haveIngredientsChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveSkillsChecked"] = false,
                    ["version"] = 3,
                },
                ["WorldMap"] = 
                {
                    [1] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["keepSquare"] = true,
                        ["y"] = 0,
                        ["relPoint"] = 128,
                        ["mapSize"] = 2,
                        ["height"] = 550,
                        ["point"] = 128,
                        ["x"] = 0,
                        ["width"] = 488,
                    },
                    [2] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                    },
                    [3] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [11] = 1,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [15] = false,
                                [7] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [4] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [11] = 1,
                                [2] = false,
                                [3] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    [5] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [3] = false,
                                [5] = false,
                                [11] = 1,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [6] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [10] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [15] = false,
                                [7] = false,
                            },
                        },
                        ["mapSize"] = 1,
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                    },
                    [7] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [1] = false,
                                [14] = false,
                                [15] = false,
                            },
                            [2] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [11] = 1,
                                [14] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    ["userMode"] = 2,
                    ["version"] = 4,
                },
                ["AutoComplete"] = 
                {
                    ["RecentInteractions"] = 
                    {
                    },
                    ["version"] = 3,
                },
                ["GamepadEnchantingCreation"] = 
                {
                    ["version"] = 1,
                    ["shouldFilterQuests"] = false,
                },
                ["UniversalDeconstruction"] = 
                {
                    ["craftingTypeFilters"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 2,
                },
                ["EnchantingCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["DeathRecap"] = 
                {
                    ["recapOn"] = true,
                    ["version"] = 1,
                },
                ["GamepadAlchemyCreation"] = 
                {
                    ["version"] = 1,
                    ["shouldFilterQuests"] = false,
                },
                ["OutfitSlots"] = 
                {
                    ["version"] = 1,
                    ["showLockedStyles"] = true,
                },
                ["SmithingResearch"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                },
                ["PerformanceMeters"] = 
                {
                    ["x"] = -20,
                    ["version"] = 1,
                    ["relPoint"] = 6,
                    ["y"] = 20,
                    ["point"] = 6,
                },
                ["GamepadSmithingExtraction"] = 
                {
                    ["craftingTypes"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 1,
                },
                ["Chat"] = 
                {
                    ["containers"] = 
                    {
                        [1] = 
                        {
                            ["width"] = 445,
                            ["height"] = 267,
                            ["x"] = 0,
                            ["y"] = -82,
                            ["relPoint"] = 6,
                            ["point"] = 6,
                        },
                    },
                    ["version"] = 4,
                },
                ["ZO_ItemSetCollectionsDataManager"] = 
                {
                    ["equipmentFilterTypes"] = 
                    {
                    },
                    ["showLocked"] = true,
                    ["equipmentFiltersTypes"] = 
                    {
                    },
                    ["version"] = 1,
                },
            },
        },
    },
}
