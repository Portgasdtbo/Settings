BattlegroundCoffersVars =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["cooldownCofferTimes"] = 
                {
                    ["8796093061464499"] = 1686268233,
                    ["8796093057729085"] = 1686269289,
                    ["8796093057561649"] = 1686267084,
                    ["8796093058809737"] = 1686268278,
                    ["8796093059852051"] = 1686269604,
                    ["8796093060264765"] = 1686270211,
                },
                ["allianceTierInfo"] = 
                {
                },
                ["excludedCharacters"] = 
                {
                },
                ["version"] = 3,
            },
        },
    },
}
