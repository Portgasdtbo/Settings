LibSets_SV_Data =
{
    ["NA Megaserver"] = 
    {
        ["$AllAccounts"] = 
        {
            ["$AccountWide"] = 
            {
                ["addSetCollectionsCurrentZoneButton"] = true,
                ["setPreviewTooltips"] = 
                {
                    ["enchantSearchCategoryType"] = 0,
                    ["traitType"] = 18,
                    ["equipType"] = 3,
                    ["quality"] = 370,
                    ["sendToChatToo"] = true,
                },
                ["modifyTooltips"] = false,
                ["version"] = 0.3800000000,
                ["tooltipModifications"] = 
                {
                    ["addBossName"] = true,
                    ["addSetType"] = true,
                    ["tooltipTextures"] = true,
                    ["addDLC"] = true,
                    ["addDropMechanic"] = true,
                    ["addDropLocation"] = true,
                    ["addReconstructionCost"] = true,
                    ["addNeededTraits"] = true,
                },
                ["useCustomTooltipPattern"] = "",
            },
        },
    },
}
LibSets_SV_DEBUG_Data =
{
    ["Default"] = 
    {
        ["$AllAccounts"] = 
        {
            ["$AccountWide"] = 
            {
                ["zoneData"] = 
                {
                },
                ["wayshrineNames"] = 
                {
                },
                ["dungeonFinderData"] = 
                {
                },
                ["setNames"] = 
                {
                },
                ["setItemIds"] = 
                {
                },
                ["maps"] = 
                {
                },
                ["setItemIds_Compressed"] = 
                {
                },
                ["version"] = 1,
                ["collectibleNames"] = 
                {
                },
                ["collectible_DLCNames"] = 
                {
                },
                ["setItemIdsNoSetId"] = 
                {
                },
                ["NewSetIDs"] = 
                {
                },
            },
        },
    },
}
