DolgubonsWritCrafterSavedVars =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["8796093061464499"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                ["dailyResetWarnTime"] = 60,
                ["lootJubileeBoxes"] = true,
                ["autoCloseBank"] = true,
                ["ignoreAuto"] = false,
                ["keepQuestBuffer"] = false,
                ["suppressQuestAnnouncements"] = true,
                ["OffsetX"] = 1150,
                ["version"] = 19,
                ["lootOutput"] = false,
                ["$LastCharacterName"] = "His Swoliness",
                ["dailyResetWarnType"] = "announcement",
                ["useCharacterSettings"] = false,
                ["OffsetY"] = 0,
                ["jewelryWritDestroy"] = false,
                ["updateChoiceCopies"] = 
                {
                },
                ["autoCraft"] = true,
                ["changeReticle"] = true,
                ["reticleAntiSteal"] = true,
                ["exitWhenDone"] = true,
                ["tutorial"] = false,
                ["craftMultiplier"] = 1,
                ["shouldGrab"] = true,
                ["transmuteBlock"] = 
                {
                },
                ["mail"] = 
                {
                    ["delete"] = false,
                    ["loot"] = true,
                },
                ["delay"] = 100,
                ["styles"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    [8] = true,
                    [9] = true,
                    [10] = true,
                    [34] = true,
                },
                ["autoLoot"] = true,
                ["debug"] = false,
                ["skipItemQuests"] = 
                {
                    ["|H1:item:45831:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:77591:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                },
                ["showWindow"] = true,
                ["autoAccept"] = true,
                ["hideWhenDone"] = true,
                ["EZJewelryDestroy"] = true,
                ["containerDelay"] = 1,
                ["keepNewContainer"] = true,
                ["rewardHandling"] = 
                {
                    ["fragment"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["repair"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["master"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["survey"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["intricate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["ornate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["recipe"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["soulGem"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["mats"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["glyph"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                },
                ["lootContainerOnReceipt"] = true,
                ["despawnBanker"] = true,
                ["scanForUnopened"] = false,
                ["stealProtection"] = true,
            },
            ["8796093057729085"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                ["dailyResetWarnTime"] = 60,
                ["lootJubileeBoxes"] = true,
                ["autoCloseBank"] = true,
                ["ignoreAuto"] = false,
                ["keepQuestBuffer"] = false,
                ["suppressQuestAnnouncements"] = true,
                ["OffsetX"] = 1506,
                ["version"] = 19,
                ["lootOutput"] = false,
                ["$LastCharacterName"] = "Big depression",
                ["dailyResetWarnType"] = "announcement",
                ["hideWhenDone"] = true,
                ["OffsetY"] = 0,
                ["jewelryWritDestroy"] = false,
                ["updateChoiceCopies"] = 
                {
                },
                ["autoCraft"] = true,
                ["changeReticle"] = true,
                ["reticleAntiSteal"] = true,
                ["exitWhenDone"] = true,
                ["tutorial"] = false,
                ["craftMultiplier"] = 1,
                ["shouldGrab"] = true,
                ["autoLoot"] = true,
                ["debug"] = false,
                ["delay"] = 100,
                ["styles"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    [8] = true,
                    [9] = true,
                    [10] = true,
                    [34] = true,
                },
                ["mail"] = 
                {
                    ["delete"] = false,
                    ["loot"] = true,
                },
                ["transmuteBlock"] = 
                {
                },
                ["skipItemQuests"] = 
                {
                    ["|H1:item:45831:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:77591:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                },
                ["showWindow"] = true,
                ["autoAccept"] = true,
                ["keepNewContainer"] = true,
                ["EZJewelryDestroy"] = true,
                ["containerDelay"] = 1,
                ["lootContainerOnReceipt"] = true,
                ["rewardHandling"] = 
                {
                    ["fragment"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["repair"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        ["all"] = 1,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["master"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["survey"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["intricate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["ornate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["recipe"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["soulGem"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["mats"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["glyph"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                },
                ["useCharacterSettings"] = false,
                ["despawnBanker"] = true,
                ["scanForUnopened"] = false,
                ["stealProtection"] = true,
            },
            ["8796093057561649"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                ["dailyResetWarnTime"] = 60,
                ["lootJubileeBoxes"] = true,
                ["autoCloseBank"] = true,
                ["ignoreAuto"] = false,
                ["keepQuestBuffer"] = false,
                ["suppressQuestAnnouncements"] = true,
                ["OffsetX"] = 1150,
                ["version"] = 19,
                ["lootOutput"] = false,
                ["$LastCharacterName"] = "Sorc deez Frags",
                ["dailyResetWarnType"] = "announcement",
                ["useCharacterSettings"] = false,
                ["OffsetY"] = 0,
                ["jewelryWritDestroy"] = false,
                ["updateChoiceCopies"] = 
                {
                },
                ["autoCraft"] = true,
                ["changeReticle"] = true,
                ["reticleAntiSteal"] = true,
                ["exitWhenDone"] = true,
                ["tutorial"] = false,
                ["craftMultiplier"] = 1,
                ["shouldGrab"] = true,
                ["transmuteBlock"] = 
                {
                },
                ["keepNewContainer"] = true,
                ["delay"] = 100,
                ["styles"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    [8] = true,
                    [9] = true,
                    [10] = true,
                    [34] = true,
                },
                ["autoLoot"] = true,
                ["debug"] = false,
                ["skipItemQuests"] = 
                {
                    ["|H1:item:45831:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:77591:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                },
                ["showWindow"] = true,
                ["autoAccept"] = true,
                ["mail"] = 
                {
                    ["delete"] = false,
                    ["loot"] = true,
                },
                ["EZJewelryDestroy"] = true,
                ["containerDelay"] = 1,
                ["hideWhenDone"] = true,
                ["rewardHandling"] = 
                {
                    ["fragment"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["repair"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["master"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["survey"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["intricate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["ornate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["recipe"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["soulGem"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["mats"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["glyph"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                },
                ["lootContainerOnReceipt"] = true,
                ["despawnBanker"] = true,
                ["scanForUnopened"] = false,
                ["stealProtection"] = true,
            },
            ["$AccountWide"] = 
            {
                ["alternateUniverse"] = true,
                ["total"] = 42,
                ["unlockedCheese"] = false,
                ["skipped"] = 0,
                ["timeSinceReset"] = 1686264950,
                ["notifyWiped"] = true,
                ["skin"] = "default",
                ["identifier"] = 22,
                ["writLocations"] = 
                {
                    [57] = 
                    {
                        [1] = 10,
                        [2] = 231085,
                        [3] = 249391,
                        [4] = 1000000,
                    },
                    [849] = 
                    {
                        [1] = 849,
                        [2] = 215118,
                        [3] = 512682,
                        [4] = 1000000,
                    },
                    [1011] = 
                    {
                        [1] = 1011,
                        [2] = 146161,
                        [3] = 341851,
                        [4] = 1000000,
                    },
                    [20] = 
                    {
                        [1] = 20,
                        [2] = 243273,
                        [3] = 227612,
                        [4] = 1000000,
                    },
                    [347] = 
                    {
                        [1] = 347,
                        [2] = 237668,
                        [3] = 302699,
                        [4] = 1000000,
                    },
                    [382] = 
                    {
                        [1] = 382,
                        [2] = 122717,
                        [3] = 187928,
                        [4] = 1000000,
                    },
                    [103] = 
                    {
                        [1] = 103,
                        [2] = 366252,
                        [3] = 201624,
                        [4] = 2000000,
                    },
                },
                ["updateDefaultCopyValue"] = 
                {
                },
                [6697110] = false,
                ["masterWrits"] = true,
                ["luckyProgress"] = 
                {
                    ["rngesus"] = 0,
                    ["gutDestruction"] = 0,
                    ["cheeseCompletion"] = 0,
                    ["lootGut"] = 0,
                    ["shootingOnLocation"] = 0,
                    ["luckCompletion"] = 0,
                    ["readInstructions"] = 0,
                    ["cheeseNerd"] = 0,
                },
                ["accountWideProfile"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    ["dailyResetWarnTime"] = 60,
                    ["lootJubileeBoxes"] = true,
                    ["autoCloseBank"] = true,
                    ["ignoreAuto"] = false,
                    ["keepQuestBuffer"] = false,
                    ["suppressQuestAnnouncements"] = true,
                    ["OffsetX"] = 1506,
                    ["preventMasterWritAccept"] = true,
                    ["lootOutput"] = false,
                    ["dailyResetWarnType"] = "announcement",
                    ["useCharacterSettings"] = false,
                    ["OffsetY"] = 0,
                    ["jewelryWritDestroy"] = false,
                    ["updateChoiceCopies"] = 
                    {
                    },
                    ["autoCraft"] = true,
                    ["changeReticle"] = true,
                    ["reticleAntiSteal"] = true,
                    ["exitWhenDone"] = true,
                    ["tutorial"] = false,
                    ["craftMultiplier"] = 1,
                    ["shouldGrab"] = true,
                    ["transmuteBlock"] = 
                    {
                    },
                    ["keepNewContainer"] = true,
                    ["delay"] = 100,
                    ["styles"] = 
                    {
                        [1] = true,
                        [2] = true,
                        [3] = true,
                        [4] = true,
                        [5] = true,
                        [6] = true,
                        [7] = true,
                        [8] = true,
                        [9] = true,
                        [10] = true,
                        [34] = true,
                    },
                    ["autoLoot"] = true,
                    ["debug"] = false,
                    ["skipItemQuests"] = 
                    {
                        ["|H1:item:45831:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                        ["|H1:item:30152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                        ["|H1:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                        ["|H1:item:30165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                        ["|H1:item:77591:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    },
                    ["showWindow"] = true,
                    ["autoAccept"] = true,
                    ["mail"] = 
                    {
                        ["delete"] = false,
                        ["loot"] = true,
                    },
                    ["EZJewelryDestroy"] = true,
                    ["containerDelay"] = 1,
                    ["hideWhenDone"] = true,
                    ["rewardHandling"] = 
                    {
                        ["fragment"] = 
                        {
                            [0] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["repair"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            ["all"] = 1,
                            ["sameForAllCrafts"] = true,
                            [6] = 1,
                            [7] = 1,
                        },
                        ["master"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            [3] = 1,
                            [4] = 1,
                            [5] = 1,
                            [6] = 1,
                            [7] = 1,
                            ["all"] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["survey"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            [3] = 1,
                            [4] = 1,
                            [6] = 1,
                            [7] = 1,
                            ["all"] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["intricate"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            ["sameForAllCrafts"] = true,
                            [6] = 1,
                            [7] = 1,
                        },
                        ["ornate"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            ["sameForAllCrafts"] = true,
                            [6] = 1,
                            [7] = 1,
                        },
                        ["recipe"] = 
                        {
                            [0] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["soulGem"] = 
                        {
                            [0] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["mats"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            [3] = 1,
                            [4] = 1,
                            [5] = 1,
                            [6] = 1,
                            [7] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["glyph"] = 
                        {
                            [0] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                    },
                    ["lootContainerOnReceipt"] = true,
                    ["despawnBanker"] = true,
                    ["scanForUnopened"] = false,
                    ["stealProtection"] = true,
                },
                ["version"] = 20,
                ["updateNoticesShown"] = 
                {
                },
                ["unlockedGoat"] = false,
                ["cheesyProgress"] = 
                {
                    ["cheesyDestruction"] = 0,
                    ["music"] = 0,
                    ["cheeseProfession"] = 0,
                    ["sheoVisit"] = 0,
                    ["cheeseCompletion"] = 0,
                    ["cheeseNerd"] = 0,
                },
                ["rewards"] = 
                {
                    [1] = 
                    {
                        ["num"] = 6,
                        [23203] = 1,
                        ["voucher"] = 6,
                        [23173] = 1,
                        [4456] = 1,
                        ["material"] = 6,
                        ["ornate"] = 3,
                        [30219] = 1,
                        ["lead"] = 1,
                        ["fragment"] = 0,
                        ["repair"] = 2,
                        ["master"] = 1,
                        ["survey"] = 0,
                        ["intricate"] = 3,
                        [4442] = 1,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["blue"] = 0,
                            ["white"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                        [54173] = 2,
                        [23171] = 1,
                    },
                    [2] = 
                    {
                        ["fragment"] = 0,
                        [54177] = 2,
                        ["num"] = 6,
                        ["repair"] = 2,
                        [23173] = 2,
                        ["master"] = 0,
                        ["survey"] = 1,
                        ["intricate"] = 5,
                        ["material"] = 5,
                        [4442] = 1,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["blue"] = 0,
                            ["white"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                        [30221] = 2,
                        ["ornate"] = 1,
                        [23221] = 1,
                    },
                    [3] = 
                    {
                        ["glyph"] = 6,
                        ["num"] = 6,
                        ["soulGem"] = 15,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["blue"] = 0,
                            ["white"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                        [45854] = 3,
                        ["master"] = 0,
                        ["survey"] = 1,
                    },
                    [4] = 
                    {
                        [30165] = 9,
                        ["num"] = 6,
                        [30163] = 6,
                        [30148] = 6,
                        [64501] = 18,
                        ["master"] = 0,
                        ["survey"] = 1,
                        [30157] = 6,
                        [30153] = 6,
                        [30156] = 9,
                        [75365] = 18,
                        ["lead"] = 1,
                        [75357] = 3,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["blue"] = 0,
                            ["white"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                        [883] = 3,
                    },
                    [5] = 
                    {
                        [34305] = 10,
                        ["num"] = 6,
                        [27043] = 10,
                        [33768] = 10,
                        [27049] = 5,
                        [26954] = 15,
                        [33771] = 10,
                        [26802] = 8,
                        [33774] = 10,
                        [34323] = 10,
                        ["fragment"] = 1,
                        [27057] = 5,
                        [27058] = 5,
                        [27059] = 8,
                        [34324] = 10,
                        [27035] = 5,
                        ["master"] = 0,
                        [27063] = 5,
                        [33752] = 20,
                        [34329] = 10,
                        [28666] = 5,
                        [28603] = 10,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["blue"] = 0,
                            ["white"] = 0,
                            ["gold"] = 0,
                            ["green"] = 6,
                        },
                        [34330] = 10,
                        [27048] = 5,
                        [34335] = 10,
                    },
                    [6] = 
                    {
                        ["fragment"] = 0,
                        ["num"] = 6,
                        [23171] = 1,
                        ["repair"] = 1,
                        ["ornate"] = 0,
                        ["master"] = 0,
                        ["survey"] = 0,
                        ["intricate"] = 6,
                        ["material"] = 6,
                        [810] = 1,
                        [30219] = 1,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["blue"] = 0,
                            ["white"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                        [23165] = 1,
                        [4456] = 1,
                        [23203] = 1,
                    },
                    [7] = 
                    {
                        [135153] = 2,
                        [135154] = 1,
                        ["survey"] = 1,
                        ["intricate"] = 6,
                        ["material"] = 5,
                        ["soulGem"] = 2,
                        ["num"] = 6,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["blue"] = 0,
                            ["white"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                        [135159] = 1,
                        [135160] = 5,
                        [135151] = 2,
                    },
                },
            },
            ["8796093058809737"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                ["dailyResetWarnTime"] = 60,
                ["lootJubileeBoxes"] = true,
                ["autoCloseBank"] = true,
                ["ignoreAuto"] = false,
                ["keepQuestBuffer"] = false,
                ["suppressQuestAnnouncements"] = true,
                ["OffsetX"] = 1150,
                ["version"] = 19,
                ["lootOutput"] = false,
                ["$LastCharacterName"] = "Bujin Yamato",
                ["dailyResetWarnType"] = "announcement",
                ["useCharacterSettings"] = false,
                ["OffsetY"] = 0,
                ["jewelryWritDestroy"] = false,
                ["updateChoiceCopies"] = 
                {
                },
                ["autoCraft"] = true,
                ["changeReticle"] = true,
                ["reticleAntiSteal"] = true,
                ["exitWhenDone"] = true,
                ["tutorial"] = false,
                ["craftMultiplier"] = 1,
                ["shouldGrab"] = true,
                ["transmuteBlock"] = 
                {
                },
                ["keepNewContainer"] = true,
                ["delay"] = 100,
                ["styles"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    [8] = true,
                    [9] = true,
                    [10] = true,
                    [34] = true,
                },
                ["autoLoot"] = true,
                ["mail"] = 
                {
                    ["delete"] = false,
                    ["loot"] = true,
                },
                ["skipItemQuests"] = 
                {
                    ["|H1:item:45831:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:77591:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                },
                ["showWindow"] = true,
                ["autoAccept"] = true,
                ["debug"] = false,
                ["EZJewelryDestroy"] = true,
                ["containerDelay"] = 1,
                ["hideWhenDone"] = true,
                ["rewardHandling"] = 
                {
                    ["fragment"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["repair"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["master"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["survey"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["intricate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["ornate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["recipe"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["soulGem"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["mats"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["glyph"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                },
                ["lootContainerOnReceipt"] = true,
                ["despawnBanker"] = true,
                ["scanForUnopened"] = false,
                ["stealProtection"] = true,
            },
            ["8796093059852051"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                ["dailyResetWarnTime"] = 60,
                ["lootJubileeBoxes"] = true,
                ["autoCloseBank"] = true,
                ["ignoreAuto"] = false,
                ["keepQuestBuffer"] = false,
                ["suppressQuestAnnouncements"] = true,
                ["OffsetX"] = 1506,
                ["version"] = 19,
                ["lootOutput"] = false,
                ["$LastCharacterName"] = "Sneaky lil Snake",
                ["dailyResetWarnType"] = "announcement",
                ["useCharacterSettings"] = false,
                ["OffsetY"] = 0,
                ["jewelryWritDestroy"] = false,
                ["updateChoiceCopies"] = 
                {
                },
                ["autoCraft"] = true,
                ["changeReticle"] = true,
                ["reticleAntiSteal"] = true,
                ["exitWhenDone"] = true,
                ["tutorial"] = false,
                ["craftMultiplier"] = 1,
                ["shouldGrab"] = true,
                ["transmuteBlock"] = 
                {
                },
                ["debug"] = false,
                ["delay"] = 100,
                ["styles"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    [8] = true,
                    [9] = true,
                    [10] = true,
                    [34] = true,
                },
                ["mail"] = 
                {
                    ["delete"] = false,
                    ["loot"] = true,
                },
                ["hideWhenDone"] = true,
                ["skipItemQuests"] = 
                {
                    ["|H1:item:45831:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:77591:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                },
                ["showWindow"] = true,
                ["autoAccept"] = true,
                ["lootContainerOnReceipt"] = true,
                ["EZJewelryDestroy"] = true,
                ["containerDelay"] = 1,
                ["rewardHandling"] = 
                {
                    ["fragment"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["repair"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        ["all"] = 1,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["master"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["survey"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["intricate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["ornate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["recipe"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["glyph"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["mats"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["soulGem"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                },
                ["autoLoot"] = true,
                ["despawnBanker"] = true,
                ["keepNewContainer"] = true,
                ["scanForUnopened"] = false,
                ["stealProtection"] = true,
            },
            ["8796093060264765"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                ["dailyResetWarnTime"] = 60,
                ["lootJubileeBoxes"] = true,
                ["autoCloseBank"] = true,
                ["ignoreAuto"] = false,
                ["keepQuestBuffer"] = false,
                ["suppressQuestAnnouncements"] = true,
                ["OffsetX"] = 1150,
                ["preventMasterWritAccept"] = true,
                ["version"] = 19,
                ["lootOutput"] = false,
                ["$LastCharacterName"] = "Sweepy Mcsweeperson",
                ["dailyResetWarnType"] = "announcement",
                ["useCharacterSettings"] = false,
                ["OffsetY"] = 0,
                ["jewelryWritDestroy"] = false,
                ["updateChoiceCopies"] = 
                {
                },
                ["autoCraft"] = false,
                ["changeReticle"] = true,
                ["reticleAntiSteal"] = true,
                ["exitWhenDone"] = true,
                ["tutorial"] = true,
                ["craftMultiplier"] = 1,
                ["shouldGrab"] = true,
                ["transmuteBlock"] = 
                {
                },
                ["keepNewContainer"] = true,
                ["delay"] = 100,
                ["styles"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    [8] = true,
                    [9] = true,
                    [10] = true,
                    [34] = true,
                },
                ["autoLoot"] = true,
                ["debug"] = false,
                ["skipItemQuests"] = 
                {
                    ["|H1:item:45831:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:77591:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                },
                ["showWindow"] = true,
                ["autoAccept"] = true,
                ["mail"] = 
                {
                    ["delete"] = false,
                    ["loot"] = true,
                },
                ["EZJewelryDestroy"] = true,
                ["containerDelay"] = 1,
                ["hideWhenDone"] = true,
                ["rewardHandling"] = 
                {
                    ["fragment"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["repair"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["master"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["survey"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["intricate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["ornate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["recipe"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["soulGem"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["mats"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["glyph"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                },
                ["lootContainerOnReceipt"] = true,
                ["despawnBanker"] = true,
                ["scanForUnopened"] = false,
                ["stealProtection"] = true,
            },
        },
    },
}
