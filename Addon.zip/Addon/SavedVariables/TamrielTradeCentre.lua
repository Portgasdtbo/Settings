TamrielTradeCentreVars =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["Settings"] = 
                {
                    ["EnableItemPriceToChatBtn"] = true,
                    ["EnablePriceToChatSuggested"] = true,
                    ["MaxAutoRecordStoreEntryCount"] = 20000,
                    ["EnableToolTipLastUpdate"] = true,
                    ["EnableItemSoldNotification"] = true,
                    ["AdditionalPriceToChatLang"] = 
                    {
                    },
                    ["EnableItemSearchOnlineBtn"] = true,
                    ["EnablePriceToChatLastUpdate"] = false,
                    ["EnableAutoRecordStoreEntries"] = true,
                    ["EnableSelfEntriesUpload"] = true,
                    ["EnableToolTipAggregate"] = true,
                    ["EnablePriceToChatStat"] = true,
                    ["EnablePriceToChatAggregate"] = false,
                    ["EnableToolTipSuggested"] = true,
                    ["EnableItemToolTipPricing"] = true,
                    ["EnableToolTipStat"] = true,
                    ["SearchOnlineSort"] = "LastSeen",
                    ["SearchOnlineOrder"] = "desc",
                    ["EnableItemPriceDetailOnlineBtn"] = true,
                },
                ["NAData"] = 
                {
                    ["Guilds"] = 
                    {
                    },
                    ["IsFirstExecute"] = false,
                    ["AutoRecordEntries"] = 
                    {
                        ["Guilds"] = 
                        {
                        },
                        ["Count"] = 0,
                    },
                },
                ["ClientCulture"] = "en",
                ["EUData"] = 
                {
                    ["Guilds"] = 
                    {
                    },
                    ["IsFirstExecute"] = true,
                    ["AutoRecordEntries"] = 
                    {
                        ["Guilds"] = 
                        {
                        },
                        ["Count"] = 0,
                    },
                },
                ["version"] = 3,
                ["ActualVersion"] = 10,
            },
        },
    },
}
