CombatMetricsFightDataSV =
{
    ["version"] = 13,
}
