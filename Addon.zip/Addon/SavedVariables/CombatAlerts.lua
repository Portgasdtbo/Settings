CombatAlertsSavedVariables =
{
    ["Default"] = 
    {
        ["$InstallationWide"] = 
        {
            ["$AccountWide"] = 
            {
                ["extMA"] = false,
                ["crshift"] = true,
                ["nearbyLeft"] = 1200,
                ["maxCastMS"] = 4000,
                ["debugLog"] = 
                {
                },
                ["castAlertsSound"] = true,
                ["extTDC"] = false,
                ["nearbyTop"] = 300,
                ["nearbyEnabled"] = false,
                ["panelLeft"] = 400,
                ["verboseCasts"] = false,
                ["dsrPortSounds"] = false,
                ["dsrDelugeBlame"] = false,
                ["panelTop"] = 300,
                ["lokiStance"] = false,
                ["castAlertsEnabled"] = true,
                ["debugEnabled"] = false,
                ["projectileTimingAdjustment"] = 0.8000000000,
                ["dsrShowWave"] = false,
                ["version"] = 1,
                ["crushing"] = false,
            },
        },
    },
}
