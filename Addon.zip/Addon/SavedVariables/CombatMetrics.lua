CombatMetrics_Save =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["Settings"] = 
                {
                    ["NotificationAllowed"] = true,
                    ["CombatMetrics_Report"] = 
                    {
                        ["x"] = 1280,
                        ["y"] = 645,
                    },
                    ["autoscreenshot"] = false,
                    ["autoselectchatchannel"] = true,
                    ["chatLog"] = 
                    {
                        ["name"] = "CMX Combat Log",
                        ["enabled"] = false,
                        ["damageIn"] = false,
                        ["damageOut"] = true,
                        ["healingIn"] = false,
                        ["healingOut"] = false,
                    },
                    ["recordgrp"] = true,
                    ["SVsize"] = 0.0000381470,
                    ["showstacks"] = true,
                    ["crusherValue"] = 2108,
                    ["ForceNotification"] = false,
                    ["recordgrpinlarge"] = true,
                    ["accountwide"] = true,
                    ["keepbossfights"] = false,
                    ["FightReport"] = 
                    {
                        ["CLSelection"] = 
                        {
                            [16] = false,
                            [4] = true,
                            [5] = false,
                            [7] = false,
                            [8] = false,
                            [10] = false,
                            [11] = false,
                            [12] = false,
                            [13] = false,
                            [14] = false,
                            [15] = false,
                        },
                        ["rightpanel"] = "buffs",
                        ["PlotColors"] = 
                        {
                            [1] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 1,
                                [3] = 0,
                            },
                            [2] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 0,
                                [3] = 0,
                            },
                            [3] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 0,
                                [2] = 1,
                                [3] = 0,
                            },
                            [4] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 0,
                                [2] = 0,
                                [3] = 1,
                            },
                            [5] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 0,
                                [3] = 1,
                            },
                            [6] = 
                            {
                                [4] = 0.4000000000,
                                [1] = 0.4000000000,
                                [2] = 1,
                                [3] = 0.4000000000,
                            },
                            [7] = 
                            {
                                [4] = 0.4000000000,
                                [1] = 1,
                                [2] = 0.4000000000,
                                [3] = 0.9000000000,
                            },
                        },
                        ["scale"] = 1,
                        ["mainpanel"] = "FightStats",
                        ["showPets"] = true,
                        ["Cursor"] = true,
                        ["useDisplayNames"] = false,
                        ["hitCritLayout"] = 
                        {
                            ["healingOut"] = 1,
                            ["damageOut"] = 1,
                            ["healingIn"] = 1,
                            ["damageIn"] = 1,
                        },
                        ["averageLayout"] = 
                        {
                            ["healingOut"] = 1,
                            ["damageOut"] = 1,
                            ["healingIn"] = 1,
                            ["damageIn"] = 1,
                        },
                        ["ShowGroupBuffsInPlots"] = true,
                        ["showWereWolf"] = false,
                        ["category"] = "damageOut",
                        ["fightstatspanel"] = 1,
                        ["maxValue"] = 
                        {
                            ["healingOut"] = true,
                            ["damageOut"] = true,
                            ["healingIn"] = true,
                            ["damageIn"] = true,
                        },
                        ["SmoothWindow"] = 5,
                        ["FavouriteBuffs"] = 
                        {
                        },
                    },
                    ["liveReport"] = 
                    {
                        ["locked"] = false,
                        ["layout"] = "Compact",
                        ["enabled"] = false,
                        ["damageIn"] = true,
                        ["damageOutSingle"] = false,
                        ["time"] = true,
                        ["healOutAbsolute"] = false,
                        ["scale"] = 1,
                        ["alignmentleft"] = false,
                        ["healOut"] = true,
                        ["damageOut"] = true,
                        ["healIn"] = true,
                        ["bgalpha"] = 95,
                    },
                    ["maxSVsize"] = 10,
                    ["offincyrodil"] = false,
                    ["chunksize"] = 1000,
                    ["autoscreenshotmintime"] = 30,
                    ["fighthistory"] = 25,
                    ["tremorscaleValue"] = 2640,
                    ["unitresistance"] = 18200,
                    ["alkoshValue"] = 6000,
                    ["showDebugIds"] = false,
                    ["lightmodeincyrodil"] = true,
                    ["version"] = 5,
                    ["CombatMetrics_LiveReport"] = 
                    {
                        ["x"] = 1282,
                        ["y"] = 1341,
                    },
                    ["currentNotificationVersion"] = 0,
                    ["lightmode"] = false,
                    ["NotificationRead"] = 0,
                },
            },
            ["8796093060264765"] = 
            {
                ["Settings"] = 
                {
                    ["NotificationAllowed"] = true,
                    ["CombatMetrics_Report"] = 
                    {
                        ["x"] = 1280,
                        ["y"] = 645,
                    },
                    ["autoscreenshot"] = false,
                    ["autoselectchatchannel"] = true,
                    ["chatLog"] = 
                    {
                        ["name"] = "CMX Combat Log",
                        ["enabled"] = false,
                        ["damageIn"] = false,
                        ["damageOut"] = true,
                        ["healingIn"] = false,
                        ["healingOut"] = false,
                    },
                    ["recordgrp"] = true,
                    ["SVsize"] = 0.0000381470,
                    ["showstacks"] = true,
                    ["crusherValue"] = 2108,
                    ["ForceNotification"] = false,
                    ["recordgrpinlarge"] = true,
                    ["accountwide"] = false,
                    ["keepbossfights"] = false,
                    ["FightReport"] = 
                    {
                        ["CLSelection"] = 
                        {
                            [16] = false,
                            [4] = true,
                            [5] = false,
                            [7] = false,
                            [8] = false,
                            [10] = false,
                            [11] = false,
                            [12] = false,
                            [13] = false,
                            [14] = false,
                            [15] = false,
                        },
                        ["rightpanel"] = "buffs",
                        ["PlotColors"] = 
                        {
                            [1] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 1,
                                [3] = 0,
                            },
                            [2] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 0,
                                [3] = 0,
                            },
                            [3] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 0,
                                [2] = 1,
                                [3] = 0,
                            },
                            [4] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 0,
                                [2] = 0,
                                [3] = 1,
                            },
                            [5] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 0,
                                [3] = 1,
                            },
                            [6] = 
                            {
                                [4] = 0.4000000000,
                                [1] = 0.4000000000,
                                [2] = 1,
                                [3] = 0.4000000000,
                            },
                            [7] = 
                            {
                                [4] = 0.4000000000,
                                [1] = 1,
                                [2] = 0.4000000000,
                                [3] = 0.9000000000,
                            },
                        },
                        ["scale"] = 1,
                        ["mainpanel"] = "FightStats",
                        ["showPets"] = true,
                        ["Cursor"] = true,
                        ["useDisplayNames"] = false,
                        ["hitCritLayout"] = 
                        {
                            ["healingOut"] = 1,
                            ["damageOut"] = 1,
                            ["healingIn"] = 1,
                            ["damageIn"] = 1,
                        },
                        ["averageLayout"] = 
                        {
                            ["healingOut"] = 1,
                            ["damageOut"] = 1,
                            ["healingIn"] = 1,
                            ["damageIn"] = 1,
                        },
                        ["ShowGroupBuffsInPlots"] = true,
                        ["showWereWolf"] = false,
                        ["category"] = "damageOut",
                        ["fightstatspanel"] = 1,
                        ["maxValue"] = 
                        {
                            ["healingOut"] = true,
                            ["damageOut"] = true,
                            ["healingIn"] = true,
                            ["damageIn"] = true,
                        },
                        ["SmoothWindow"] = 5,
                        ["FavouriteBuffs"] = 
                        {
                        },
                    },
                    ["liveReport"] = 
                    {
                        ["locked"] = false,
                        ["layout"] = "Compact",
                        ["enabled"] = true,
                        ["damageIn"] = true,
                        ["damageOutSingle"] = false,
                        ["time"] = true,
                        ["healOutAbsolute"] = false,
                        ["scale"] = 1,
                        ["alignmentleft"] = false,
                        ["healOut"] = true,
                        ["damageOut"] = true,
                        ["healIn"] = true,
                        ["bgalpha"] = 95,
                    },
                    ["maxSVsize"] = 10,
                    ["offincyrodil"] = false,
                    ["chunksize"] = 1000,
                    ["autoscreenshotmintime"] = 30,
                    ["fighthistory"] = 25,
                    ["tremorscaleValue"] = 2640,
                    ["unitresistance"] = 18200,
                    ["alkoshValue"] = 6000,
                    ["showDebugIds"] = false,
                    ["lightmodeincyrodil"] = true,
                    ["version"] = 5,
                    ["CombatMetrics_LiveReport"] = 
                    {
                        ["x"] = 700,
                        ["y"] = 500,
                    },
                    ["currentNotificationVersion"] = 0,
                    ["lightmode"] = false,
                    ["NotificationRead"] = 0,
                },
                ["$LastCharacterName"] = "Sweepy Mcsweeperson",
            },
        },
    },
}
