LostTreasure_Account =
{
    ["NA Megaserver"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["notifications"] = 
                {
                },
                ["mining"] = 
                {
                    ["APIVersion"] = 101038,
                    ["data"] = 
                    {
                    },
                    ["APITimeStamp"] = 1686264961,
                },
                ["version"] = 20,
                ["miniMap"] = 
                {
                    ["deletionDelay"] = 4,
                    ["size"] = 400,
                    ["enabled"] = true,
                    ["anchor"] = 
                    {
                        ["data"] = 
                        {
                            [1] = 3,
                            [3] = 3,
                            [4] = 100,
                            [5] = 100,
                            [6] = 0,
                        },
                    },
                },
                ["pinTypes"] = 
                {
                    ["treasure"] = 
                    {
                        ["deletionDelay"] = 10,
                        ["showOnMap"] = true,
                        ["pinLevel"] = 47,
                        ["markOption"] = "inventory",
                        ["showOnCompass"] = true,
                        ["size"] = 32,
                        ["texture"] = "LibTreasure/Icons/x_red.dds",
                    },
                    ["clue"] = 
                    {
                        ["deletionDelay"] = 10,
                        ["showOnMap"] = true,
                        ["pinLevel"] = 47,
                        ["markOption"] = "inventory",
                        ["showOnCompass"] = true,
                        ["size"] = 32,
                        ["texture"] = "LibTreasure/Icons/hammerstrike.dds",
                    },
                    ["survey"] = 
                    {
                        ["deletionDelay"] = 10,
                        ["showOnMap"] = true,
                        ["pinLevel"] = 47,
                        ["markOption"] = "inventory",
                        ["showOnCompass"] = true,
                        ["size"] = 32,
                        ["texture"] = "LibTreasure/Icons/hammerstrike.dds",
                    },
                },
                ["misc"] = 
                {
                    ["hasNewIconPath"] = true,
                },
            },
        },
    },
}
LostTreasure_Character =
{
    ["NA Megaserver"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["8796093060264765"] = 
            {
                ["$LastCharacterName"] = "Sweepy Mcsweeperson",
                ["LibSavedVars"] = 
                {
                    ["accountSavedVarsActive"] = true,
                },
                ["version"] = 20,
            },
        },
    },
}
