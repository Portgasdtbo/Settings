ZO_InternalIngame_SavedVariables =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["Tribute"] = 
                {
                    ["version"] = 1,
                    ["autoPlayChecked"] = false,
                },
            },
        },
    },
}
