WritWorthyVars =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["Bujin Yamato"] = 
            {
                ["enable_banked_vouchers"] = false,
                ["enable_station_colors"] = false,
                ["enable_mm_fallback"] = false,
                ["lang"] = false,
                ["enable_mat_price_tooltip"] = true,
                ["version"] = 1,
                ["enable_mat_list_chat"] = "Off",
                ["enable_mat_list_tooltip"] = "Off",
                ["writ_unique_id"] = 
                {
                },
                ["enable_lib_price"] = true,
            },
            ["Sorc deez Frags"] = 
            {
                ["enable_banked_vouchers"] = false,
                ["enable_station_colors"] = false,
                ["enable_mm_fallback"] = false,
                ["lang"] = false,
                ["enable_mat_price_tooltip"] = true,
                ["version"] = 1,
                ["enable_mat_list_chat"] = "Off",
                ["enable_mat_list_tooltip"] = "Off",
                ["writ_unique_id"] = 
                {
                },
                ["enable_lib_price"] = true,
            },
            ["His Swoliness"] = 
            {
                ["enable_banked_vouchers"] = false,
                ["enable_station_colors"] = false,
                ["enable_mm_fallback"] = false,
                ["lang"] = false,
                ["enable_mat_price_tooltip"] = true,
                ["version"] = 1,
                ["enable_mat_list_chat"] = "Off",
                ["enable_mat_list_tooltip"] = "Off",
                ["writ_unique_id"] = 
                {
                },
                ["enable_lib_price"] = true,
            },
            ["Sweepy Mcsweeperson"] = 
            {
                ["enable_banked_vouchers"] = false,
                ["enable_station_colors"] = false,
                ["enable_mm_fallback"] = false,
                ["lang"] = false,
                ["enable_mat_price_tooltip"] = true,
                ["version"] = 1,
                ["enable_mat_list_chat"] = "Off",
                ["enable_mat_list_tooltip"] = "Off",
                ["writ_unique_id"] = 
                {
                },
                ["enable_lib_price"] = true,
            },
            ["$AccountWide"] = 
            {
                ["position"] = 
                {
                    [2] = 50,
                    [1] = 50,
                },
                ["version"] = 1,
            },
            ["Big depression"] = 
            {
                ["enable_banked_vouchers"] = false,
                ["enable_station_colors"] = false,
                ["enable_mm_fallback"] = false,
                ["lang"] = false,
                ["enable_mat_price_tooltip"] = true,
                ["version"] = 1,
                ["enable_mat_list_chat"] = "Off",
                ["enable_mat_list_tooltip"] = "Off",
                ["writ_unique_id"] = 
                {
                },
                ["enable_lib_price"] = true,
            },
            ["Sneaky lil Snake"] = 
            {
                ["enable_banked_vouchers"] = false,
                ["enable_station_colors"] = false,
                ["enable_mm_fallback"] = false,
                ["lang"] = false,
                ["enable_mat_price_tooltip"] = true,
                ["writ_unique_id"] = 
                {
                },
                ["enable_mat_list_tooltip"] = "Off",
                ["enable_lib_price"] = true,
                ["version"] = 1,
                ["enable_mat_list_chat"] = "Off",
            },
        },
    },
}
