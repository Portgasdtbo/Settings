LibDebugLoggerSettings =
{
    ["loadScreenStartTime"] = 1686270265970,
    ["logTraces"] = false,
    ["minLogLevel"] = "I",
    ["version"] = 2,
}
LibDebugLoggerLog =
{
    [1] = 
    {
        [1] = 1686264950003,
        [2] = "2023-06-08 18:55:50.003 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@portgasdtbo\nSweepy Mcsweeperson\n2023-06-08 18:53:45.351 -0400\neso.live.9.0.5.2691744 (101038)\nNA Megaserver\nPC - Steam (win32)\nkeyboard\neso+\nen\nEnglish\naddon count: 37/37\nallow outdated\nfullscreen windowed (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [2] = 
    {
        [1] = 1686264952410,
        [2] = "2023-06-08 18:55:52.410 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [3] = 
    {
        [1] = 1686264952410,
        [2] = "2023-06-08 18:55:52.410 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [4] = 
    {
        [1] = 1686264952410,
        [2] = "2023-06-08 18:55:52.410 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [5] = 
    {
        [1] = 1686264952410,
        [2] = "2023-06-08 18:55:52.410 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [6] = 
    {
        [1] = 1686264952410,
        [2] = "2023-06-08 18:55:52.410 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [7] = 
    {
        [1] = 1686264952410,
        [2] = "2023-06-08 18:55:52.410 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [8] = 
    {
        [1] = 1686264952410,
        [2] = "2023-06-08 18:55:52.410 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [9] = 
    {
        [1] = 1686264952410,
        [2] = "2023-06-08 18:55:52.410 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [10] = 
    {
        [1] = 1686264952498,
        [2] = "2023-06-08 18:55:52.498 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [11] = 
    {
        [1] = 1686264952498,
        [2] = "2023-06-08 18:55:52.498 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 262, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [12] = 
    {
        [1] = 1686264952498,
        [2] = "2023-06-08 18:55:52.498 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [13] = 
    {
        [1] = 1686264952505,
        [2] = "2023-06-08 18:55:52.505 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [14] = 
    {
        [1] = 1686264952505,
        [2] = "2023-06-08 18:55:52.505 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [15] = 
    {
        [1] = 1686264952505,
        [2] = "2023-06-08 18:55:52.505 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [16] = 
    {
        [1] = 1686264952510,
        [2] = "2023-06-08 18:55:52.510 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [17] = 
    {
        [1] = 1686264952554,
        [2] = "2023-06-08 18:55:52.554 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [18] = 
    {
        [1] = 1686264952554,
        [2] = "2023-06-08 18:55:52.554 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [19] = 
    {
        [1] = 1686264952554,
        [2] = "2023-06-08 18:55:52.554 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1630, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [20] = 
    {
        [1] = 1686264953167,
        [2] = "2023-06-08 18:55:53.167 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [21] = 
    {
        [1] = 1686264953172,
        [2] = "2023-06-08 18:55:53.172 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DynamicCP, AddOnVersion: 0, directory: 'user:/AddOns/DynamicCP/'",
        [7] = "",
    },
    [22] = 
    {
        [1] = 1686264953196,
        [2] = "2023-06-08 18:55:53.196 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 69, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [23] = 
    {
        [1] = 1686264953196,
        [2] = "2023-06-08 18:55:53.196 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [24] = 
    {
        [1] = 1686264953196,
        [2] = "2023-06-08 18:55:53.196 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [25] = 
    {
        [1] = 1686264953196,
        [2] = "2023-06-08 18:55:53.196 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [26] = 
    {
        [1] = 1686264953196,
        [2] = "2023-06-08 18:55:53.196 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [27] = 
    {
        [1] = 1686264953197,
        [2] = "2023-06-08 18:55:53.197 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSlashCommander, AddOnVersion: 36, directory: 'user:/AddOns/LibSlashCommander/'",
        [7] = "",
    },
    [28] = 
    {
        [1] = 1686264953197,
        [2] = "2023-06-08 18:55:53.197 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 85, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [29] = 
    {
        [1] = 1686264953645,
        [2] = "2023-06-08 18:55:53.645 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [30] = 
    {
        [1] = 1686264953928,
        [2] = "2023-06-08 18:55:53.928 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [31] = 
    {
        [1] = 1686264953928,
        [2] = "2023-06-08 18:55:53.928 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [32] = 
    {
        [1] = 1686264953936,
        [2] = "2023-06-08 18:55:53.936 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: TamrielTradeCentre, AddOnVersion: 0, directory: 'user:/AddOns/TamrielTradeCentre/'",
        [7] = "",
    },
    [33] = 
    {
        [1] = 1686264954384,
        [2] = "2023-06-08 18:55:54.384 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [34] = 
    {
        [1] = 1686264959526,
        [2] = "2023-06-08 18:55:59.526 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BanditsUserInterface, AddOnVersion: 0, directory: 'user:/AddOns/BanditsUserInterface/'",
        [7] = "",
    },
    [35] = 
    {
        [1] = 1686264960699,
        [2] = "2023-06-08 18:56:00.699 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BeamMeUp, AddOnVersion: 345, directory: 'user:/AddOns/BeamMeUp/'",
        [7] = "",
    },
    [36] = 
    {
        [1] = 1686264960840,
        [2] = "2023-06-08 18:56:00.840 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [37] = 
    {
        [1] = 1686264960840,
        [2] = "2023-06-08 18:56:00.840 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [38] = 
    {
        [1] = 1686264960840,
        [2] = "2023-06-08 18:56:00.840 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 18, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [39] = 
    {
        [1] = 1686264960846,
        [2] = "2023-06-08 18:56:00.846 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: WritWorthy, AddOnVersion: 70307, directory: 'user:/AddOns/WritWorthy/'",
        [7] = "",
    },
    [40] = 
    {
        [1] = 1686264960876,
        [2] = "2023-06-08 18:56:00.876 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BattlegroundCoffers, AddOnVersion: 0, directory: 'user:/AddOns/BattlegroundCoffers/'",
        [7] = "",
    },
    [41] = 
    {
        [1] = 1686264961142,
        [2] = "2023-06-08 18:56:01.142 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [42] = 
    {
        [1] = 1686264961142,
        [2] = "2023-06-08 18:56:01.142 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [43] = 
    {
        [1] = 1686264961142,
        [2] = "2023-06-08 18:56:01.142 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 14, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [44] = 
    {
        [1] = 1686264961142,
        [2] = "2023-06-08 18:56:01.142 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LostTreasure, AddOnVersion: 28, directory: 'user:/AddOns/LostTreasure/'",
        [7] = "",
    },
    [45] = 
    {
        [1] = 1686264961142,
        [2] = "2023-06-08 18:56:01.142 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure/mining",
        [6] = "initialized: Mining is ACTIVE due to a new game API Version.",
        [7] = "",
    },
    [46] = 
    {
        [1] = 1686264961183,
        [2] = "2023-06-08 18:56:01.183 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30920, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [47] = 
    {
        [1] = 1686264961199,
        [2] = "2023-06-08 18:56:01.199 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [48] = 
    {
        [1] = 1686264961304,
        [2] = "2023-06-08 18:56:01.304 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: IIfA, AddOnVersion: 30065, directory: 'user:/AddOns/IIfA/'",
        [7] = "",
    },
    [49] = 
    {
        [1] = 1686264961619,
        [2] = "2023-06-08 18:56:01.619 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10514, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [50] = 
    {
        [1] = 1686264963037,
        [2] = "2023-06-08 18:56:03.037 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 13.037s)",
        [7] = "",
    },
    [51] = 
    {
        [1] = 1686264965328,
        [2] = "2023-06-08 18:56:05.328 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "LibLazyCrafting: Beginning scrape of set items. Estimated time: 34s",
        [7] = "",
    },
    [52] = 
    {
        [1] = 1686264965331,
        [2] = "2023-06-08 18:56:05.331 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "This is a (usually) once per major game update scan. Please wait until it it is complete.",
        [7] = "",
    },
    [53] = 
    {
        [1] = 1686265001256,
        [2] = "2023-06-08 18:56:41.256 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "LibLazyCrafting: Item Scrape complete",
        [7] = "",
    },
    [54] = 
    {
        [1] = 1686265195003,
        [2] = "2023-06-08 18:59:55.003 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@portgasdtbo\nSweepy Mcsweeperson\n2023-06-08 18:53:45.748 -0400\neso.live.9.0.5.2691744 (101038)\nNA Megaserver\nPC - Steam (win32)\nkeyboard\neso+\nen\nEnglish\naddon count: 37/37\nallow outdated\nfullscreen windowed (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [55] = 
    {
        [1] = 1686265197420,
        [2] = "2023-06-08 18:59:57.420 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [56] = 
    {
        [1] = 1686265197421,
        [2] = "2023-06-08 18:59:57.421 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [57] = 
    {
        [1] = 1686265197421,
        [2] = "2023-06-08 18:59:57.421 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [58] = 
    {
        [1] = 1686265197421,
        [2] = "2023-06-08 18:59:57.421 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [59] = 
    {
        [1] = 1686265197421,
        [2] = "2023-06-08 18:59:57.421 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [60] = 
    {
        [1] = 1686265197421,
        [2] = "2023-06-08 18:59:57.421 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [61] = 
    {
        [1] = 1686265197421,
        [2] = "2023-06-08 18:59:57.421 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [62] = 
    {
        [1] = 1686265197421,
        [2] = "2023-06-08 18:59:57.421 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [63] = 
    {
        [1] = 1686265197505,
        [2] = "2023-06-08 18:59:57.505 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [64] = 
    {
        [1] = 1686265197505,
        [2] = "2023-06-08 18:59:57.505 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 262, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [65] = 
    {
        [1] = 1686265197505,
        [2] = "2023-06-08 18:59:57.505 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [66] = 
    {
        [1] = 1686265197513,
        [2] = "2023-06-08 18:59:57.513 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [67] = 
    {
        [1] = 1686265197513,
        [2] = "2023-06-08 18:59:57.513 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [68] = 
    {
        [1] = 1686265197513,
        [2] = "2023-06-08 18:59:57.513 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [69] = 
    {
        [1] = 1686265197517,
        [2] = "2023-06-08 18:59:57.517 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [70] = 
    {
        [1] = 1686265197562,
        [2] = "2023-06-08 18:59:57.562 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [71] = 
    {
        [1] = 1686265197562,
        [2] = "2023-06-08 18:59:57.562 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [72] = 
    {
        [1] = 1686265197562,
        [2] = "2023-06-08 18:59:57.562 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1630, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [73] = 
    {
        [1] = 1686265198057,
        [2] = "2023-06-08 18:59:58.057 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [74] = 
    {
        [1] = 1686265198062,
        [2] = "2023-06-08 18:59:58.062 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DynamicCP, AddOnVersion: 0, directory: 'user:/AddOns/DynamicCP/'",
        [7] = "",
    },
    [75] = 
    {
        [1] = 1686265198075,
        [2] = "2023-06-08 18:59:58.075 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 69, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [76] = 
    {
        [1] = 1686265198075,
        [2] = "2023-06-08 18:59:58.075 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [77] = 
    {
        [1] = 1686265198075,
        [2] = "2023-06-08 18:59:58.075 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [78] = 
    {
        [1] = 1686265198075,
        [2] = "2023-06-08 18:59:58.075 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [79] = 
    {
        [1] = 1686265198075,
        [2] = "2023-06-08 18:59:58.075 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [80] = 
    {
        [1] = 1686265198076,
        [2] = "2023-06-08 18:59:58.076 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSlashCommander, AddOnVersion: 36, directory: 'user:/AddOns/LibSlashCommander/'",
        [7] = "",
    },
    [81] = 
    {
        [1] = 1686265198076,
        [2] = "2023-06-08 18:59:58.076 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 85, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [82] = 
    {
        [1] = 1686265198501,
        [2] = "2023-06-08 18:59:58.501 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [83] = 
    {
        [1] = 1686265198752,
        [2] = "2023-06-08 18:59:58.752 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [84] = 
    {
        [1] = 1686265198752,
        [2] = "2023-06-08 18:59:58.752 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [85] = 
    {
        [1] = 1686265198757,
        [2] = "2023-06-08 18:59:58.757 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: TamrielTradeCentre, AddOnVersion: 0, directory: 'user:/AddOns/TamrielTradeCentre/'",
        [7] = "",
    },
    [86] = 
    {
        [1] = 1686265199156,
        [2] = "2023-06-08 18:59:59.156 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [87] = 
    {
        [1] = 1686265203855,
        [2] = "2023-06-08 19:00:03.855 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BanditsUserInterface, AddOnVersion: 0, directory: 'user:/AddOns/BanditsUserInterface/'",
        [7] = "",
    },
    [88] = 
    {
        [1] = 1686265204982,
        [2] = "2023-06-08 19:00:04.982 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BeamMeUp, AddOnVersion: 345, directory: 'user:/AddOns/BeamMeUp/'",
        [7] = "",
    },
    [89] = 
    {
        [1] = 1686265205119,
        [2] = "2023-06-08 19:00:05.119 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [90] = 
    {
        [1] = 1686265205119,
        [2] = "2023-06-08 19:00:05.119 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [91] = 
    {
        [1] = 1686265205119,
        [2] = "2023-06-08 19:00:05.119 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 18, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [92] = 
    {
        [1] = 1686265205125,
        [2] = "2023-06-08 19:00:05.125 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: WritWorthy, AddOnVersion: 70307, directory: 'user:/AddOns/WritWorthy/'",
        [7] = "",
    },
    [93] = 
    {
        [1] = 1686265205156,
        [2] = "2023-06-08 19:00:05.156 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BattlegroundCoffers, AddOnVersion: 0, directory: 'user:/AddOns/BattlegroundCoffers/'",
        [7] = "",
    },
    [94] = 
    {
        [1] = 1686265205438,
        [2] = "2023-06-08 19:00:05.438 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [95] = 
    {
        [1] = 1686265205438,
        [2] = "2023-06-08 19:00:05.438 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [96] = 
    {
        [1] = 1686265205438,
        [2] = "2023-06-08 19:00:05.438 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 14, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [97] = 
    {
        [1] = 1686265205438,
        [2] = "2023-06-08 19:00:05.438 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LostTreasure, AddOnVersion: 28, directory: 'user:/AddOns/LostTreasure/'",
        [7] = "",
    },
    [98] = 
    {
        [1] = 1686265205439,
        [2] = "2023-06-08 19:00:05.439 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure/mining",
        [6] = "initialized: Mining is ACTIVE within active mining time.",
        [7] = "",
    },
    [99] = 
    {
        [1] = 1686265205481,
        [2] = "2023-06-08 19:00:05.481 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30920, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [100] = 
    {
        [1] = 1686265205497,
        [2] = "2023-06-08 19:00:05.497 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [101] = 
    {
        [1] = 1686265205596,
        [2] = "2023-06-08 19:00:05.596 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: IIfA, AddOnVersion: 30065, directory: 'user:/AddOns/IIfA/'",
        [7] = "",
    },
    [102] = 
    {
        [1] = 1686265205871,
        [2] = "2023-06-08 19:00:05.871 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10514, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [103] = 
    {
        [1] = 1686265206645,
        [2] = "2023-06-08 19:00:06.645 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Loading screen ended (duration: 18.792s)",
        [7] = "",
    },
    [104] = 
    {
        [1] = 1686266834072,
        [2] = "2023-06-08 19:27:14.072 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure",
        [6] = "Invalid interaction. pinType survey, interactionType 6, sceneName bank",
        [7] = "",
    },
    [105] = 
    {
        [1] = 1686266920229,
        [2] = "2023-06-08 19:28:40.229 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [106] = 
    {
        [1] = 1686266958836,
        [2] = "2023-06-08 19:29:18.836 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [107] = 
    {
        [1] = 1686266962149,
        [2] = "2023-06-08 19:29:22.149 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can only deposit one of that item, and already have one in your bank.",
        [7] = "",
    },
    [108] = 
    {
        [1] = 1686266971287,
        [2] = "2023-06-08 19:29:31.287 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can only deposit one of that item, and already have one in your bank.",
        [7] = "",
    },
    [109] = 
    {
        [1] = 1686266974065,
        [2] = "2023-06-08 19:29:34.065 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [110] = 
    {
        [1] = 1686266987016,
        [2] = "2023-06-08 19:29:47.016 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure",
        [6] = "Invalid interaction. pinType survey, interactionType 6, sceneName bank",
        [7] = "",
    },
    [111] = 
    {
        [1] = 1686266997365,
        [2] = "2023-06-08 19:29:57.365 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [112] = 
    {
        [1] = 1686267006188,
        [2] = "2023-06-08 19:30:06.188 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure",
        [6] = "Invalid interaction. pinType treasure, interactionType 6, sceneName bank",
        [7] = "",
    },
    [113] = 
    {
        [1] = 1686267069003,
        [2] = "2023-06-08 19:31:09.003 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@portgasdtbo\nSorc deez Frags\n2023-06-08 18:53:46.073 -0400\neso.live.9.0.5.2691744 (101038)\nNA Megaserver\nPC - Steam (win32)\nkeyboard\neso+\nen\nEnglish\naddon count: 37/37\nallow outdated\nfullscreen windowed (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [114] = 
    {
        [1] = 1686267071660,
        [2] = "2023-06-08 19:31:11.660 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [115] = 
    {
        [1] = 1686267071660,
        [2] = "2023-06-08 19:31:11.660 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [116] = 
    {
        [1] = 1686267071660,
        [2] = "2023-06-08 19:31:11.660 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [117] = 
    {
        [1] = 1686267071661,
        [2] = "2023-06-08 19:31:11.661 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [118] = 
    {
        [1] = 1686267071661,
        [2] = "2023-06-08 19:31:11.661 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [119] = 
    {
        [1] = 1686267071661,
        [2] = "2023-06-08 19:31:11.661 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [120] = 
    {
        [1] = 1686267071661,
        [2] = "2023-06-08 19:31:11.661 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [121] = 
    {
        [1] = 1686267071661,
        [2] = "2023-06-08 19:31:11.661 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [122] = 
    {
        [1] = 1686267071743,
        [2] = "2023-06-08 19:31:11.743 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [123] = 
    {
        [1] = 1686267071743,
        [2] = "2023-06-08 19:31:11.743 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 262, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [124] = 
    {
        [1] = 1686267071743,
        [2] = "2023-06-08 19:31:11.743 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [125] = 
    {
        [1] = 1686267071750,
        [2] = "2023-06-08 19:31:11.750 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [126] = 
    {
        [1] = 1686267071750,
        [2] = "2023-06-08 19:31:11.750 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [127] = 
    {
        [1] = 1686267071750,
        [2] = "2023-06-08 19:31:11.750 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [128] = 
    {
        [1] = 1686267071754,
        [2] = "2023-06-08 19:31:11.754 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [129] = 
    {
        [1] = 1686267071802,
        [2] = "2023-06-08 19:31:11.802 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [130] = 
    {
        [1] = 1686267071802,
        [2] = "2023-06-08 19:31:11.802 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [131] = 
    {
        [1] = 1686267071802,
        [2] = "2023-06-08 19:31:11.802 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1630, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [132] = 
    {
        [1] = 1686267072299,
        [2] = "2023-06-08 19:31:12.299 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [133] = 
    {
        [1] = 1686267072304,
        [2] = "2023-06-08 19:31:12.304 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DynamicCP, AddOnVersion: 0, directory: 'user:/AddOns/DynamicCP/'",
        [7] = "",
    },
    [134] = 
    {
        [1] = 1686267072317,
        [2] = "2023-06-08 19:31:12.317 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 69, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [135] = 
    {
        [1] = 1686267072317,
        [2] = "2023-06-08 19:31:12.317 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [136] = 
    {
        [1] = 1686267072317,
        [2] = "2023-06-08 19:31:12.317 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [137] = 
    {
        [1] = 1686267072317,
        [2] = "2023-06-08 19:31:12.317 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [138] = 
    {
        [1] = 1686267072317,
        [2] = "2023-06-08 19:31:12.317 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [139] = 
    {
        [1] = 1686267072318,
        [2] = "2023-06-08 19:31:12.318 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSlashCommander, AddOnVersion: 36, directory: 'user:/AddOns/LibSlashCommander/'",
        [7] = "",
    },
    [140] = 
    {
        [1] = 1686267072318,
        [2] = "2023-06-08 19:31:12.318 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 85, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [141] = 
    {
        [1] = 1686267072754,
        [2] = "2023-06-08 19:31:12.754 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [142] = 
    {
        [1] = 1686267073014,
        [2] = "2023-06-08 19:31:13.014 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [143] = 
    {
        [1] = 1686267073014,
        [2] = "2023-06-08 19:31:13.014 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [144] = 
    {
        [1] = 1686267073020,
        [2] = "2023-06-08 19:31:13.020 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: TamrielTradeCentre, AddOnVersion: 0, directory: 'user:/AddOns/TamrielTradeCentre/'",
        [7] = "",
    },
    [145] = 
    {
        [1] = 1686267073432,
        [2] = "2023-06-08 19:31:13.432 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [146] = 
    {
        [1] = 1686267078286,
        [2] = "2023-06-08 19:31:18.286 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BanditsUserInterface, AddOnVersion: 0, directory: 'user:/AddOns/BanditsUserInterface/'",
        [7] = "",
    },
    [147] = 
    {
        [1] = 1686267079396,
        [2] = "2023-06-08 19:31:19.396 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BeamMeUp, AddOnVersion: 345, directory: 'user:/AddOns/BeamMeUp/'",
        [7] = "",
    },
    [148] = 
    {
        [1] = 1686267079546,
        [2] = "2023-06-08 19:31:19.546 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [149] = 
    {
        [1] = 1686267079546,
        [2] = "2023-06-08 19:31:19.546 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [150] = 
    {
        [1] = 1686267079546,
        [2] = "2023-06-08 19:31:19.546 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 18, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [151] = 
    {
        [1] = 1686267079552,
        [2] = "2023-06-08 19:31:19.552 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: WritWorthy, AddOnVersion: 70307, directory: 'user:/AddOns/WritWorthy/'",
        [7] = "",
    },
    [152] = 
    {
        [1] = 1686267079713,
        [2] = "2023-06-08 19:31:19.713 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BattlegroundCoffers, AddOnVersion: 0, directory: 'user:/AddOns/BattlegroundCoffers/'",
        [7] = "",
    },
    [153] = 
    {
        [1] = 1686267080004,
        [2] = "2023-06-08 19:31:20.004 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [154] = 
    {
        [1] = 1686267080004,
        [2] = "2023-06-08 19:31:20.004 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [155] = 
    {
        [1] = 1686267080004,
        [2] = "2023-06-08 19:31:20.004 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 14, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [156] = 
    {
        [1] = 1686267080004,
        [2] = "2023-06-08 19:31:20.004 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LostTreasure, AddOnVersion: 28, directory: 'user:/AddOns/LostTreasure/'",
        [7] = "",
    },
    [157] = 
    {
        [1] = 1686267080005,
        [2] = "2023-06-08 19:31:20.005 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure/mining",
        [6] = "initialized: Mining is ACTIVE within active mining time.",
        [7] = "",
    },
    [158] = 
    {
        [1] = 1686267080043,
        [2] = "2023-06-08 19:31:20.043 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30920, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [159] = 
    {
        [1] = 1686267080058,
        [2] = "2023-06-08 19:31:20.058 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [160] = 
    {
        [1] = 1686267080154,
        [2] = "2023-06-08 19:31:20.154 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: IIfA, AddOnVersion: 30065, directory: 'user:/AddOns/IIfA/'",
        [7] = "",
    },
    [161] = 
    {
        [1] = 1686267080474,
        [2] = "2023-06-08 19:31:20.474 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10514, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [162] = 
    {
        [1] = 1686267081895,
        [2] = "2023-06-08 19:31:21.895 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.895s)",
        [7] = "",
    },
    [163] = 
    {
        [1] = 1686267219771,
        [2] = "2023-06-08 19:33:39.771 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "This collectible is not ready yet.",
        [7] = "",
    },
    [164] = 
    {
        [1] = 1686267222245,
        [2] = "2023-06-08 19:33:42.245 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "This collectible is not ready yet.",
        [7] = "",
    },
    [165] = 
    {
        [1] = 1686267392003,
        [2] = "2023-06-08 19:36:32.003 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@portgasdtbo\nBujin Yamato\n2023-06-08 18:53:45.782 -0400\neso.live.9.0.5.2691744 (101038)\nNA Megaserver\nPC - Steam (win32)\nkeyboard\neso+\nen\nEnglish\naddon count: 37/37\nallow outdated\nfullscreen windowed (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [166] = 
    {
        [1] = 1686267394470,
        [2] = "2023-06-08 19:36:34.470 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [167] = 
    {
        [1] = 1686267394471,
        [2] = "2023-06-08 19:36:34.471 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [168] = 
    {
        [1] = 1686267394476,
        [2] = "2023-06-08 19:36:34.476 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [169] = 
    {
        [1] = 1686267394478,
        [2] = "2023-06-08 19:36:34.478 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [170] = 
    {
        [1] = 1686267394478,
        [2] = "2023-06-08 19:36:34.478 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [171] = 
    {
        [1] = 1686267394478,
        [2] = "2023-06-08 19:36:34.478 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [172] = 
    {
        [1] = 1686267394478,
        [2] = "2023-06-08 19:36:34.478 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [173] = 
    {
        [1] = 1686267394478,
        [2] = "2023-06-08 19:36:34.478 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [174] = 
    {
        [1] = 1686267394573,
        [2] = "2023-06-08 19:36:34.573 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [175] = 
    {
        [1] = 1686267394573,
        [2] = "2023-06-08 19:36:34.573 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 262, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [176] = 
    {
        [1] = 1686267394573,
        [2] = "2023-06-08 19:36:34.573 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [177] = 
    {
        [1] = 1686267394581,
        [2] = "2023-06-08 19:36:34.581 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [178] = 
    {
        [1] = 1686267394581,
        [2] = "2023-06-08 19:36:34.581 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [179] = 
    {
        [1] = 1686267394581,
        [2] = "2023-06-08 19:36:34.581 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [180] = 
    {
        [1] = 1686267394586,
        [2] = "2023-06-08 19:36:34.586 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [181] = 
    {
        [1] = 1686267394643,
        [2] = "2023-06-08 19:36:34.643 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [182] = 
    {
        [1] = 1686267394643,
        [2] = "2023-06-08 19:36:34.643 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [183] = 
    {
        [1] = 1686267394643,
        [2] = "2023-06-08 19:36:34.643 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1630, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [184] = 
    {
        [1] = 1686267395331,
        [2] = "2023-06-08 19:36:35.331 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [185] = 
    {
        [1] = 1686267395336,
        [2] = "2023-06-08 19:36:35.336 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DynamicCP, AddOnVersion: 0, directory: 'user:/AddOns/DynamicCP/'",
        [7] = "",
    },
    [186] = 
    {
        [1] = 1686267395355,
        [2] = "2023-06-08 19:36:35.355 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 69, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [187] = 
    {
        [1] = 1686267395355,
        [2] = "2023-06-08 19:36:35.355 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [188] = 
    {
        [1] = 1686267395355,
        [2] = "2023-06-08 19:36:35.355 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [189] = 
    {
        [1] = 1686267395355,
        [2] = "2023-06-08 19:36:35.355 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [190] = 
    {
        [1] = 1686267395355,
        [2] = "2023-06-08 19:36:35.355 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [191] = 
    {
        [1] = 1686267395356,
        [2] = "2023-06-08 19:36:35.356 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSlashCommander, AddOnVersion: 36, directory: 'user:/AddOns/LibSlashCommander/'",
        [7] = "",
    },
    [192] = 
    {
        [1] = 1686267395356,
        [2] = "2023-06-08 19:36:35.356 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 85, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [193] = 
    {
        [1] = 1686267395801,
        [2] = "2023-06-08 19:36:35.801 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [194] = 
    {
        [1] = 1686267396047,
        [2] = "2023-06-08 19:36:36.047 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [195] = 
    {
        [1] = 1686267396047,
        [2] = "2023-06-08 19:36:36.047 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [196] = 
    {
        [1] = 1686267396053,
        [2] = "2023-06-08 19:36:36.053 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: TamrielTradeCentre, AddOnVersion: 0, directory: 'user:/AddOns/TamrielTradeCentre/'",
        [7] = "",
    },
    [197] = 
    {
        [1] = 1686267396457,
        [2] = "2023-06-08 19:36:36.457 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [198] = 
    {
        [1] = 1686267401143,
        [2] = "2023-06-08 19:36:41.143 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BanditsUserInterface, AddOnVersion: 0, directory: 'user:/AddOns/BanditsUserInterface/'",
        [7] = "",
    },
    [199] = 
    {
        [1] = 1686267402255,
        [2] = "2023-06-08 19:36:42.255 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BeamMeUp, AddOnVersion: 345, directory: 'user:/AddOns/BeamMeUp/'",
        [7] = "",
    },
    [200] = 
    {
        [1] = 1686267402395,
        [2] = "2023-06-08 19:36:42.395 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [201] = 
    {
        [1] = 1686267402395,
        [2] = "2023-06-08 19:36:42.395 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [202] = 
    {
        [1] = 1686267402395,
        [2] = "2023-06-08 19:36:42.395 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 18, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [203] = 
    {
        [1] = 1686267402401,
        [2] = "2023-06-08 19:36:42.401 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: WritWorthy, AddOnVersion: 70307, directory: 'user:/AddOns/WritWorthy/'",
        [7] = "",
    },
    [204] = 
    {
        [1] = 1686267402452,
        [2] = "2023-06-08 19:36:42.452 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BattlegroundCoffers, AddOnVersion: 0, directory: 'user:/AddOns/BattlegroundCoffers/'",
        [7] = "",
    },
    [205] = 
    {
        [1] = 1686267402704,
        [2] = "2023-06-08 19:36:42.704 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [206] = 
    {
        [1] = 1686267402704,
        [2] = "2023-06-08 19:36:42.704 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [207] = 
    {
        [1] = 1686267402704,
        [2] = "2023-06-08 19:36:42.704 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 14, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [208] = 
    {
        [1] = 1686267402704,
        [2] = "2023-06-08 19:36:42.704 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LostTreasure, AddOnVersion: 28, directory: 'user:/AddOns/LostTreasure/'",
        [7] = "",
    },
    [209] = 
    {
        [1] = 1686267402706,
        [2] = "2023-06-08 19:36:42.706 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure/mining",
        [6] = "initialized: Mining is ACTIVE within active mining time.",
        [7] = "",
    },
    [210] = 
    {
        [1] = 1686267402757,
        [2] = "2023-06-08 19:36:42.757 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30920, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [211] = 
    {
        [1] = 1686267402781,
        [2] = "2023-06-08 19:36:42.781 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [212] = 
    {
        [1] = 1686267402883,
        [2] = "2023-06-08 19:36:42.883 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: IIfA, AddOnVersion: 30065, directory: 'user:/AddOns/IIfA/'",
        [7] = "",
    },
    [213] = 
    {
        [1] = 1686267403215,
        [2] = "2023-06-08 19:36:43.215 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10514, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [214] = 
    {
        [1] = 1686267404526,
        [2] = "2023-06-08 19:36:44.526 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.526s)",
        [7] = "",
    },
    [215] = 
    {
        [1] = 1686267497319,
        [2] = "2023-06-08 19:38:17.319 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "|cAAAAAAGained 1 champion point|r",
        [7] = "",
    },
    [216] = 
    {
        [1] = 1686267499791,
        [2] = "2023-06-08 19:38:19.791 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure",
        [6] = "Invalid interaction. pinType survey, interactionType 0, sceneName hud",
        [7] = "",
    },
    [217] = 
    {
        [1] = 1686267516882,
        [2] = "2023-06-08 19:38:36.882 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure",
        [6] = "Invalid interaction. pinType survey, interactionType 0, sceneName hud",
        [7] = "",
    },
    [218] = 
    {
        [1] = 1686267652637,
        [2] = "2023-06-08 19:40:52.637 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [219] = 
    {
        [1] = 1686267839004,
        [2] = "2023-06-08 19:43:59.004 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@portgasdtbo\nHis Swoliness\n2023-06-08 18:53:46.185 -0400\neso.live.9.0.5.2691744 (101038)\nNA Megaserver\nPC - Steam (win32)\nkeyboard\neso+\nen\nEnglish\naddon count: 37/37\nallow outdated\nfullscreen windowed (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [220] = 
    {
        [1] = 1686267841529,
        [2] = "2023-06-08 19:44:01.529 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [221] = 
    {
        [1] = 1686267841529,
        [2] = "2023-06-08 19:44:01.529 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [222] = 
    {
        [1] = 1686267841529,
        [2] = "2023-06-08 19:44:01.529 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [223] = 
    {
        [1] = 1686267841529,
        [2] = "2023-06-08 19:44:01.529 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [224] = 
    {
        [1] = 1686267841529,
        [2] = "2023-06-08 19:44:01.529 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [225] = 
    {
        [1] = 1686267841529,
        [2] = "2023-06-08 19:44:01.529 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [226] = 
    {
        [1] = 1686267841529,
        [2] = "2023-06-08 19:44:01.529 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [227] = 
    {
        [1] = 1686267841529,
        [2] = "2023-06-08 19:44:01.529 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [228] = 
    {
        [1] = 1686267841601,
        [2] = "2023-06-08 19:44:01.601 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [229] = 
    {
        [1] = 1686267841601,
        [2] = "2023-06-08 19:44:01.601 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 262, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [230] = 
    {
        [1] = 1686267841601,
        [2] = "2023-06-08 19:44:01.601 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [231] = 
    {
        [1] = 1686267841610,
        [2] = "2023-06-08 19:44:01.610 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [232] = 
    {
        [1] = 1686267841610,
        [2] = "2023-06-08 19:44:01.610 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [233] = 
    {
        [1] = 1686267841610,
        [2] = "2023-06-08 19:44:01.610 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [234] = 
    {
        [1] = 1686267841615,
        [2] = "2023-06-08 19:44:01.615 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [235] = 
    {
        [1] = 1686267841673,
        [2] = "2023-06-08 19:44:01.673 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [236] = 
    {
        [1] = 1686267841673,
        [2] = "2023-06-08 19:44:01.673 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [237] = 
    {
        [1] = 1686267841673,
        [2] = "2023-06-08 19:44:01.673 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1630, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [238] = 
    {
        [1] = 1686267842155,
        [2] = "2023-06-08 19:44:02.155 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [239] = 
    {
        [1] = 1686267842160,
        [2] = "2023-06-08 19:44:02.160 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DynamicCP, AddOnVersion: 0, directory: 'user:/AddOns/DynamicCP/'",
        [7] = "",
    },
    [240] = 
    {
        [1] = 1686267842173,
        [2] = "2023-06-08 19:44:02.173 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 69, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [241] = 
    {
        [1] = 1686267842173,
        [2] = "2023-06-08 19:44:02.173 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [242] = 
    {
        [1] = 1686267842173,
        [2] = "2023-06-08 19:44:02.173 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [243] = 
    {
        [1] = 1686267842173,
        [2] = "2023-06-08 19:44:02.173 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [244] = 
    {
        [1] = 1686267842173,
        [2] = "2023-06-08 19:44:02.173 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [245] = 
    {
        [1] = 1686267842173,
        [2] = "2023-06-08 19:44:02.173 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSlashCommander, AddOnVersion: 36, directory: 'user:/AddOns/LibSlashCommander/'",
        [7] = "",
    },
    [246] = 
    {
        [1] = 1686267842174,
        [2] = "2023-06-08 19:44:02.174 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 85, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [247] = 
    {
        [1] = 1686267842623,
        [2] = "2023-06-08 19:44:02.623 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [248] = 
    {
        [1] = 1686267842877,
        [2] = "2023-06-08 19:44:02.877 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [249] = 
    {
        [1] = 1686267842877,
        [2] = "2023-06-08 19:44:02.877 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [250] = 
    {
        [1] = 1686267842882,
        [2] = "2023-06-08 19:44:02.882 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: TamrielTradeCentre, AddOnVersion: 0, directory: 'user:/AddOns/TamrielTradeCentre/'",
        [7] = "",
    },
    [251] = 
    {
        [1] = 1686267843260,
        [2] = "2023-06-08 19:44:03.260 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [252] = 
    {
        [1] = 1686267848058,
        [2] = "2023-06-08 19:44:08.058 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BanditsUserInterface, AddOnVersion: 0, directory: 'user:/AddOns/BanditsUserInterface/'",
        [7] = "",
    },
    [253] = 
    {
        [1] = 1686267849155,
        [2] = "2023-06-08 19:44:09.155 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BeamMeUp, AddOnVersion: 345, directory: 'user:/AddOns/BeamMeUp/'",
        [7] = "",
    },
    [254] = 
    {
        [1] = 1686267849295,
        [2] = "2023-06-08 19:44:09.295 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [255] = 
    {
        [1] = 1686267849295,
        [2] = "2023-06-08 19:44:09.295 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [256] = 
    {
        [1] = 1686267849295,
        [2] = "2023-06-08 19:44:09.295 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 18, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [257] = 
    {
        [1] = 1686267849301,
        [2] = "2023-06-08 19:44:09.301 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: WritWorthy, AddOnVersion: 70307, directory: 'user:/AddOns/WritWorthy/'",
        [7] = "",
    },
    [258] = 
    {
        [1] = 1686267849378,
        [2] = "2023-06-08 19:44:09.378 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BattlegroundCoffers, AddOnVersion: 0, directory: 'user:/AddOns/BattlegroundCoffers/'",
        [7] = "",
    },
    [259] = 
    {
        [1] = 1686267849661,
        [2] = "2023-06-08 19:44:09.661 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [260] = 
    {
        [1] = 1686267849661,
        [2] = "2023-06-08 19:44:09.661 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [261] = 
    {
        [1] = 1686267849661,
        [2] = "2023-06-08 19:44:09.661 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 14, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [262] = 
    {
        [1] = 1686267849661,
        [2] = "2023-06-08 19:44:09.661 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LostTreasure, AddOnVersion: 28, directory: 'user:/AddOns/LostTreasure/'",
        [7] = "",
    },
    [263] = 
    {
        [1] = 1686267849662,
        [2] = "2023-06-08 19:44:09.662 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure/mining",
        [6] = "initialized: Mining is ACTIVE within active mining time.",
        [7] = "",
    },
    [264] = 
    {
        [1] = 1686267849703,
        [2] = "2023-06-08 19:44:09.703 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30920, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [265] = 
    {
        [1] = 1686267849722,
        [2] = "2023-06-08 19:44:09.722 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [266] = 
    {
        [1] = 1686267849837,
        [2] = "2023-06-08 19:44:09.837 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: IIfA, AddOnVersion: 30065, directory: 'user:/AddOns/IIfA/'",
        [7] = "",
    },
    [267] = 
    {
        [1] = 1686267850167,
        [2] = "2023-06-08 19:44:10.167 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10514, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [268] = 
    {
        [1] = 1686267851655,
        [2] = "2023-06-08 19:44:11.655 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.655s)",
        [7] = "",
    },
    [269] = 
    {
        [1] = 1686268061768,
        [2] = "2023-06-08 19:47:41.768 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "This collectible is not ready yet.",
        [7] = "",
    },
    [270] = 
    {
        [1] = 1686268063022,
        [2] = "2023-06-08 19:47:43.022 -0400",
        [3] = 4,
        [4] = "W",
        [5] = "UI",
        [6] = "This collectible is not ready yet.",
        [7] = "",
    },
    [271] = 
    {
        [1] = 1686268078251,
        [2] = "2023-06-08 19:47:58.251 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure",
        [6] = "Invalid interaction. pinType survey, interactionType 6, sceneName bank",
        [7] = "",
    },
    [272] = 
    {
        [1] = 1686268102718,
        [2] = "2023-06-08 19:48:22.718 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure",
        [6] = "Invalid interaction. pinType survey, interactionType 6, sceneName bank",
        [7] = "",
    },
    [273] = 
    {
        [1] = 1686268106317,
        [2] = "2023-06-08 19:48:26.317 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can only deposit one of that item, and already have one in your bank.",
        [7] = "",
    },
    [274] = 
    {
        [1] = 1686268121417,
        [2] = "2023-06-08 19:48:41.417 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [275] = 
    {
        [1] = 1686268127413,
        [2] = "2023-06-08 19:48:47.413 -0400",
        [3] = 2,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [276] = 
    {
        [1] = 1686268219003,
        [2] = "2023-06-08 19:50:19.003 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@portgasdtbo\nHis Swoliness\n2023-06-08 18:53:46.144 -0400\neso.live.9.0.5.2691744 (101038)\nNA Megaserver\nPC - Steam (win32)\nkeyboard\neso+\nen\nEnglish\naddon count: 37/37\nallow outdated\nfullscreen windowed (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [277] = 
    {
        [1] = 1686268221540,
        [2] = "2023-06-08 19:50:21.540 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [278] = 
    {
        [1] = 1686268221541,
        [2] = "2023-06-08 19:50:21.541 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [279] = 
    {
        [1] = 1686268221541,
        [2] = "2023-06-08 19:50:21.541 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [280] = 
    {
        [1] = 1686268221541,
        [2] = "2023-06-08 19:50:21.541 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [281] = 
    {
        [1] = 1686268221541,
        [2] = "2023-06-08 19:50:21.541 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [282] = 
    {
        [1] = 1686268221541,
        [2] = "2023-06-08 19:50:21.541 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [283] = 
    {
        [1] = 1686268221541,
        [2] = "2023-06-08 19:50:21.541 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [284] = 
    {
        [1] = 1686268221541,
        [2] = "2023-06-08 19:50:21.541 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [285] = 
    {
        [1] = 1686268221615,
        [2] = "2023-06-08 19:50:21.615 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [286] = 
    {
        [1] = 1686268221615,
        [2] = "2023-06-08 19:50:21.615 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 262, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [287] = 
    {
        [1] = 1686268221615,
        [2] = "2023-06-08 19:50:21.615 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [288] = 
    {
        [1] = 1686268221623,
        [2] = "2023-06-08 19:50:21.623 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [289] = 
    {
        [1] = 1686268221623,
        [2] = "2023-06-08 19:50:21.623 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [290] = 
    {
        [1] = 1686268221624,
        [2] = "2023-06-08 19:50:21.624 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [291] = 
    {
        [1] = 1686268221628,
        [2] = "2023-06-08 19:50:21.628 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [292] = 
    {
        [1] = 1686268221693,
        [2] = "2023-06-08 19:50:21.693 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [293] = 
    {
        [1] = 1686268221693,
        [2] = "2023-06-08 19:50:21.693 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [294] = 
    {
        [1] = 1686268221693,
        [2] = "2023-06-08 19:50:21.693 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1630, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [295] = 
    {
        [1] = 1686268222193,
        [2] = "2023-06-08 19:50:22.193 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [296] = 
    {
        [1] = 1686268222199,
        [2] = "2023-06-08 19:50:22.199 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DynamicCP, AddOnVersion: 0, directory: 'user:/AddOns/DynamicCP/'",
        [7] = "",
    },
    [297] = 
    {
        [1] = 1686268222213,
        [2] = "2023-06-08 19:50:22.213 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 69, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [298] = 
    {
        [1] = 1686268222213,
        [2] = "2023-06-08 19:50:22.213 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [299] = 
    {
        [1] = 1686268222213,
        [2] = "2023-06-08 19:50:22.213 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [300] = 
    {
        [1] = 1686268222213,
        [2] = "2023-06-08 19:50:22.213 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [301] = 
    {
        [1] = 1686268222213,
        [2] = "2023-06-08 19:50:22.213 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [302] = 
    {
        [1] = 1686268222213,
        [2] = "2023-06-08 19:50:22.213 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSlashCommander, AddOnVersion: 36, directory: 'user:/AddOns/LibSlashCommander/'",
        [7] = "",
    },
    [303] = 
    {
        [1] = 1686268222213,
        [2] = "2023-06-08 19:50:22.213 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 85, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [304] = 
    {
        [1] = 1686268222691,
        [2] = "2023-06-08 19:50:22.691 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [305] = 
    {
        [1] = 1686268222953,
        [2] = "2023-06-08 19:50:22.953 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [306] = 
    {
        [1] = 1686268222953,
        [2] = "2023-06-08 19:50:22.953 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [307] = 
    {
        [1] = 1686268222959,
        [2] = "2023-06-08 19:50:22.959 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: TamrielTradeCentre, AddOnVersion: 0, directory: 'user:/AddOns/TamrielTradeCentre/'",
        [7] = "",
    },
    [308] = 
    {
        [1] = 1686268223371,
        [2] = "2023-06-08 19:50:23.371 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [309] = 
    {
        [1] = 1686268228314,
        [2] = "2023-06-08 19:50:28.314 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BanditsUserInterface, AddOnVersion: 0, directory: 'user:/AddOns/BanditsUserInterface/'",
        [7] = "",
    },
    [310] = 
    {
        [1] = 1686268229437,
        [2] = "2023-06-08 19:50:29.437 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BeamMeUp, AddOnVersion: 345, directory: 'user:/AddOns/BeamMeUp/'",
        [7] = "",
    },
    [311] = 
    {
        [1] = 1686268229589,
        [2] = "2023-06-08 19:50:29.589 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [312] = 
    {
        [1] = 1686268229589,
        [2] = "2023-06-08 19:50:29.589 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [313] = 
    {
        [1] = 1686268229589,
        [2] = "2023-06-08 19:50:29.589 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 18, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [314] = 
    {
        [1] = 1686268229595,
        [2] = "2023-06-08 19:50:29.595 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: WritWorthy, AddOnVersion: 70307, directory: 'user:/AddOns/WritWorthy/'",
        [7] = "",
    },
    [315] = 
    {
        [1] = 1686268229625,
        [2] = "2023-06-08 19:50:29.625 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BattlegroundCoffers, AddOnVersion: 0, directory: 'user:/AddOns/BattlegroundCoffers/'",
        [7] = "",
    },
    [316] = 
    {
        [1] = 1686268229892,
        [2] = "2023-06-08 19:50:29.892 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [317] = 
    {
        [1] = 1686268229892,
        [2] = "2023-06-08 19:50:29.892 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [318] = 
    {
        [1] = 1686268229892,
        [2] = "2023-06-08 19:50:29.892 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 14, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [319] = 
    {
        [1] = 1686268229892,
        [2] = "2023-06-08 19:50:29.892 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LostTreasure, AddOnVersion: 28, directory: 'user:/AddOns/LostTreasure/'",
        [7] = "",
    },
    [320] = 
    {
        [1] = 1686268229893,
        [2] = "2023-06-08 19:50:29.893 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure/mining",
        [6] = "initialized: Mining is ACTIVE within active mining time.",
        [7] = "",
    },
    [321] = 
    {
        [1] = 1686268229934,
        [2] = "2023-06-08 19:50:29.934 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30920, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [322] = 
    {
        [1] = 1686268229950,
        [2] = "2023-06-08 19:50:29.950 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [323] = 
    {
        [1] = 1686268230053,
        [2] = "2023-06-08 19:50:30.053 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: IIfA, AddOnVersion: 30065, directory: 'user:/AddOns/IIfA/'",
        [7] = "",
    },
    [324] = 
    {
        [1] = 1686268230335,
        [2] = "2023-06-08 19:50:30.335 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10514, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [325] = 
    {
        [1] = 1686268231621,
        [2] = "2023-06-08 19:50:31.621 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.621s)",
        [7] = "",
    },
    [326] = 
    {
        [1] = 1686268264004,
        [2] = "2023-06-08 19:51:04.004 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@portgasdtbo\nBujin Yamato\n2023-06-08 18:53:46.181 -0400\neso.live.9.0.5.2691744 (101038)\nNA Megaserver\nPC - Steam (win32)\nkeyboard\neso+\nen\nEnglish\naddon count: 37/37\nallow outdated\nfullscreen windowed (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [327] = 
    {
        [1] = 1686268266559,
        [2] = "2023-06-08 19:51:06.559 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [328] = 
    {
        [1] = 1686268266559,
        [2] = "2023-06-08 19:51:06.559 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [329] = 
    {
        [1] = 1686268266560,
        [2] = "2023-06-08 19:51:06.560 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [330] = 
    {
        [1] = 1686268266560,
        [2] = "2023-06-08 19:51:06.560 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [331] = 
    {
        [1] = 1686268266560,
        [2] = "2023-06-08 19:51:06.560 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [332] = 
    {
        [1] = 1686268266560,
        [2] = "2023-06-08 19:51:06.560 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [333] = 
    {
        [1] = 1686268266560,
        [2] = "2023-06-08 19:51:06.560 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [334] = 
    {
        [1] = 1686268266560,
        [2] = "2023-06-08 19:51:06.560 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [335] = 
    {
        [1] = 1686268266649,
        [2] = "2023-06-08 19:51:06.649 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [336] = 
    {
        [1] = 1686268266649,
        [2] = "2023-06-08 19:51:06.649 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 262, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [337] = 
    {
        [1] = 1686268266649,
        [2] = "2023-06-08 19:51:06.649 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [338] = 
    {
        [1] = 1686268266657,
        [2] = "2023-06-08 19:51:06.657 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [339] = 
    {
        [1] = 1686268266657,
        [2] = "2023-06-08 19:51:06.657 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [340] = 
    {
        [1] = 1686268266657,
        [2] = "2023-06-08 19:51:06.657 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [341] = 
    {
        [1] = 1686268266663,
        [2] = "2023-06-08 19:51:06.663 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [342] = 
    {
        [1] = 1686268266724,
        [2] = "2023-06-08 19:51:06.724 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [343] = 
    {
        [1] = 1686268266724,
        [2] = "2023-06-08 19:51:06.724 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [344] = 
    {
        [1] = 1686268266724,
        [2] = "2023-06-08 19:51:06.724 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1630, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [345] = 
    {
        [1] = 1686268267283,
        [2] = "2023-06-08 19:51:07.283 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [346] = 
    {
        [1] = 1686268267288,
        [2] = "2023-06-08 19:51:07.288 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DynamicCP, AddOnVersion: 0, directory: 'user:/AddOns/DynamicCP/'",
        [7] = "",
    },
    [347] = 
    {
        [1] = 1686268267303,
        [2] = "2023-06-08 19:51:07.303 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 69, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [348] = 
    {
        [1] = 1686268267303,
        [2] = "2023-06-08 19:51:07.303 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [349] = 
    {
        [1] = 1686268267303,
        [2] = "2023-06-08 19:51:07.303 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [350] = 
    {
        [1] = 1686268267303,
        [2] = "2023-06-08 19:51:07.303 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [351] = 
    {
        [1] = 1686268267303,
        [2] = "2023-06-08 19:51:07.303 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [352] = 
    {
        [1] = 1686268267304,
        [2] = "2023-06-08 19:51:07.304 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSlashCommander, AddOnVersion: 36, directory: 'user:/AddOns/LibSlashCommander/'",
        [7] = "",
    },
    [353] = 
    {
        [1] = 1686268267304,
        [2] = "2023-06-08 19:51:07.304 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 85, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [354] = 
    {
        [1] = 1686268267736,
        [2] = "2023-06-08 19:51:07.736 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [355] = 
    {
        [1] = 1686268267983,
        [2] = "2023-06-08 19:51:07.983 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [356] = 
    {
        [1] = 1686268267983,
        [2] = "2023-06-08 19:51:07.983 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [357] = 
    {
        [1] = 1686268267989,
        [2] = "2023-06-08 19:51:07.989 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: TamrielTradeCentre, AddOnVersion: 0, directory: 'user:/AddOns/TamrielTradeCentre/'",
        [7] = "",
    },
    [358] = 
    {
        [1] = 1686268268369,
        [2] = "2023-06-08 19:51:08.369 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [359] = 
    {
        [1] = 1686268273371,
        [2] = "2023-06-08 19:51:13.371 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BanditsUserInterface, AddOnVersion: 0, directory: 'user:/AddOns/BanditsUserInterface/'",
        [7] = "",
    },
    [360] = 
    {
        [1] = 1686268274485,
        [2] = "2023-06-08 19:51:14.485 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BeamMeUp, AddOnVersion: 345, directory: 'user:/AddOns/BeamMeUp/'",
        [7] = "",
    },
    [361] = 
    {
        [1] = 1686268274656,
        [2] = "2023-06-08 19:51:14.656 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [362] = 
    {
        [1] = 1686268274656,
        [2] = "2023-06-08 19:51:14.656 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [363] = 
    {
        [1] = 1686268274656,
        [2] = "2023-06-08 19:51:14.656 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 18, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [364] = 
    {
        [1] = 1686268274661,
        [2] = "2023-06-08 19:51:14.661 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: WritWorthy, AddOnVersion: 70307, directory: 'user:/AddOns/WritWorthy/'",
        [7] = "",
    },
    [365] = 
    {
        [1] = 1686268274694,
        [2] = "2023-06-08 19:51:14.694 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BattlegroundCoffers, AddOnVersion: 0, directory: 'user:/AddOns/BattlegroundCoffers/'",
        [7] = "",
    },
    [366] = 
    {
        [1] = 1686268274956,
        [2] = "2023-06-08 19:51:14.956 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [367] = 
    {
        [1] = 1686268274956,
        [2] = "2023-06-08 19:51:14.956 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [368] = 
    {
        [1] = 1686268274956,
        [2] = "2023-06-08 19:51:14.956 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 14, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [369] = 
    {
        [1] = 1686268274956,
        [2] = "2023-06-08 19:51:14.956 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LostTreasure, AddOnVersion: 28, directory: 'user:/AddOns/LostTreasure/'",
        [7] = "",
    },
    [370] = 
    {
        [1] = 1686268274958,
        [2] = "2023-06-08 19:51:14.958 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure/mining",
        [6] = "initialized: Mining is ACTIVE within active mining time.",
        [7] = "",
    },
    [371] = 
    {
        [1] = 1686268275002,
        [2] = "2023-06-08 19:51:15.002 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30920, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [372] = 
    {
        [1] = 1686268275018,
        [2] = "2023-06-08 19:51:15.018 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [373] = 
    {
        [1] = 1686268275119,
        [2] = "2023-06-08 19:51:15.119 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: IIfA, AddOnVersion: 30065, directory: 'user:/AddOns/IIfA/'",
        [7] = "",
    },
    [374] = 
    {
        [1] = 1686268275506,
        [2] = "2023-06-08 19:51:15.506 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10514, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [375] = 
    {
        [1] = 1686268276764,
        [2] = "2023-06-08 19:51:16.764 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.764s)",
        [7] = "",
    },
    [376] = 
    {
        [1] = 1686268338510,
        [2] = "2023-06-08 19:52:18.510 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "This collectible is not ready yet.",
        [7] = "",
    },
    [377] = 
    {
        [1] = 1686269210226,
        [2] = "2023-06-08 20:06:50.226 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [378] = 
    {
        [1] = 1686269221270,
        [2] = "2023-06-08 20:07:01.270 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure",
        [6] = "Book opened. bookId: 4576, title: Invitation to Morrowind, isCollected: false",
        [7] = "",
    },
    [379] = 
    {
        [1] = 1686269275004,
        [2] = "2023-06-08 20:07:55.004 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@portgasdtbo\nBig depression\n2023-06-08 18:53:45.834 -0400\neso.live.9.0.5.2691744 (101038)\nNA Megaserver\nPC - Steam (win32)\nkeyboard\neso+\nen\nEnglish\naddon count: 37/37\nallow outdated\nfullscreen windowed (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [380] = 
    {
        [1] = 1686269277612,
        [2] = "2023-06-08 20:07:57.612 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [381] = 
    {
        [1] = 1686269277612,
        [2] = "2023-06-08 20:07:57.612 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [382] = 
    {
        [1] = 1686269277612,
        [2] = "2023-06-08 20:07:57.612 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [383] = 
    {
        [1] = 1686269277612,
        [2] = "2023-06-08 20:07:57.612 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [384] = 
    {
        [1] = 1686269277612,
        [2] = "2023-06-08 20:07:57.612 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [385] = 
    {
        [1] = 1686269277612,
        [2] = "2023-06-08 20:07:57.612 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [386] = 
    {
        [1] = 1686269277612,
        [2] = "2023-06-08 20:07:57.612 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [387] = 
    {
        [1] = 1686269277612,
        [2] = "2023-06-08 20:07:57.612 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [388] = 
    {
        [1] = 1686269277698,
        [2] = "2023-06-08 20:07:57.698 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [389] = 
    {
        [1] = 1686269277698,
        [2] = "2023-06-08 20:07:57.698 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 262, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [390] = 
    {
        [1] = 1686269277698,
        [2] = "2023-06-08 20:07:57.698 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [391] = 
    {
        [1] = 1686269277707,
        [2] = "2023-06-08 20:07:57.707 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [392] = 
    {
        [1] = 1686269277707,
        [2] = "2023-06-08 20:07:57.707 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [393] = 
    {
        [1] = 1686269277707,
        [2] = "2023-06-08 20:07:57.707 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [394] = 
    {
        [1] = 1686269277712,
        [2] = "2023-06-08 20:07:57.712 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [395] = 
    {
        [1] = 1686269277772,
        [2] = "2023-06-08 20:07:57.772 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [396] = 
    {
        [1] = 1686269277772,
        [2] = "2023-06-08 20:07:57.772 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [397] = 
    {
        [1] = 1686269277772,
        [2] = "2023-06-08 20:07:57.772 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1630, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [398] = 
    {
        [1] = 1686269278305,
        [2] = "2023-06-08 20:07:58.305 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [399] = 
    {
        [1] = 1686269278311,
        [2] = "2023-06-08 20:07:58.311 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DynamicCP, AddOnVersion: 0, directory: 'user:/AddOns/DynamicCP/'",
        [7] = "",
    },
    [400] = 
    {
        [1] = 1686269278327,
        [2] = "2023-06-08 20:07:58.327 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 69, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [401] = 
    {
        [1] = 1686269278327,
        [2] = "2023-06-08 20:07:58.327 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [402] = 
    {
        [1] = 1686269278327,
        [2] = "2023-06-08 20:07:58.327 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [403] = 
    {
        [1] = 1686269278327,
        [2] = "2023-06-08 20:07:58.327 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [404] = 
    {
        [1] = 1686269278327,
        [2] = "2023-06-08 20:07:58.327 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [405] = 
    {
        [1] = 1686269278327,
        [2] = "2023-06-08 20:07:58.327 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSlashCommander, AddOnVersion: 36, directory: 'user:/AddOns/LibSlashCommander/'",
        [7] = "",
    },
    [406] = 
    {
        [1] = 1686269278327,
        [2] = "2023-06-08 20:07:58.327 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 85, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [407] = 
    {
        [1] = 1686269278751,
        [2] = "2023-06-08 20:07:58.751 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [408] = 
    {
        [1] = 1686269279000,
        [2] = "2023-06-08 20:07:59.000 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [409] = 
    {
        [1] = 1686269279000,
        [2] = "2023-06-08 20:07:59.000 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [410] = 
    {
        [1] = 1686269279005,
        [2] = "2023-06-08 20:07:59.005 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: TamrielTradeCentre, AddOnVersion: 0, directory: 'user:/AddOns/TamrielTradeCentre/'",
        [7] = "",
    },
    [411] = 
    {
        [1] = 1686269279395,
        [2] = "2023-06-08 20:07:59.395 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [412] = 
    {
        [1] = 1686269284043,
        [2] = "2023-06-08 20:08:04.043 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BanditsUserInterface, AddOnVersion: 0, directory: 'user:/AddOns/BanditsUserInterface/'",
        [7] = "",
    },
    [413] = 
    {
        [1] = 1686269285105,
        [2] = "2023-06-08 20:08:05.105 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BeamMeUp, AddOnVersion: 345, directory: 'user:/AddOns/BeamMeUp/'",
        [7] = "",
    },
    [414] = 
    {
        [1] = 1686269285247,
        [2] = "2023-06-08 20:08:05.247 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [415] = 
    {
        [1] = 1686269285247,
        [2] = "2023-06-08 20:08:05.247 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [416] = 
    {
        [1] = 1686269285247,
        [2] = "2023-06-08 20:08:05.247 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 18, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [417] = 
    {
        [1] = 1686269285252,
        [2] = "2023-06-08 20:08:05.252 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: WritWorthy, AddOnVersion: 70307, directory: 'user:/AddOns/WritWorthy/'",
        [7] = "",
    },
    [418] = 
    {
        [1] = 1686269285362,
        [2] = "2023-06-08 20:08:05.362 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BattlegroundCoffers, AddOnVersion: 0, directory: 'user:/AddOns/BattlegroundCoffers/'",
        [7] = "",
    },
    [419] = 
    {
        [1] = 1686269285620,
        [2] = "2023-06-08 20:08:05.620 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [420] = 
    {
        [1] = 1686269285620,
        [2] = "2023-06-08 20:08:05.620 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [421] = 
    {
        [1] = 1686269285620,
        [2] = "2023-06-08 20:08:05.620 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 14, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [422] = 
    {
        [1] = 1686269285620,
        [2] = "2023-06-08 20:08:05.620 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LostTreasure, AddOnVersion: 28, directory: 'user:/AddOns/LostTreasure/'",
        [7] = "",
    },
    [423] = 
    {
        [1] = 1686269285621,
        [2] = "2023-06-08 20:08:05.621 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure/mining",
        [6] = "initialized: Mining is ACTIVE within active mining time.",
        [7] = "",
    },
    [424] = 
    {
        [1] = 1686269285662,
        [2] = "2023-06-08 20:08:05.662 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30920, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [425] = 
    {
        [1] = 1686269285678,
        [2] = "2023-06-08 20:08:05.678 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [426] = 
    {
        [1] = 1686269285792,
        [2] = "2023-06-08 20:08:05.792 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: IIfA, AddOnVersion: 30065, directory: 'user:/AddOns/IIfA/'",
        [7] = "",
    },
    [427] = 
    {
        [1] = 1686269286079,
        [2] = "2023-06-08 20:08:06.079 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10514, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [428] = 
    {
        [1] = 1686269287312,
        [2] = "2023-06-08 20:08:07.312 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.312s)",
        [7] = "",
    },
    [429] = 
    {
        [1] = 1686269438026,
        [2] = "2023-06-08 20:10:38.026 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure",
        [6] = "Invalid interaction. pinType survey, interactionType 6, sceneName bank",
        [7] = "",
    },
    [430] = 
    {
        [1] = 1686269478462,
        [2] = "2023-06-08 20:11:18.462 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [431] = 
    {
        [1] = 1686269507680,
        [2] = "2023-06-08 20:11:47.680 -0400",
        [3] = 6,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [432] = 
    {
        [1] = 1686269525298,
        [2] = "2023-06-08 20:12:05.298 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure",
        [6] = "Invalid interaction. pinType survey, interactionType 6, sceneName bank",
        [7] = "",
    },
    [433] = 
    {
        [1] = 1686269537747,
        [2] = "2023-06-08 20:12:17.747 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [434] = 
    {
        [1] = 1686269589003,
        [2] = "2023-06-08 20:13:09.003 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@portgasdtbo\nSneaky lil Snake\n2023-06-08 18:53:45.846 -0400\neso.live.9.0.5.2691744 (101038)\nNA Megaserver\nPC - Steam (win32)\nkeyboard\neso+\nen\nEnglish\naddon count: 37/37\nallow outdated\nfullscreen windowed (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [435] = 
    {
        [1] = 1686269591621,
        [2] = "2023-06-08 20:13:11.621 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [436] = 
    {
        [1] = 1686269591621,
        [2] = "2023-06-08 20:13:11.621 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [437] = 
    {
        [1] = 1686269591621,
        [2] = "2023-06-08 20:13:11.621 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [438] = 
    {
        [1] = 1686269591621,
        [2] = "2023-06-08 20:13:11.621 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [439] = 
    {
        [1] = 1686269591621,
        [2] = "2023-06-08 20:13:11.621 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [440] = 
    {
        [1] = 1686269591621,
        [2] = "2023-06-08 20:13:11.621 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [441] = 
    {
        [1] = 1686269591621,
        [2] = "2023-06-08 20:13:11.621 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [442] = 
    {
        [1] = 1686269591621,
        [2] = "2023-06-08 20:13:11.621 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [443] = 
    {
        [1] = 1686269591713,
        [2] = "2023-06-08 20:13:11.713 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [444] = 
    {
        [1] = 1686269591713,
        [2] = "2023-06-08 20:13:11.713 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 262, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [445] = 
    {
        [1] = 1686269591713,
        [2] = "2023-06-08 20:13:11.713 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [446] = 
    {
        [1] = 1686269591723,
        [2] = "2023-06-08 20:13:11.723 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [447] = 
    {
        [1] = 1686269591723,
        [2] = "2023-06-08 20:13:11.723 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [448] = 
    {
        [1] = 1686269591723,
        [2] = "2023-06-08 20:13:11.723 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [449] = 
    {
        [1] = 1686269591727,
        [2] = "2023-06-08 20:13:11.727 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [450] = 
    {
        [1] = 1686269591796,
        [2] = "2023-06-08 20:13:11.796 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [451] = 
    {
        [1] = 1686269591796,
        [2] = "2023-06-08 20:13:11.796 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [452] = 
    {
        [1] = 1686269591796,
        [2] = "2023-06-08 20:13:11.796 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1630, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [453] = 
    {
        [1] = 1686269592468,
        [2] = "2023-06-08 20:13:12.468 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [454] = 
    {
        [1] = 1686269592473,
        [2] = "2023-06-08 20:13:12.473 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DynamicCP, AddOnVersion: 0, directory: 'user:/AddOns/DynamicCP/'",
        [7] = "",
    },
    [455] = 
    {
        [1] = 1686269592495,
        [2] = "2023-06-08 20:13:12.495 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 69, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [456] = 
    {
        [1] = 1686269592495,
        [2] = "2023-06-08 20:13:12.495 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [457] = 
    {
        [1] = 1686269592495,
        [2] = "2023-06-08 20:13:12.495 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [458] = 
    {
        [1] = 1686269592495,
        [2] = "2023-06-08 20:13:12.495 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [459] = 
    {
        [1] = 1686269592495,
        [2] = "2023-06-08 20:13:12.495 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [460] = 
    {
        [1] = 1686269592496,
        [2] = "2023-06-08 20:13:12.496 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSlashCommander, AddOnVersion: 36, directory: 'user:/AddOns/LibSlashCommander/'",
        [7] = "",
    },
    [461] = 
    {
        [1] = 1686269592496,
        [2] = "2023-06-08 20:13:12.496 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 85, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [462] = 
    {
        [1] = 1686269592919,
        [2] = "2023-06-08 20:13:12.919 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [463] = 
    {
        [1] = 1686269593162,
        [2] = "2023-06-08 20:13:13.162 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [464] = 
    {
        [1] = 1686269593162,
        [2] = "2023-06-08 20:13:13.162 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [465] = 
    {
        [1] = 1686269593168,
        [2] = "2023-06-08 20:13:13.168 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: TamrielTradeCentre, AddOnVersion: 0, directory: 'user:/AddOns/TamrielTradeCentre/'",
        [7] = "",
    },
    [466] = 
    {
        [1] = 1686269593564,
        [2] = "2023-06-08 20:13:13.564 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [467] = 
    {
        [1] = 1686269598465,
        [2] = "2023-06-08 20:13:18.465 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BanditsUserInterface, AddOnVersion: 0, directory: 'user:/AddOns/BanditsUserInterface/'",
        [7] = "",
    },
    [468] = 
    {
        [1] = 1686269599532,
        [2] = "2023-06-08 20:13:19.532 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BeamMeUp, AddOnVersion: 345, directory: 'user:/AddOns/BeamMeUp/'",
        [7] = "",
    },
    [469] = 
    {
        [1] = 1686269599670,
        [2] = "2023-06-08 20:13:19.670 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [470] = 
    {
        [1] = 1686269599670,
        [2] = "2023-06-08 20:13:19.670 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [471] = 
    {
        [1] = 1686269599670,
        [2] = "2023-06-08 20:13:19.670 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 18, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [472] = 
    {
        [1] = 1686269599676,
        [2] = "2023-06-08 20:13:19.676 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: WritWorthy, AddOnVersion: 70307, directory: 'user:/AddOns/WritWorthy/'",
        [7] = "",
    },
    [473] = 
    {
        [1] = 1686269599706,
        [2] = "2023-06-08 20:13:19.706 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BattlegroundCoffers, AddOnVersion: 0, directory: 'user:/AddOns/BattlegroundCoffers/'",
        [7] = "",
    },
    [474] = 
    {
        [1] = 1686269599982,
        [2] = "2023-06-08 20:13:19.982 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [475] = 
    {
        [1] = 1686269599982,
        [2] = "2023-06-08 20:13:19.982 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [476] = 
    {
        [1] = 1686269599982,
        [2] = "2023-06-08 20:13:19.982 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 14, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [477] = 
    {
        [1] = 1686269599982,
        [2] = "2023-06-08 20:13:19.982 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LostTreasure, AddOnVersion: 28, directory: 'user:/AddOns/LostTreasure/'",
        [7] = "",
    },
    [478] = 
    {
        [1] = 1686269599983,
        [2] = "2023-06-08 20:13:19.983 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure/mining",
        [6] = "initialized: Mining is ACTIVE within active mining time.",
        [7] = "",
    },
    [479] = 
    {
        [1] = 1686269600026,
        [2] = "2023-06-08 20:13:20.026 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30920, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [480] = 
    {
        [1] = 1686269600042,
        [2] = "2023-06-08 20:13:20.042 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [481] = 
    {
        [1] = 1686269600148,
        [2] = "2023-06-08 20:13:20.148 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: IIfA, AddOnVersion: 30065, directory: 'user:/AddOns/IIfA/'",
        [7] = "",
    },
    [482] = 
    {
        [1] = 1686269600469,
        [2] = "2023-06-08 20:13:20.469 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10514, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [483] = 
    {
        [1] = 1686269601720,
        [2] = "2023-06-08 20:13:21.720 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.720s)",
        [7] = "",
    },
    [484] = 
    {
        [1] = 1686270102311,
        [2] = "2023-06-08 20:21:42.311 -0400",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [485] = 
    {
        [1] = 1686270110457,
        [2] = "2023-06-08 20:21:50.457 -0400",
        [3] = 3,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [486] = 
    {
        [1] = 1686270196003,
        [2] = "2023-06-08 20:23:16.003 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@portgasdtbo\nSweepy Mcsweeperson\n2023-06-08 18:53:45.747 -0400\neso.live.9.0.5.2691744 (101038)\nNA Megaserver\nPC - Steam (win32)\nkeyboard\neso+\nen\nEnglish\naddon count: 37/37\nallow outdated\nfullscreen windowed (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [487] = 
    {
        [1] = 1686270198718,
        [2] = "2023-06-08 20:23:18.718 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [488] = 
    {
        [1] = 1686270198718,
        [2] = "2023-06-08 20:23:18.718 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [489] = 
    {
        [1] = 1686270198718,
        [2] = "2023-06-08 20:23:18.718 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [490] = 
    {
        [1] = 1686270198718,
        [2] = "2023-06-08 20:23:18.718 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [491] = 
    {
        [1] = 1686270198718,
        [2] = "2023-06-08 20:23:18.718 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [492] = 
    {
        [1] = 1686270198718,
        [2] = "2023-06-08 20:23:18.718 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [493] = 
    {
        [1] = 1686270198718,
        [2] = "2023-06-08 20:23:18.718 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [494] = 
    {
        [1] = 1686270198718,
        [2] = "2023-06-08 20:23:18.718 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [495] = 
    {
        [1] = 1686270198800,
        [2] = "2023-06-08 20:23:18.800 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [496] = 
    {
        [1] = 1686270198800,
        [2] = "2023-06-08 20:23:18.800 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 262, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [497] = 
    {
        [1] = 1686270198800,
        [2] = "2023-06-08 20:23:18.800 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [498] = 
    {
        [1] = 1686270198809,
        [2] = "2023-06-08 20:23:18.809 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [499] = 
    {
        [1] = 1686270198809,
        [2] = "2023-06-08 20:23:18.809 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [500] = 
    {
        [1] = 1686270198809,
        [2] = "2023-06-08 20:23:18.809 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [501] = 
    {
        [1] = 1686270198814,
        [2] = "2023-06-08 20:23:18.814 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [502] = 
    {
        [1] = 1686270198885,
        [2] = "2023-06-08 20:23:18.885 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [503] = 
    {
        [1] = 1686270198885,
        [2] = "2023-06-08 20:23:18.885 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [504] = 
    {
        [1] = 1686270198885,
        [2] = "2023-06-08 20:23:18.885 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1630, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [505] = 
    {
        [1] = 1686270199429,
        [2] = "2023-06-08 20:23:19.429 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [506] = 
    {
        [1] = 1686270199435,
        [2] = "2023-06-08 20:23:19.435 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DynamicCP, AddOnVersion: 0, directory: 'user:/AddOns/DynamicCP/'",
        [7] = "",
    },
    [507] = 
    {
        [1] = 1686270199453,
        [2] = "2023-06-08 20:23:19.453 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 69, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [508] = 
    {
        [1] = 1686270199453,
        [2] = "2023-06-08 20:23:19.453 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [509] = 
    {
        [1] = 1686270199453,
        [2] = "2023-06-08 20:23:19.453 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [510] = 
    {
        [1] = 1686270199453,
        [2] = "2023-06-08 20:23:19.453 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [511] = 
    {
        [1] = 1686270199453,
        [2] = "2023-06-08 20:23:19.453 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [512] = 
    {
        [1] = 1686270199454,
        [2] = "2023-06-08 20:23:19.454 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSlashCommander, AddOnVersion: 36, directory: 'user:/AddOns/LibSlashCommander/'",
        [7] = "",
    },
    [513] = 
    {
        [1] = 1686270199454,
        [2] = "2023-06-08 20:23:19.454 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 85, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [514] = 
    {
        [1] = 1686270199884,
        [2] = "2023-06-08 20:23:19.884 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [515] = 
    {
        [1] = 1686270200139,
        [2] = "2023-06-08 20:23:20.139 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [516] = 
    {
        [1] = 1686270200139,
        [2] = "2023-06-08 20:23:20.139 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [517] = 
    {
        [1] = 1686270200145,
        [2] = "2023-06-08 20:23:20.145 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: TamrielTradeCentre, AddOnVersion: 0, directory: 'user:/AddOns/TamrielTradeCentre/'",
        [7] = "",
    },
    [518] = 
    {
        [1] = 1686270200547,
        [2] = "2023-06-08 20:23:20.547 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [519] = 
    {
        [1] = 1686270205473,
        [2] = "2023-06-08 20:23:25.473 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BanditsUserInterface, AddOnVersion: 0, directory: 'user:/AddOns/BanditsUserInterface/'",
        [7] = "",
    },
    [520] = 
    {
        [1] = 1686270206622,
        [2] = "2023-06-08 20:23:26.622 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BeamMeUp, AddOnVersion: 345, directory: 'user:/AddOns/BeamMeUp/'",
        [7] = "",
    },
    [521] = 
    {
        [1] = 1686270206781,
        [2] = "2023-06-08 20:23:26.781 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [522] = 
    {
        [1] = 1686270206781,
        [2] = "2023-06-08 20:23:26.781 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [523] = 
    {
        [1] = 1686270206781,
        [2] = "2023-06-08 20:23:26.781 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 18, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [524] = 
    {
        [1] = 1686270206787,
        [2] = "2023-06-08 20:23:26.787 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: WritWorthy, AddOnVersion: 70307, directory: 'user:/AddOns/WritWorthy/'",
        [7] = "",
    },
    [525] = 
    {
        [1] = 1686270206821,
        [2] = "2023-06-08 20:23:26.821 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: BattlegroundCoffers, AddOnVersion: 0, directory: 'user:/AddOns/BattlegroundCoffers/'",
        [7] = "",
    },
    [526] = 
    {
        [1] = 1686270207074,
        [2] = "2023-06-08 20:23:27.074 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [527] = 
    {
        [1] = 1686270207074,
        [2] = "2023-06-08 20:23:27.074 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [528] = 
    {
        [1] = 1686270207074,
        [2] = "2023-06-08 20:23:27.074 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 14, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [529] = 
    {
        [1] = 1686270207074,
        [2] = "2023-06-08 20:23:27.074 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LostTreasure, AddOnVersion: 28, directory: 'user:/AddOns/LostTreasure/'",
        [7] = "",
    },
    [530] = 
    {
        [1] = 1686270207074,
        [2] = "2023-06-08 20:23:27.074 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LostTreasure/mining",
        [6] = "initialized: Mining is ACTIVE within active mining time.",
        [7] = "",
    },
    [531] = 
    {
        [1] = 1686270207114,
        [2] = "2023-06-08 20:23:27.114 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30920, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [532] = 
    {
        [1] = 1686270207129,
        [2] = "2023-06-08 20:23:27.129 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [533] = 
    {
        [1] = 1686270207239,
        [2] = "2023-06-08 20:23:27.239 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: IIfA, AddOnVersion: 30065, directory: 'user:/AddOns/IIfA/'",
        [7] = "",
    },
    [534] = 
    {
        [1] = 1686270207511,
        [2] = "2023-06-08 20:23:27.511 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10514, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [535] = 
    {
        [1] = 1686270208743,
        [2] = "2023-06-08 20:23:28.743 -0400",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.743s)",
        [7] = "",
    },
}
