IIfA_Settings =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["8796093061464499"] = 
            {
                ["$LastCharacterName"] = "His Swoliness",
                ["in2AgedGuildBankDataWarning"] = true,
                ["collectHouseData"] = 
                {
                },
                ["TooltipFontSize"] = 18,
                ["bAddContextMenuEntrySearchInIIfA"] = true,
                ["ShowToolTipWhen"] = "Always",
                ["showItemStats"] = false,
                ["TooltipFontFace"] = "EsoUI/Common/Fonts/Univers57.otf",
                ["dontFocusSearch"] = false,
                ["BagSpaceAlert"] = 
                {
                    ["threshold"] = 95,
                    ["b"] = 0,
                    ["g"] = 1,
                    ["r"] = 1,
                },
                ["bCollectGuildBankData"] = false,
                ["BagSpaceFull"] = 
                {
                    ["b"] = 0,
                    ["g"] = 0,
                    ["r"] = 255,
                },
                ["in2DefaultInventoryFrameView"] = "All",
                ["TooltipFontEffect"] = "soft-shadow-thin",
                ["FCOISshowMarkerIcons"] = false,
                ["bInSeparateFrame"] = true,
                ["showStyleInfo"] = true,
                ["ignoredCharEquipment"] = 
                {
                },
                ["hideCloseButton"] = false,
                ["DBv3"] = 
                {
                },
                ["BagSpaceWarn"] = 
                {
                    ["threshold"] = 85,
                    ["b"] = 0,
                    ["g"] = 0.5098039216,
                    ["r"] = 0.9019607843,
                },
                ["frameSettings"] = 
                {
                    ["store"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["alchemy"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["guildBank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["stables"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["smithing"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["inventory"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["hud"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = false,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = true,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["trade"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["bank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["tradinghouse"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                },
                ["ignoredCharInventories"] = 
                {
                },
                ["saveSettingsGlobally"] = true,
                ["bFilterOnSetName"] = false,
                ["showItemCountOnRight"] = true,
                ["version"] = 1,
                ["b_collectHouses"] = false,
                ["in2TooltipsFont"] = "ZoFontGame",
                ["bFilterOnSetNameToo"] = false,
                ["bDebug"] = false,
            },
            ["8796093057729085"] = 
            {
                ["$LastCharacterName"] = "Big depression",
                ["in2AgedGuildBankDataWarning"] = true,
                ["collectHouseData"] = 
                {
                },
                ["TooltipFontSize"] = 18,
                ["bAddContextMenuEntrySearchInIIfA"] = true,
                ["ShowToolTipWhen"] = "Always",
                ["TooltipFontFace"] = "EsoUI/Common/Fonts/Univers57.otf",
                ["showItemStats"] = false,
                ["dontFocusSearch"] = false,
                ["bCollectGuildBankData"] = false,
                ["BagSpaceAlert"] = 
                {
                    ["threshold"] = 95,
                    ["b"] = 0,
                    ["g"] = 1,
                    ["r"] = 1,
                },
                ["BagSpaceFull"] = 
                {
                    ["b"] = 0,
                    ["g"] = 0,
                    ["r"] = 255,
                },
                ["in2DefaultInventoryFrameView"] = "All",
                ["TooltipFontEffect"] = "soft-shadow-thin",
                ["FCOISshowMarkerIcons"] = false,
                ["bInSeparateFrame"] = true,
                ["showStyleInfo"] = true,
                ["ignoredCharEquipment"] = 
                {
                },
                ["hideCloseButton"] = false,
                ["DBv3"] = 
                {
                },
                ["BagSpaceWarn"] = 
                {
                    ["threshold"] = 85,
                    ["b"] = 0,
                    ["g"] = 0.5098039216,
                    ["r"] = 0.9019607843,
                },
                ["frameSettings"] = 
                {
                    ["store"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["docked"] = true,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["alchemy"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["docked"] = true,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["guildBank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["docked"] = true,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["stables"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["docked"] = true,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["smithing"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["docked"] = true,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["inventory"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["docked"] = true,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["hud"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["docked"] = false,
                        ["lastY"] = 300,
                        ["hidden"] = true,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["trade"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["docked"] = true,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["bank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["docked"] = true,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["tradinghouse"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["docked"] = true,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                },
                ["ignoredCharInventories"] = 
                {
                },
                ["saveSettingsGlobally"] = true,
                ["bFilterOnSetName"] = false,
                ["showItemCountOnRight"] = true,
                ["version"] = 1,
                ["b_collectHouses"] = false,
                ["in2TooltipsFont"] = "ZoFontGame",
                ["bFilterOnSetNameToo"] = false,
                ["bDebug"] = false,
            },
            ["8796093057561649"] = 
            {
                ["$LastCharacterName"] = "Sorc deez Frags",
                ["in2AgedGuildBankDataWarning"] = true,
                ["collectHouseData"] = 
                {
                },
                ["TooltipFontSize"] = 18,
                ["TooltipFontFace"] = "EsoUI/Common/Fonts/Univers57.otf",
                ["ShowToolTipWhen"] = "Always",
                ["showItemStats"] = false,
                ["showStyleInfo"] = true,
                ["dontFocusSearch"] = false,
                ["BagSpaceAlert"] = 
                {
                    ["threshold"] = 95,
                    ["b"] = 0,
                    ["g"] = 1,
                    ["r"] = 1,
                },
                ["bCollectGuildBankData"] = false,
                ["BagSpaceFull"] = 
                {
                    ["b"] = 0,
                    ["g"] = 0,
                    ["r"] = 255,
                },
                ["in2DefaultInventoryFrameView"] = "All",
                ["TooltipFontEffect"] = "soft-shadow-thin",
                ["FCOISshowMarkerIcons"] = false,
                ["bInSeparateFrame"] = true,
                ["ignoredCharEquipment"] = 
                {
                },
                ["BagSpaceWarn"] = 
                {
                    ["threshold"] = 85,
                    ["b"] = 0,
                    ["g"] = 0.5098039216,
                    ["r"] = 0.9019607843,
                },
                ["hideCloseButton"] = false,
                ["DBv3"] = 
                {
                },
                ["frameSettings"] = 
                {
                    ["store"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["alchemy"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["guildBank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["stables"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["smithing"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["inventory"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["hud"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = false,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = true,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["trade"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["bank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["tradinghouse"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                },
                ["bAddContextMenuEntrySearchInIIfA"] = true,
                ["ignoredCharInventories"] = 
                {
                },
                ["saveSettingsGlobally"] = true,
                ["bFilterOnSetName"] = false,
                ["showItemCountOnRight"] = true,
                ["version"] = 1,
                ["b_collectHouses"] = false,
                ["in2TooltipsFont"] = "ZoFontGame",
                ["bFilterOnSetNameToo"] = false,
                ["bDebug"] = false,
            },
            ["8796093058809737"] = 
            {
                ["$LastCharacterName"] = "Bujin Yamato",
                ["in2AgedGuildBankDataWarning"] = true,
                ["collectHouseData"] = 
                {
                },
                ["TooltipFontSize"] = 18,
                ["TooltipFontFace"] = "EsoUI/Common/Fonts/Univers57.otf",
                ["ShowToolTipWhen"] = "Always",
                ["showItemCountOnRight"] = true,
                ["showItemStats"] = false,
                ["dontFocusSearch"] = false,
                ["ignoredCharInventories"] = 
                {
                },
                ["BagSpaceAlert"] = 
                {
                    ["threshold"] = 95,
                    ["b"] = 0,
                    ["g"] = 1,
                    ["r"] = 1,
                },
                ["BagSpaceFull"] = 
                {
                    ["b"] = 0,
                    ["g"] = 0,
                    ["r"] = 255,
                },
                ["in2DefaultInventoryFrameView"] = "All",
                ["TooltipFontEffect"] = "soft-shadow-thin",
                ["FCOISshowMarkerIcons"] = false,
                ["bInSeparateFrame"] = true,
                ["bCollectGuildBankData"] = false,
                ["bAddContextMenuEntrySearchInIIfA"] = true,
                ["ignoredCharEquipment"] = 
                {
                },
                ["DBv3"] = 
                {
                },
                ["BagSpaceWarn"] = 
                {
                    ["threshold"] = 85,
                    ["b"] = 0,
                    ["g"] = 0.5098039216,
                    ["r"] = 0.9019607843,
                },
                ["frameSettings"] = 
                {
                    ["store"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["alchemy"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["guildBank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["stables"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["smithing"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["inventory"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["hud"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = false,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = true,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["trade"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["bank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["tradinghouse"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                },
                ["showStyleInfo"] = true,
                ["saveSettingsGlobally"] = true,
                ["bFilterOnSetName"] = false,
                ["hideCloseButton"] = false,
                ["version"] = 1,
                ["b_collectHouses"] = false,
                ["in2TooltipsFont"] = "ZoFontGame",
                ["bFilterOnSetNameToo"] = false,
                ["bDebug"] = false,
            },
            ["8796093059852051"] = 
            {
                ["$LastCharacterName"] = "Sneaky lil Snake",
                ["in2AgedGuildBankDataWarning"] = true,
                ["collectHouseData"] = 
                {
                },
                ["TooltipFontSize"] = 18,
                ["bAddContextMenuEntrySearchInIIfA"] = true,
                ["ShowToolTipWhen"] = "Always",
                ["ignoredCharEquipment"] = 
                {
                },
                ["showItemStats"] = false,
                ["dontFocusSearch"] = false,
                ["showStyleInfo"] = true,
                ["bCollectGuildBankData"] = false,
                ["BagSpaceFull"] = 
                {
                    ["b"] = 0,
                    ["g"] = 0,
                    ["r"] = 255,
                },
                ["in2DefaultInventoryFrameView"] = "All",
                ["TooltipFontEffect"] = "soft-shadow-thin",
                ["FCOISshowMarkerIcons"] = false,
                ["bInSeparateFrame"] = true,
                ["BagSpaceWarn"] = 
                {
                    ["threshold"] = 85,
                    ["b"] = 0,
                    ["g"] = 0.5098039216,
                    ["r"] = 0.9019607843,
                },
                ["TooltipFontFace"] = "EsoUI/Common/Fonts/Univers57.otf",
                ["hideCloseButton"] = false,
                ["DBv3"] = 
                {
                },
                ["showItemCountOnRight"] = true,
                ["bFilterOnSetNameToo"] = false,
                ["ignoredCharInventories"] = 
                {
                },
                ["saveSettingsGlobally"] = true,
                ["bFilterOnSetName"] = false,
                ["frameSettings"] = 
                {
                    ["store"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["lastY"] = 300,
                        ["docked"] = true,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["alchemy"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["lastY"] = 300,
                        ["docked"] = true,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["guildBank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["lastY"] = 300,
                        ["docked"] = true,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["stables"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["lastY"] = 300,
                        ["docked"] = true,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["smithing"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["lastY"] = 300,
                        ["docked"] = true,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["inventory"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["lastY"] = 300,
                        ["docked"] = true,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["hud"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["lastY"] = 300,
                        ["docked"] = false,
                        ["hidden"] = true,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["trade"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["lastY"] = 300,
                        ["docked"] = true,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["bank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["lastY"] = 300,
                        ["docked"] = true,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                    ["tradinghouse"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["minimized"] = false,
                        ["lastY"] = 300,
                        ["docked"] = true,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["width"] = 380,
                    },
                },
                ["version"] = 1,
                ["b_collectHouses"] = false,
                ["in2TooltipsFont"] = "ZoFontGame",
                ["BagSpaceAlert"] = 
                {
                    ["threshold"] = 95,
                    ["b"] = 0,
                    ["g"] = 1,
                    ["r"] = 1,
                },
                ["bDebug"] = false,
            },
            ["8796093060264765"] = 
            {
                ["collectHouseData"] = 
                {
                },
                ["showItemStats"] = false,
                ["$LastCharacterName"] = "Sweepy Mcsweeperson",
                ["TooltipFontSize"] = 18,
                ["TooltipFontFace"] = "EsoUI/Common/Fonts/Univers57.otf",
                ["in2AgedGuildBankDataWarning"] = true,
                ["bAddContextMenuEntrySearchInIIfA"] = true,
                ["ShowToolTipWhen"] = "Always",
                ["dontFocusSearch"] = false,
                ["BagSpaceAlert"] = 
                {
                    ["threshold"] = 95,
                    ["b"] = 0,
                    ["g"] = 1,
                    ["r"] = 1,
                },
                ["bCollectGuildBankData"] = false,
                ["BagSpaceFull"] = 
                {
                    ["b"] = 0,
                    ["g"] = 0,
                    ["r"] = 255,
                },
                ["in2DefaultInventoryFrameView"] = "All",
                ["TooltipFontEffect"] = "soft-shadow-thin",
                ["FCOISshowMarkerIcons"] = false,
                ["bInSeparateFrame"] = true,
                ["showStyleInfo"] = true,
                ["ignoredCharEquipment"] = 
                {
                },
                ["hideCloseButton"] = false,
                ["DBv3"] = 
                {
                },
                ["BagSpaceWarn"] = 
                {
                    ["threshold"] = 85,
                    ["b"] = 0,
                    ["g"] = 0.5098039216,
                    ["r"] = 0.9019607843,
                },
                ["frameSettings"] = 
                {
                    ["store"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["alchemy"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["guildBank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["stables"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["smithing"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["inventory"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["hud"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = false,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = true,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["trade"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["bank"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                    ["tradinghouse"] = 
                    {
                        ["locked"] = false,
                        ["height"] = 798,
                        ["docked"] = true,
                        ["width"] = 380,
                        ["lastY"] = 300,
                        ["hidden"] = false,
                        ["lastX"] = 400,
                        ["minimized"] = false,
                    },
                },
                ["ignoredCharInventories"] = 
                {
                },
                ["showItemCountOnRight"] = true,
                ["bFilterOnSetName"] = false,
                ["saveSettingsGlobally"] = true,
                ["version"] = 1,
                ["b_collectHouses"] = false,
                ["in2TooltipsFont"] = "ZoFontGame",
                ["bFilterOnSetNameToo"] = false,
                ["bDebug"] = false,
            },
        },
    },
}
IIfA_Data =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["Data"] = 
                {
                    ["in2AgedGuildBankDataWarning"] = true,
                    ["NA"] = 
                    {
                        ["DBv3"] = 
                        {
                            ["|H1:item:121530:6:1:0:0:0:72:192:5:325:2:39:0:0:0:0:0:0:0:0:604800|h|h"] = 
                            {
                                ["itemName"] = "Sealed Woodworking Writ",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [38] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["27059"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:27059:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Bervez Juice",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27059] = 575,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["28636"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:28636:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rose",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [28636] = 675,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68222"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [204] = 2,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [102] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Bravil Bitter Barley Beer",
                                ["itemLink"] = "|H1:item:68222:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:97255:363:50:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Gloves of a Mother's Sorrow",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [76] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:57807:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Eastmarch",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [53] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["145532"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:145532:0:0:0:0:0:0:0:0:0:0:0:0:0:0:79:0:0:0:0:0|h|h",
                                ["itemName"] = "Crocodile Leather",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [145532] = 16,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:43629:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Auridon Treasure Map V",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [65] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["54170"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:54170:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Honing Stone",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54170] = 387,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["27048"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:27048:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Metheglin",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27048] = 1155,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57752:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Stormhaven",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [58] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["54172"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:54172:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Grain Solvent",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54172] = 142,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:139016:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Artaeum Pickled Fish Bowl",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [59] = 27,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["34349"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34349:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Acai Berry",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34349] = 554,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["140448"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140448:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Bows",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [139] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["156571"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:156571:0:0:0:0:0:0:0:0:0:0:0:0:0:0:92:0:0:0:0:0|h|h",
                                ["itemName"] = "Gilding Salts",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [156571] = 10,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["75339"] = 
                            {
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [5] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Large Stolen Shipment",
                                ["itemLink"] = "|H1:item:75339:175:1:0:0:0:0:0:0:0:0:0:0:0:17:0:0:1:1:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:121528:6:1:0:0:0:45875:207:5:0:0:0:0:0:0:0:0:0:0:0:60000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Enchanting Writ",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [48] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45823"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45823:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pojode",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45823] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:153739:4:1:0:0:0:18:255:3:323:29:0:0:0:0:0:0:0:0:0:288750|h|h"] = 
                            {
                                ["itemName"] = "Sealed Jewelry Crafter Writ",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [40] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:44815:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:262427|h|h"] = 
                            {
                                ["itemName"] = "Essence of Ravage Magicka",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [10] = 16,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57777:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Malabal Tor",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [10] = 1,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [6] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["44878"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:44878:121:40:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h",
                                ["itemName"] = "Greater Repair Kit",
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [52] = 11,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["181550"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [64] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Diagram: Vampiric Candlestick",
                                ["itemLink"] = "|H1:item:181550:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["34345"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34345:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Surilie Grapes",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34345] = 621,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:61079:122:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Repair Kit",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [39] = 10,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [98] = 10,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [63] = 15,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:76829:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:262144|h|h"] = 
                            {
                                ["itemName"] = "Damage Magicka Poison IX",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 1,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [14] = 4,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [5] = 79,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 11,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [107] = 14,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [58] = 15,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["64501"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64501:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Lorkhan's Tears",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64501] = 2152,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23138"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23138:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rough Nightwood",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23138] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:167264:5:1:0:0:0:0:0:0:0:0:0:0:0:1025:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Rune-Carved Bone Fragment",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [178] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68214"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68214:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Heart's Day Rose Tea",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [100] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:69808:369:50:26582:369:50:0:0:0:0:0:0:0:0:1:1:1:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Shoes of Julianos",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [106] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["140457"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140457:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Staves",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [79] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["140447"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140447:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Boots",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [115] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:135110:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Experience Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [24] = 2,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [2] = 1,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57743:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Stonefalls",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [93] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["121520"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:121520:0:0:0:0:0:0:0:0:0:0:0:0:0:0:50:0:0:0:0:0|h|h",
                                ["itemName"] = "Lustrous Sphalerite",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [121520] = 110,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["87688"] = 
                            {
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [116] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Witchmother's Party Punch",
                                ["itemLink"] = "|H1:item:87688:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["45839"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45839:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Dekeipa",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45839] = 135,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["135159"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135159:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pulverized Antimony",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135159] = 170,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:43699:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Bleakrock Treasure Map I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [93] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:110803:363:50:0:0:0:0:0:0:0:0:0:0:0:1:30:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Sash of the Worm Cult",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [17] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:171737:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Imperial Champion Axe",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [82] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:43645:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Malabal Tor Treasure Map III",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [17] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["34305"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34305:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pumpkin",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34305] = 526,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:94439:124:1:0:0:0:0:0:0:0:0:0:0:0:65:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Gold Coast Experience Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [36] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45829"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45829:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rede",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45829] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["64506"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64506:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rubedo Leather",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64506] = 2563,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:43628:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Auridon Treasure Map IV",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [24] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["114889"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:114889:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Regulus",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [114889] = 391,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:171741:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Imperial Champion Sword",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [92] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:68263:309:50:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Hagraven's Tonic",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [100] = 2,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [113] = 1,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [151] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["135146"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135146:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Platinum Ounce",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135146] = 4023,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57780:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Reaper's March",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [12] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["119385"] = 
                            {
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [62] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Design: Sugar Pumpkin, Wax",
                                ["itemLink"] = "|H1:item:119385:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["69555"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:69555:0:0:0:0:0:0:0:0:0:0:0:0:0:0:22:0:0:0:0:0|h|h",
                                ["itemName"] = "Cassiterite",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [69555] = 16,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:139424:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Stonefalls",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [74] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["56863"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:56863:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Potent Nirncrux",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [56863] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["71198"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71198:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rubedite Ore",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71198] = 5397,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:45357:308:50:0:0:0:0:0:0:0:0:0:0:0:0:9:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Rubedo Leather Boots",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [135] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["802"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:802:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rough Maple",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [802] = 191,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:43698:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Khenarthi's Roost Treasure Map IV",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [64] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:136990:363:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:3215:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Belt",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [6] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:135127:123:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Gold Coast Warrior Elixir",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [64] = 25,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["30164"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30164:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Columbine",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30164] = 468,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57826:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: The Rift",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [101] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["45854"] = 
                            {
                                ["itemQuality"] = 5,
                                ["itemLink"] = "|H1:item:45854:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Kuta",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45854] = 104,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:33265:30:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Soul Gem (Empty)",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [26] = 54,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 136,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [105] = 155,
                                            [6] = 200,
                                            [91] = 200,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [79] = 191,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 139,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [16] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:147513:363:50:45883:370:50:33:0:0:0:0:0:0:0:1:23:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Deadly Necklace",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [83] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["45833"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45833:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Deni",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45833] = 148,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:94440:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Major Gold Coast Experience Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [184] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["54174"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:54174:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Hemming",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54174] = 363,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:126111:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Vvardenfell",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [47] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:135124:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Instant All Research",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [38] = 1,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [22] = 1,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [80] = 1,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [91] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68194"] = 
                            {
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [212] = 3,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [114] = 2,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Tomato Garlic Chutney",
                                ["itemLink"] = "|H1:item:68194:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:43650:4:1:0:0:0:0:0:0:0:0:0:0:0:16:0:0:0:1:0:0|h|h"] = 
                            {
                                ["itemName"] = "Reaper's March Treasure Map II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [48] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["160575"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:160575:0:0:0:0:0:0:0:0:0:0:0:0:0:0:102:0:0:0:0:0|h|h",
                                ["itemName"] = "Sea Snake Fang",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [160575] = 12,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["75358"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:75358:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ichor",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [75358] = 84,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:147318:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Sai Sahan's Arm Cops",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [232] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["23103"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23103:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Orichalcum Ore",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23103] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:153780:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Glenmoril Wyrd Sash",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [80] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["135142"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135142:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Silver Ounce",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135142] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["182543"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:182543:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 113: Steadfast Society Daggers",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [110] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68215"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68215:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Soothing Bard's-Throat Tea",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [224] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["152235"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:152235:0:0:0:0:0:0:0:0:0:0:0:0:0:0:86:0:0:0:0:0|h|h",
                                ["itemName"] = "Frost Embers",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [152235] = 23,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:79691:6:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Gold Coast Trapping Poison",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [157] = 50,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:153739:4:1:0:0:0:24:255:3:241:22:0:0:0:1025:0:0:1:0:0:262500|h|h"] = 
                            {
                                ["itemName"] = "Sealed Jewelry Crafter Writ",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [95] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["34335"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34335:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Yerba Mate",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34335] = 588,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["33773"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33773:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Mint",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33773] = 578,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:149977:362:50:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "False God's Ring",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [32] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:97229:364:50:0:0:0:3:0:0:0:0:0:0:0:2049:6:0:1:0:473:0|h|h"] = 
                            {
                                ["itemName"] = "Lightning Staff of a Mother's Sorrow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [149] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:54340:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:197919|h|h"] = 
                            {
                                ["itemName"] = "Essence of Magicka",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [55] = 138,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57804:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Rivenspire",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [56] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["141821"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:141821:0:0:0:0:0:0:0:0:0:0:0:0:0:0:78:0:0:0:0:0|h|h",
                                ["itemName"] = "Argent Pelt",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [141821] = 21,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["114890"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:114890:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Bast",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [114890] = 436,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["119199"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [81] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Pattern: Redguard Tapestry, Lattice",
                                ["itemLink"] = "|H1:item:119199:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57773:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Stormhaven",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [38] = 1,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [190] = 1,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [7] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["68197"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68197:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Tenmar Millet-Carrot Couscous",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [211] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:69908:369:50:26582:370:50:0:0:0:0:0:0:0:0:1:45:1:1:0:9550:0|h|h"] = 
                            {
                                ["itemName"] = "Jerkin of Julianos",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [2] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:45356:308:50:0:0:0:0:0:0:0:0:0:0:0:0:7:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Rubedo Leather Jack",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [196] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:133875:362:50:0:0:0:0:0:0:0:0:0:0:0:1:4:0:1:0:300:0|h|h"] = 
                            {
                                ["itemName"] = "The Master's Inferno Staff",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [55] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:43718:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Cyrodiil Treasure Map XVI",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [22] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["45832"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45832:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Makko",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45832] = 107,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:86783:363:50:26582:370:50:0:0:0:0:0:0:0:0:1:6:0:1:0:7342:0|h|h"] = 
                            {
                                ["itemName"] = "Breeches of Necropotence",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [65] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["45813"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45813:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rera",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45813] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68220"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:68220:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Port Hunding Pinot Noir",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [222] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:135119:124:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Oblivious: Cheerful Cliff Racer",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [61] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["137957"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:137957:0:0:0:0:0:0:0:0:0:0:0:0:0:0:74:0:0:0:0:0|h|h",
                                ["itemName"] = "Warrior's Heart Ashes",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [137957] = 54,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:87695:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ghastly Eye Bowl",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 88,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:153871:124:1:0:0:0:0:0:0:0:0:0:0:0:1025:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Attunable Blacksmithing Station, Bound",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [111] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:136950:363:50:45883:370:50:31:0:0:0:0:0:0:0:1:73:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Necklace",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:136968:359:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Guards",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [35] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["64690"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64690:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Malachite Shard",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64690] = 38,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:141731:6:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Keep Recall Stone",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [77] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:137174:362:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Siroria's Sash",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [130] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["26954"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:26954:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Garlic",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [26954] = 912,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["27064"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:27064:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Millet",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27064] = 939,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:149837:364:50:0:0:0:26:0:0:0:0:0:0:0:1:86:0:1:0:313:0|h|h"] = 
                            {
                                ["itemName"] = "Lokkestiiz's Axe",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [13] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["30154"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30154:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "White Cap",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30154] = 294,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:27037:2:44:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Philter of Magicka",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [28] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:87959:364:50:0:0:0:26:0:0:0:0:0:0:0:1:23:0:1:0:161:0|h|h"] = 
                            {
                                ["itemName"] = "Deadly Axe",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [124] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["114895"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:114895:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Heartwood",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [114895] = 360,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:135112:123:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Refreshing Drink",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [16] = 1,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [19] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119563:5:1:0:0:0:53:188:4:387:2:70:0:0:0:0:0:0:0:0:72000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Blacksmithing Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [122] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["30155"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30155:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Luminous Russula",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30155] = 269,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:123409:363:50:0:0:0:0:0:0:0:0:0:0:0:1:50:0:1:0:3475:0|h|h"] = 
                            {
                                ["itemName"] = "Coward's Gear Belt",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [6] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["42877"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:42877:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Simple Bait",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [42877] = 198,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["71740"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71740:0:0:0:0:0:0:0:0:0:0:0:0:0:0:24:0:0:0:0:0|h|h",
                                ["itemName"] = "Dragon Scute",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71740] = 37,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["803"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:803:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sanded Maple",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [803] = 2930,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["46136"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46136:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Iron Hide",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46136] = 181,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["42871"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:42871:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crawlers, Foul Bait",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [42871] = 1399,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["76910"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:76910:0:0:0:0:0:0:0:0:0:0:0:0:0:0:46:0:0:0:0:0|h|h",
                                ["itemName"] = "Tainted Blood",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [76910] = 22,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68340"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:68340:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Itade",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [68340] = 171,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:159480:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Jephrine Paladin Shield",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [217] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:152576:363:50:0:0:0:0:0:0:0:0:0:0:0:1:93:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Hollowfang Gloves",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [47] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["79304"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:79304:0:0:0:0:0:0:0:0:0:0:0:0:0:0:12:0:0:0:0:0|h|h",
                                ["itemName"] = "Black Beeswax",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [79304] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:43614:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alik'r Treasure Map II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [48] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["71668"] = 
                            {
                                ["itemQuality"] = 5,
                                ["itemLink"] = "|H1:item:71668:0:0:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h",
                                ["itemName"] = "Crown Mimic Stone",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71668] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["16291"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:16291:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Citrine",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [16291] = 252,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:43661:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Deshaan Treasure Map I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [65] = 1,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [14] = 1,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [56] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:119694:5:1:0:0:0:34:194:4:80:17:71:0:0:0:0:0:0:0:0:68250|h|h"] = 
                            {
                                ["itemName"] = "Sealed Clothier Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [12] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["46133"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46133:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Silverweave",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46133] = 324,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:151600:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Northern Elsweyr",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [90] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:57788:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Greenshade",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [26] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["23203"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23203:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Chysolite",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23203] = 269,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:135130:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Attribute Respecification Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [30] = 1,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [89] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["160592"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:160592:0:0:0:0:0:0:0:0:0:0:0:0:0:0:103:0:0:0:0:0|h|h",
                                ["itemName"] = "Etched Corundum",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [160592] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["34330"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34330:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Lotus",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34330] = 616,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45834"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45834:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Okoma",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45834] = 109,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:149994:364:50:0:0:0:18:0:0:0:0:0:0:0:1:86:0:1:0:7659:0|h|h"] = 
                            {
                                ["itemName"] = "False God's Gloves",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [16] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["54173"] = 
                            {
                                ["itemQuality"] = 5,
                                ["itemLink"] = "|H1:item:54173:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Tempering Alloy",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54173] = 37,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23095"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23095:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Leather Scraps",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23095] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:68236:309:50:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Firsthold Fruit and Cheese Plate",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [39] = 2,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [114] = 1,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [26] = 2,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [83] = 2,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [36] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["181553"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [65] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Formula: Vampiric Lab Jar, Large",
                                ["itemLink"] = "|H1:item:181553:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:45052:359:50:5365:359:50:0:0:0:0:0:0:0:0:0:3:0:0:0:250:0|h|h"] = 
                            {
                                ["itemName"] = "Ruby Ash Restoration Staff of Frost",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [145] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:57757:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Greenshade",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [41] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:119681:5:1:0:0:0:70:192:4:351:1:56:0:0:0:0:0:0:0:0:66000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Woodworking Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [130] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["34324"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34324:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Carrots",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34324] = 316,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["79672"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:79672:0:0:0:0:0:0:0:0:0:0:0:0:0:0:45:0:0:0:0:0|h|h",
                                ["itemName"] = "Defiled Whiskers",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [79672] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57829:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Coldharbour II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [144] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:166036:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blackreach: Greymoor Caverns CE Treasure Map I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:119563:5:1:0:0:0:59:188:4:219:1:51:0:0:0:0:0:0:0:0:72000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Blacksmithing Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [30] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:139408:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Stormhaven",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [75] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["82025"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82025:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Boots",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [154] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:64537:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Experience Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [75] = 10,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:126122:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Vvardenfell",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [60] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:54511:365:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Platinum Ring",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [67] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:81166:363:50:0:0:0:0:0:0:0:0:0:0:0:1:35:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ring Of The Infallible Aether",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [59] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["23171"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23171:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Garnet",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23171] = 538,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:159479:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Jephrine Paladin Bow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [91] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:42867:25:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Dhufish",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [64] = 45,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:135111:123:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Gold Coast Swift Survivor Elixir",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [14] = 25,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [17] = 25,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["135161"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135161:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ochre",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135161] = 150,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:45322:308:50:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Rubedo Leather Boots",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [85] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["54181"] = 
                            {
                                ["itemQuality"] = 5,
                                ["itemLink"] = "|H1:item:54181:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rosin",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54181] = 52,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["28604"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:28604:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Greens",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [28604] = 269,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["54176"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:54176:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Elegant Lining",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54176] = 159,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["139019"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:139019:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Powdered Mother of Pearl",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [139019] = 66,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["121519"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:121519:0:0:0:0:0:0:0:0:0:0:0:0:0:0:51:0:0:0:0:0|h|h",
                                ["itemName"] = "Wrought Ferrofungus",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [121519] = 7,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["794"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:794:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rawhide",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [794] = 714,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["145533"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:145533:0:0:0:0:0:0:0:0:0:0:0:0:0:0:81:0:0:0:0:0|h|h",
                                ["itemName"] = "Hackwing Plumage",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [145533] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45625"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:45625:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: High Rock Rose and Rye",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [220] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45853"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:45853:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rekuta",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45853] = 262,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["56862"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:56862:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Fortified Nirncrux",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [56862] = 26,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:79690:6:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Lethal Poison",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [28] = 1000,
                                            [117] = 150,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["135139"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135139:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Copper Dust",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135139] = 227,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["75359"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:75359:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Slime",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [75359] = 210,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["76911"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:76911:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Dried Blood",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [76911] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["71696"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:71696:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 25: Aldmeri Dominion Helmets",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [68] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119701:5:1:0:0:0:199:27:1:4:0:0:0:0:0:0:0:0:0:0:50000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Alchemy Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [103] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["135149"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:135149:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Zircon Plating",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135149] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["140453"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140453:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Legs",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [98] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45654"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [106] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Red Deer Stew",
                                ["itemLink"] = "|H1:item:45654:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:136984:363:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:5705:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Jack",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [2] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["64502"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64502:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sanded Ruby Ash",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64502] = 472,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:147313:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Lyris Titanborn's Girdle",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [216] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["42875"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:42875:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Chub, Saltwater Bait",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [42875] = 76,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["140445"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140445:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Axes",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [77] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["150672"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:150672:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crimson Nirnroot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [150672] = 22,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["82034"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82034:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Shoulders",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [161] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["178544"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:178544:0:0:0:0:0:0:0:0:0:0:0:0:0:0:125:0:0:0:0:0|h|h",
                                ["itemName"] = "Blaze-Veined Prism",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [178544] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:129710:364:50:0:0:0:0:0:0:0:0:0:0:0:1:37:0:1:0:500:0|h|h"] = 
                            {
                                ["itemName"] = "Briarheart Axe",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [4] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["4456"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:4456:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Quartz",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [4456] = 519,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:64706:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Recipe: Psijic Ambrosia, Fragment IV",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [11] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["114892"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:114892:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Mundane Rune",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [114892] = 386,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["151621"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:151621:0:0:0:0:0:0:0:0:0:0:0:0:0:0:84:0:0:0:0:0|h|h",
                                ["itemName"] = "Shimmering Sand",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [151621] = 34,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["27035"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:27035:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Isinglass",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27035] = 682,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:64703:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Recipe: Psijic Ambrosia, Fragment I",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [208] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68192"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68192:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Firsthold Fruit and Cheese Plate",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [205] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["71239"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71239:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rubedo Hide Scraps",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71239] = 2794,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["33258"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33258:0:0:0:0:0:0:0:0:0:0:0:0:0:0:2:0:0:0:0:0|h|h",
                                ["itemName"] = "Starmetal",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33258] = 192,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:135113:122:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Repair Kit",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [15] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:153739:4:1:0:0:0:18:255:3:323:22:0:0:0:0:0:0:0:0:0:275000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Jewelry Crafter Writ",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [34] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:151617:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Northern Elsweyr Treasure Map V",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [28] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["139416"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:139416:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pulverized Titanium",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [139416] = 55,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:69805:369:50:26582:369:50:0:0:0:0:0:0:0:0:1:1:1:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Gloves of Julianos",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [145] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:57759:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Rivenspire",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [44] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:43736:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Gold Coast Treasure Map II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [68] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:45339:308:50:0:0:0:0:0:0:0:0:0:0:0:0:8:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Rubedite Dagger",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [72] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["135138"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135138:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pewter Ounce",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135138] = 853,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["16427"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:16427:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 6: Redguard Style",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [39] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45850"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ta",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45850] = 324,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:64709:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Recipe: Psijic Ambrosia, Fragment VII",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [143] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["4442"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:4442:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Emerald",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [4442] = 398,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["30219"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:30219:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Bloodstone",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30219] = 598,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["6000"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:6000:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Dwarven Ingot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [6000] = 429,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["82028"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82028:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Daggers",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [157] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["23204"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23204:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Amethyst",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23204] = 245,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["28610"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:28610:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jazbay Grapes",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [28610] = 676,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:126110:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Vvardenfell",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [219] = 1,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [33] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:64705:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Recipe: Psijic Ambrosia, Fragment III",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [150] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68201"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:68201:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Sticky Pork and Radish Noodles",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [210] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["30156"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30156:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Imp Stool",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30156] = 209,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["30148"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30148:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Blue Entoloma",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30148] = 420,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:97311:364:50:26848:370:50:3:0:0:0:0:0:0:0:1:6:0:1:0:421:0|h|h"] = 
                            {
                                ["itemName"] = "Inferno Staff of a Mother's Sorrow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [4] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["135153"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:135153:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Zircon Grains",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135153] = 60,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:156839:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Jephrine Paladin Cuirass",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [84] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119694:5:1:0:0:0:34:194:4:51:18:84:0:0:0:0:0:0:0:0:57750|h|h"] = 
                            {
                                ["itemName"] = "Sealed Clothier Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [73] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["23142"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23142:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Topgrain Hide Scraps",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23142] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["34309"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34309:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Beets",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34309] = 531,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["71766"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71766:0:0:0:0:0:0:0:0:0:0:0:0:0:0:30:0:0:0:0:0|h|h",
                                ["itemName"] = "Azure Plasm",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71766] = 64,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57790:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Rivenspire",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [29] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:166462:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Western Skyrim",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [61] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["33768"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33768:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Comberry",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33768] = 775,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:137171:364:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Siroria's Breeches",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [126] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["87694"] = 
                            {
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [118] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Witchmother's Potent Brew",
                                ["itemLink"] = "|H1:item:87694:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["71742"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71742:0:0:0:0:0:0:0:0:0:0:0:0:0:0:23:0:0:0:0:0|h|h",
                                ["itemName"] = "Lion Fang",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71742] = 31,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["27052"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:27052:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ginger",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27052] = 1306,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:166215:363:50:0:0:0:0:0:0:0:0:0:0:0:1:14:0:1:0:400:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Perfected Inferno Staff",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [78] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["64489"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64489:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rubedite Ingot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64489] = 2312,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119680:5:1:0:0:0:46:188:4:224:18:4:0:0:0:0:0:0:0:0:51250|h|h"] = 
                            {
                                ["itemName"] = "Sealed Blacksmithing Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [47] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:97217:364:50:45884:370:50:31:0:0:0:0:0:0:0:1:6:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ring of a Mother's Sorrow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [12] = 1,
                                            [11] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:69806:369:50:26582:369:50:0:0:0:0:0:0:0:0:1:1:1:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Sash of Julianos",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [104] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["4487"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:4487:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Steel Ingot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [4487] = 1709,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["46129"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46129:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Quicksilver Ingot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46129] = 353,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:120076:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Aetherial Ambrosia",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 15,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [6] = 10,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:135120:124:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Darkening: Dark of the Moons",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [76] = 1,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [45] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:27038:307:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Essence of Stamina",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [61] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:166035:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Western Skyrim CE Treasure Map",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [22] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:69913:369:50:26582:370:50:0:0:0:0:0:0:0:0:1:4:1:1:0:7450:0|h|h"] = 
                            {
                                ["itemName"] = "Shoes of Julianos",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["125476"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:125476:0:0:0:0:0:0:0:0:0:0:0:0:0:0:54:0:0:0:0:0|h|h",
                                ["itemName"] = "Ash Canvas",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [125476] = 23,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["145993"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:145993:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Blueprint: Murkmire Wardrobe, Woven",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [199] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:125474:124:1:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Research Scroll, Clothing, 1 Day",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [19] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57749:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Stormhaven",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [31] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:44812:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:131072|h|h"] = 
                            {
                                ["itemName"] = "Essence of Ravage Health",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [22] = 2,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [31] = 3,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [3] = 21,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [102] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:139660:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Exemplary Infused Necklace",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [79] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["64509"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64509:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rejera",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64509] = 398,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:164291:364:50:0:0:0:0:0:0:0:0:0:0:0:1:10:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Thrassian Stranglers",
                                ["itemQuality"] = 6,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [41] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:43549:365:50:0:0:0:0:0:0:0:0:0:0:0:0:8:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ruby Ash Bow",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [179] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["167286"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:167286:0:0:0:0:0:0:0:0:0:0:0:0:0:0:110:0:0:0:0:0|h|h",
                                ["itemName"] = "Etched Bronze",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [167286] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:149830:363:50:0:0:0:0:0:0:0:0:0:0:0:1:86:0:1:0:3300:0|h|h"] = 
                            {
                                ["itemName"] = "Lokkestiiz's Jack",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [31] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:97254:363:50:0:0:0:0:0:0:0:0:0:0:0:1:6:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Shoes of a Mother's Sorrow",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [105] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["119170"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:119170:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pattern: Redguard Couch, Padded",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [202] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["27058"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:27058:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Seasoning",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27058] = 1243,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["46141"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46141:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sanded Mahogany",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46141] = 390,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:106520:363:50:0:0:0:0:0:0:0:0:0:0:0:1:26:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ring of the Undaunted Infiltrator",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [15] = 1,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [55] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["46152"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:15:0:0:0:0:0|h|h",
                                ["itemName"] = "Palladium",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46152] = 136,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57734:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Glenumbra",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [54] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["1187"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:1187:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Clear Water",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [1187] = 180,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:68235:309:50:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Lilmoth Garlic Hagfish",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [98] = 2,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [15] = 1,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [146] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68217"] = 
                            {
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [206] = 5,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [105] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Fredas Night Infusion",
                                ["itemLink"] = "|H1:item:68217:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:139442:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Wrothgar II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [3] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:142601:363:50:26583:370:50:0:0:0:0:0:0:0:0:1:81:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Bright-Throat's Boast Necklace",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["135147"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:135147:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Terne Plating",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135147] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["5820"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:5820:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "High Iron Ore",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [5820] = 19,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45808"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45808:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pojora",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45808] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["29030"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:29030:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rice",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [29030] = 575,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:80275:363:50:0:0:0:0:0:0:0:0:0:0:0:1:35:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Gloves Of The Infallible Aether",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [187] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:159474:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Jephrine Paladin Pauldrons",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [85] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:45331:308:50:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ruby Ash Lightning Staff",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [194] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["45817"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45817:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jode",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45817] = 39,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:153777:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Glenmoril Wyrd Hat",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [142] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45811"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45811:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pora",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45811] = 7,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["54180"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:54180:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Mastic",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54180] = 202,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45826"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45826:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Idode",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45826] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["42874"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:42874:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Shad, River Bait",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [42874] = 112,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:100271:359:50:0:0:0:0:0:0:0:0:0:0:0:1:5:0:1:0:5206:0|h|h"] = 
                            {
                                ["itemName"] = "Fiord's Arm Cops",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [3] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:156716:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Southern Elsweyr Treasure Map I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [96] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:86779:363:50:26582:370:50:0:0:0:0:0:0:0:0:1:6:0:1:0:5867:0|h|h"] = 
                            {
                                ["itemName"] = "Robe of Necropotence",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [67] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["75373"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:75373:0:0:0:0:0:0:0:0:0:0:0:0:0:0:31:0:0:0:0:0|h|h",
                                ["itemName"] = "Pristine Shroud",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [75373] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:167245:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Grave Dancer Bow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [111] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:27036:2:44:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Philter of Health",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [58] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:139441:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Wrothgar I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [79] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["6001"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:6001:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ebony Ingot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [6001] = 447,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:153646:6:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Glenmoril Wyrd Treasure Map: Rivenspire",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [165] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:166460:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Western Skyrim",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [34] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["71584"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71584:0:0:0:0:0:0:0:0:0:0:0:0:0:0:13:0:0:0:0:0|h|h",
                                ["itemName"] = "Potash",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71584] = 22,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57793:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Reaper's March",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [28] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:120891:123:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Sparkly Hat Dazzler",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [152] = 12,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["46137"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46137:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Superb Hide",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46137] = 124,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:102478:362:50:0:0:0:0:0:0:0:0:0:0:0:1:3:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Sash of Sanctuary",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [33] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:100212:363:50:0:0:0:0:0:0:0:0:0:0:0:1:5:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Fiord's Necklace",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["139417"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:139417:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pulverized Aurbic Amber",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [139417] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:80119:363:50:0:0:0:0:0:0:0:0:0:0:0:1:35:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Jack Of The Vicious Ophidian",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [67] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:133722:364:50:54484:370:50:0:0:0:0:0:0:0:0:1:14:0:1:0:424:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Inferno Staff",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [73] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:141847:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Animal Bones, Gnawed",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [122] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 21,
                            },
                            ["|H1:item:94574:364:50:26588:370:50:18:0:0:0:0:0:0:0:1:67:0:1:0:7855:0|h|h"] = 
                            {
                                ["itemName"] = "Selene's Visage",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["28609"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:28609:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Game",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [28609] = 573,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:151601:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Northern Elsweyr",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [11] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:44714:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:856325|h|h"] = 
                            {
                                ["itemName"] = "Essence of Weapon Power",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [7] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["46139"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46139:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sanded Birch",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46139] = 42,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:51547:369:50:26588:370:50:0:0:0:0:0:0:0:0:1:2:1:1:0:6290:0|h|h"] = 
                            {
                                ["itemName"] = "Belt of Hunding's Rage",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [80] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:43735:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Gold Coast Treasure Map I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [95] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["182570"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:182570:0:0:0:0:0:0:0:0:0:0:0:0:0:0:132:0:0:0:0:0|h|h",
                                ["itemName"] = "High Isle Filigree",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [182570] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:156362:369:50:26582:370:50:0:0:0:0:0:0:0:0:1:20:1:1:0:9575:0|h|h"] = 
                            {
                                ["itemName"] = "New Moon Acolyte's Gauntlets",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [16] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:97229:363:50:0:0:0:6:0:0:0:0:0:0:0:2049:6:0:1:0:162:0|h|h"] = 
                            {
                                ["itemName"] = "Lightning Staff of a Mother's Sorrow",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [148] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:54340:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:196608|h|h"] = 
                            {
                                ["itemName"] = "Essence of Magicka",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [97] = 2,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 14,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [13] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:68257:309:50:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Markarth Mead",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [63] = 1,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [183] = 2,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [5] = 2,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [111] = 2,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [109] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:153739:4:1:0:0:0:24:255:3:148:30:0:0:0:0:0:0:0:0:0:288750|h|h"] = 
                            {
                                ["itemName"] = "Sealed Jewelry Crafter Writ",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [128] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:64487:123:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Key Fragment",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 200,
                                            [107] = 157,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:136990:362:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Belt",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [23] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:76826:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:66816|h|h"] = 
                            {
                                ["itemName"] = "Drain Health Poison IX",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [98] = 12,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [3] = 5,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [4] = 65,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [36] = 13,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["75357"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:75357:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Grease",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [75357] = 1104,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:71164:364:50:54484:370:50:4:0:0:0:0:0:0:0:2049:14:0:1:0:439:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Lightning Staff",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [131] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["134798"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:134798:0:0:0:0:0:0:0:0:0:0:0:0:0:0:55:0:0:0:0:0|h|h",
                                ["itemName"] = "Desecrated Grave Soil",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [134798] = 94,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["82023"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82023:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Axes",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [152] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68213"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68213:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Markarth Mead",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [149] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["151907"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:151907:0:0:0:0:0:0:0:0:0:0:0:0:0:0:82:0:0:0:0:0|h|h",
                                ["itemName"] = "Goblin-Cloth Scrap",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [151907] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["34321"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34321:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Poultry",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34321] = 486,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:147512:363:50:26589:370:50:31:0:0:0:0:0:0:0:1:23:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Deadly Ring",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [85] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:68244:310:50:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Solitude Salmon-Millet Soup",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [40] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:71142:364:50:0:0:0:4:0:0:0:0:0:0:0:2049:14:0:1:0:497:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Bow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [86] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:150017:364:50:0:0:0:0:0:0:0:0:0:0:0:1:86:0:1:0:7145:0|h|h"] = 
                            {
                                ["itemName"] = "False God's Breeches",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["4478"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:4478:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Shadowhide Scraps",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [4478] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:27038:2:44:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Philter of Stamina",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [22] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["156596"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:156596:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 78: Moongrave Fane Daggers",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [40] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:33271:31:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Soul Gem",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [25] = 79,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 120,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 200,
                                            [2] = 200,
                                            [52] = 200,
                                            [89] = 200,
                                            [90] = 66,
                                            [56] = 200,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [56] = 200,
                                            [180] = 89,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [4] = 200,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 16,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [2] = 200,
                                            [29] = 151,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:153644:6:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Glenmoril Wyrd Treasure Map: Malabal Tor",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [67] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:137162:364:50:26848:370:50:3:0:0:0:0:0:0:0:1:73:0:1:0:423:0|h|h"] = 
                            {
                                ["itemName"] = "Siroria's Inferno Staff",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [127] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["82036"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82036:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Swords",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [163] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["132196"] = 
                            {
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [82] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Pattern: Witches Corpse, Wrapped",
                                ["itemLink"] = "|H1:item:132196:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["4482"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:4482:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Calcinium Ore",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [4482] = 30,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:139440:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Eastmarch",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [66] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["45838"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45838:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rakeipa",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45838] = 133,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:97313:364:50:26848:370:50:0:0:0:0:0:0:0:0:1:6:0:1:0:125:0|h|h"] = 
                            {
                                ["itemName"] = "Lightning Staff of a Mother's Sorrow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [101] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:86781:363:50:26582:370:50:0:0:0:0:0:0:0:0:1:6:0:1:0:6646:0|h|h"] = 
                            {
                                ["itemName"] = "Gloves of Necropotence",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [66] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["140450"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140450:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Daggers",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [78] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:121532:6:1:0:0:0:26:194:5:41:14:83:0:0:0:0:0:0:0:0:768000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Clothier Writ",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [125] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68224"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:68224:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Camlorn Sweet Brown Ale",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [193] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["23122"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23122:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sanded Hickory",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23122] = 504,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:123407:363:50:0:0:0:0:0:0:0:0:0:0:0:1:50:0:1:0:8822:0|h|h"] = 
                            {
                                ["itemName"] = "Coward's Gear Guards",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:71088:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Wrothgar III",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [19] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["46127"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46127:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Calcinium Ingot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46127] = 275,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["33771"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33771:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jasmine",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33771] = 622,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:94522:363:50:0:0:0:0:0:0:0:0:0:0:0:1:67:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Infernal Guardian's Visage",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [189] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["137958"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:137958:0:0:0:0:0:0:0:0:0:0:0:0:0:0:69:0:0:0:0:0|h|h",
                                ["itemName"] = "Dragon Bone",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [137958] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:166464:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Western Skyrim",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [78] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:94828:363:50:0:0:0:12:0:0:0:0:0:0:0:1:67:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Pirate Skeleton's Guise",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [150] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:151598:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Northern Elsweyr",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [35] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:76831:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:393216|h|h"] = 
                            {
                                ["itemName"] = "Damage Stamina Poison IX",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [53] = 12,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [4] = 5,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [3] = 70,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [65] = 14,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45822"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45822:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Edode",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45822] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:81196:307:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Cloudy Hindering Poison IX",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [21] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["135006"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135006:175:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h",
                                ["itemName"] = "Cyrodiil Defense Crate",
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [40] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45837"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45837:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Kuoko",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45837] = 110,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:159478:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Jephrine Paladin Greatsword",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [218] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:135128:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Skill Respecification Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [29] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:167249:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Grave Dancer Greatsword",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [176] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:167170:5:1:0:0:0:33813:0:0:0:0:0:0:0:0:0:0:0:0:0:10000|h|h"] = 
                            {
                                ["itemName"] = "Imperial Charity Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [43] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["139415"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:139415:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pulverized Dawn-Prism",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [139415] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:135123:6:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Gold Coast Draining Poison",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [52] = 80,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["34334"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34334:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Bittergreen",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34334] = 603,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["135157"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135157:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Zinc",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135157] = 32,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:97217:364:50:45884:370:50:0:0:0:0:0:0:0:0:1:6:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ring of a Mother's Sorrow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [130] = 1,
                                            [133] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["23097"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23097:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Fell Hide Scraps",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23097] = 12,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23100"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23100:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Thick Leather",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23100] = 154,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:95264:363:50:26582:370:50:0:0:0:0:0:0:0:0:1:67:0:1:0:7717:0|h|h"] = 
                            {
                                ["itemName"] = "Grothdarr's Arm Cops",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [3] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:61080:32:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Soul Gem",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [12] = 8,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:118004:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Common Basket, Closed",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [121] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 21,
                            },
                            ["|H1:item:150013:364:50:0:0:0:0:0:0:0:0:0:0:0:1:86:0:1:0:8160:0|h|h"] = 
                            {
                                ["itemName"] = "False God's Robe",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [2] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:97255:363:50:0:0:0:0:0:0:0:0:0:0:0:1:6:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Gloves of a Mother's Sorrow",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [123] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["30162"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30162:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Dragonthorn",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30162] = 244,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["33256"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33256:0:0:0:0:0:0:0:0:0:0:0:0:0:0:5:0:0:0:0:0|h|h",
                                ["itemName"] = "Corundum",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33256] = 205,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:153778:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Glenmoril Wyrd Breeches",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [108] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["54171"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:54171:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Dwarven Oil",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54171] = 443,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23123"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23123:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sanded Yew",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23123] = 435,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["42870"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:42870:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Guts, Lake Bait",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [42870] = 669,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["33774"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33774:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Yeast",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33774] = 767,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68206"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:68206:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Late Hearthfire Vegetable Tart",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [221] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["34347"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34347:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ginseng",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34347] = 926,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:71069:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Wrothgar II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [49] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["114893"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:114893:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Alchemical Resin",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [114893] = 734,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:76827:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:138240|h|h"] = 
                            {
                                ["itemName"] = "Damage Health Poison IX",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [13] = 259,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [13] = 224,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["181554"] = 
                            {
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [77] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Formula: Vampiric Lab Jar, Small",
                                ["itemLink"] = "|H1:item:181554:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["141740"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:141740:0:0:0:0:0:0:0:0:0:0:0:0:0:0:73:0:0:0:0:0|h|h",
                                ["itemName"] = "Gryphon Plume",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [141740] = 21,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:159481:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Jephrine Paladin Staff",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [75] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:97269:359:50:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:250:0|h|h"] = 
                            {
                                ["itemName"] = "Inferno Staff of a Mother's Sorrow",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [102] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:141849:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Animal Bones, Fresh",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [123] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 21,
                            },
                            ["|H1:item:57825:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Reaper's March",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [91] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["170147"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:170147:0:0:0:0:0:0:0:0:0:0:0:0:0:0:114:0:0:0:0:0|h|h",
                                ["itemName"] = "Etched Nickel",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [170147] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["28639"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:28639:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rye",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [28639] = 471,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["42876"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:42876:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Minnow, Lake Bait",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [42876] = 119,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:71304:363:50:45883:370:50:0:0:0:0:0:0:0:0:1:37:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Briarheart Collar",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [23] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["34311"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34311:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Apples",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34311] = 766,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119700:5:1:0:0:0:199:29:9:6:0:0:0:0:0:0:0:0:0:0:50000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Alchemy Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [146] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["135158"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135158:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pulverized Cobalt",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135158] = 143,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:27962:175:1:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Keep Door Woodwork Repair Kit",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [29] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119818:5:1:0:0:0:199:2:4:6:0:0:0:0:0:0:0:0:0:0:50000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Alchemy Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [151] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:129562:363:50:26582:370:50:0:0:0:0:0:0:0:0:1:67:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Zaan's Mask",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [134] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:97035:363:50:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Plague Doctor's Ring",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [102] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["132618"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:132618:0:0:0:0:0:0:0:0:0:0:0:0:0:0:66:0:0:0:0:0|h|h",
                                ["itemName"] = "Tenebrous Cord",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [132618] = 21,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57803:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Shadowfen",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [57] = 1,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [55] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:188194:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: High Isle",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [128] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["30152"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Violet Coprinus",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30152] = 110,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:110206:364:50:0:0:0:0:0:0:0:0:0:0:0:1:32:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Overwhelming Necklace",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [13] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:57791:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Malabal Tor",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [27] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:104525:363:50:0:0:0:0:0:0:0:0:0:0:0:1:20:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Burning Spellweave Sash",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [41] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["23125"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23125:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Cotton",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23125] = 465,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57742:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Glenumbra",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [86] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["71199"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71199:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rough Ruby Ash",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71199] = 5122,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["34348"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34348:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Wheat",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34348] = 1062,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23121"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23121:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sanded Beech",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23121] = 426,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["27057"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:27057:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Cheese",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27057] = 980,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["64689"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64689:0:0:0:0:0:0:0:0:0:0:0:0:0:0:28:0:0:0:0:0|h|h",
                                ["itemName"] = "Malachite",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64689] = 15,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:45347:365:50:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ancestor Silk Robe",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [139] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:153874:124:1:0:0:0:0:0:0:0:0:0:0:0:1025:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Attunable Clothing Station, Bound",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [112] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["115026"] = 
                            {
                                ["itemQuality"] = 5,
                                ["itemLink"] = "|H1:item:115026:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Aetherial Dust",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [115026] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["77589"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:77589:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Scrib Jelly",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [77589] = 138,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:150041:364:50:0:0:0:18:0:0:0:0:0:0:0:1:86:0:1:0:8286:0|h|h"] = 
                            {
                                ["itemName"] = "False God's Sash",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [6] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:57820:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Shadowfen",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [92] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:147929:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Mummified Alfiq Parts",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [25] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:149993:364:50:0:0:0:18:0:0:0:0:0:0:0:1:86:0:1:0:8194:0|h|h"] = 
                            {
                                ["itemName"] = "False God's Shoes",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["139413"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:139413:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Dibellium",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [139413] = 11,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23165"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Carnelian",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23165] = 188,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45836"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45836:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Denima",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45836] = 105,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["34346"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34346:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ginkgo",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34346] = 689,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68341"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:68341:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Repora",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [68341] = 233,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:139437:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Craglorn I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [7] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:137132:363:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Siroria's Necklace",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [97] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["121521"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:121521:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Viridian Dust",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [121521] = 7,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["135156"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135156:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Antimony",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135156] = 41,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:28473:3:40:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Two-Zephyr Tea",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [14] = 33,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["127068"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:127068:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Blueprint: Redoran Fork, Wooden",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [201] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["140456"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140456:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Shoulders",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [117] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68196"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68196:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Bravil's Best Beet Risotto",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [188] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["140451"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140451:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Gloves",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [140] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["23117"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23117:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rough Beech",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23117] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:86786:363:50:26582:370:50:0:0:0:0:0:0:0:0:1:6:0:1:0:6473:0|h|h"] = 
                            {
                                ["itemName"] = "Sash of Necropotence",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [71] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["64504"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64504:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ancestor Silk",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64504] = 1007,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["77587"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:77587:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Fleshfly Larva",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [77587] = 416,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:153782:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Glenmoril Wyrd Gloves",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [109] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:156361:369:50:26582:370:50:0:0:0:0:0:0:0:0:1:20:1:1:0:9521:0|h|h"] = 
                            {
                                ["itemName"] = "New Moon Acolyte's Sabatons",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["23127"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23127:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ebonthread",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23127] = 172,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:159482:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Jephrine Paladin Sword",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [74] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:43696:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Khenarthi's Roost Treasure Map II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [60] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:28382:3:15:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Port Hunding Cheese Fries",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 10,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:147310:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Lyris Titanborn's Pauldrons",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [89] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45848"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45848:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Makderi",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45848] = 70,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:87697:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Witchmother's Potent Brew",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [53] = 24,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [4] = 83,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["46151"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46151:0:0:0:0:0:0:0:0:0:0:0:0:0:0:20:0:0:0:0:0|h|h",
                                ["itemName"] = "Daedra Heart",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46151] = 2244,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["137961"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:137961:0:0:0:0:0:0:0:0:0:0:0:0:0:0:70:0:0:0:0:0|h|h",
                                ["itemName"] = "Infected Flesh",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [137961] = 12,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:136985:363:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:8346:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Boots",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [43] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:147326:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Abnur Tharn's Breeches",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [228] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:137174:364:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Siroria's Sash",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [129] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["68200"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:68200:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Solitude Salmon-Millet Soup",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [223] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:54339:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:66304|h|h"] = 
                            {
                                ["itemName"] = "Essence of Health",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [99] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:69802:20:14:0:0:0:0:0:0:0:0:0:0:0:1:1:1:1:0:7814:0|h|h"] = 
                            {
                                ["itemName"] = "Robe of Julianos",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [72] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["23129"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23129:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Raw Cotton",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23129] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45846"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45846:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Oru",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45846] = 123,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["160509"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:160509:0:0:0:0:0:0:0:0:0:0:0:0:0:0:100:0:0:0:0:0|h|h",
                                ["itemName"] = "Gloomspore Chitin",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [160509] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:45352:365:50:0:0:0:0:0:0:0:0:0:0:0:0:4:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ancestor Silk Jerkin",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [186] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["27043"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:27043:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Honey",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27043] = 1209,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:28978:363:50:0:0:0:0:0:0:0:0:0:0:0:1:34:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Chain of the Snake Charmer",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [26] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:129716:364:50:0:0:0:0:0:0:0:0:0:0:0:1:37:0:1:0:500:0|h|h"] = 
                            {
                                ["itemName"] = "Briarheart Dagger",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [5] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["46149"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46149:0:0:0:0:0:0:0:0:0:0:0:0:0:0:17:0:0:0:0:0|h|h",
                                ["itemName"] = "Bronze",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46149] = 169,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:54339:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:65536|h|h"] = 
                            {
                                ["itemName"] = "Essence of Health",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [12] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:136950:363:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Necklace",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [51] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["59922"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:59922:0:0:0:0:0:0:0:0:0:0:0:0:0:0:29:0:0:0:0:0|h|h",
                                ["itemName"] = "Charcoal of Remorse",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [59922] = 25,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:94580:363:50:0:0:0:15:0:0:0:0:0:0:0:2049:67:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Grothdarr's Visage",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [147] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["45840"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45840:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Meip",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45840] = 101,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["46128"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46128:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Galatite Ingot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46128] = 377,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["56945"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:56945:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Summerset Rainbow Pie",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [225] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["156606"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:156606:0:0:0:0:0:0:0:0:0:0:0:0:0:0:93:0:0:0:0:0|h|h",
                                ["itemName"] = "Blood of Sahrotnax",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [156606] = 14,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:80101:363:50:0:0:0:0:0:0:0:0:0:0:0:1:35:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Bracers Of The Vicious Ophidian",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [112] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:123457:363:50:0:0:0:0:0:0:0:0:0:0:0:1:50:0:1:0:388:0|h|h"] = 
                            {
                                ["itemName"] = "Coward's Gear Bow",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["34307"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34307:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Radish",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34307] = 589,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["57587"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:57587:0:0:0:0:0:0:0:0:0:0:0:0:0:0:14:0:0:0:0:0|h|h",
                                ["itemName"] = "Dwemer Frame",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [57587] = 20,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["4448"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:4448:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Hide Scraps",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [4448] = 18,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:97218:363:50:45884:370:50:31:0:0:0:0:0:0:0:1:6:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Necklace of a Mother's Sorrow",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:156366:369:50:26582:370:50:0:0:0:0:0:0:0:0:1:20:1:1:0:9823:0|h|h"] = 
                            {
                                ["itemName"] = "New Moon Acolyte's Girdle",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [6] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["45835"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45835:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Makkoma",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45835] = 97,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:125467:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Instant Woodworking Research",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [36] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["181549"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [100] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Praxis: Vampiric Lamp, Azure Triple",
                                ["itemLink"] = "|H1:item:181549:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["139419"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:139419:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pulverized Dibellium",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [139419] = 30,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["27049"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:27049:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Lemon",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27049] = 1437,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["135152"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:135152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Iridium Grains",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135152] = 155,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57739:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Glenumbra",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [40] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["23149"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23149:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Fire Opal",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23149] = 242,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23143"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23143:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Iron Hide Scraps",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23143] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57765:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: The Rift",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [46] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:97253:359:50:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Robe of a Mother's Sorrow",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [86] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["82024"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82024:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Belts",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [153] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["135004"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135004:175:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h",
                                ["itemName"] = "Cyrodiil Assault Crate",
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [29] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:129546:364:50:0:0:0:18:0:0:0:0:0:0:0:2049:67:0:1:0:8601:0|h|h"] = 
                            {
                                ["itemName"] = "Zaan's Guise",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["33758"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33758:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Potato",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33758] = 476,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["64222"] = 
                            {
                                ["itemQuality"] = 5,
                                ["itemLink"] = "|H1:item:64222:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Perfect Roe",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64222] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["30166"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30166:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Water Hyacinth",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30166] = 212,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["82029"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82029:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Gloves",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [158] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57816:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Grahtwood",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [87] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:43702:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Bal Foyen Treasure Map II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [118] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:57818:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Stormhaven",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [94] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["135160"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135160:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pulverized Zinc",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135160] = 159,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57747:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Grahtwood",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [24] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:156497:370:50:26848:370:50:0:0:0:0:0:0:0:0:1:1:1:1:0:412:0|h|h"] = 
                            {
                                ["itemName"] = "New Moon Acolyte's Lightning Staff",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [4] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:167170:5:1:0:0:0:33819:0:0:0:0:0:0:0:0:0:0:0:0:0:10000|h|h"] = 
                            {
                                ["itemName"] = "Imperial Charity Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [42] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["87683"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [103] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Crisp and Crunchy Pumpkin Snack Skewer",
                                ["itemLink"] = "|H1:item:87683:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119696:5:1:0:0:0:239:3:11:21:0:0:0:0:0:0:0:0:0:0:20000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Alchemy Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [61] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["27100"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:27100:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Flour",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27100] = 1036,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["46135"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46135:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Topgrain Hide",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46135] = 150,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:123473:363:50:0:0:0:0:0:0:0:0:0:0:0:1:50:0:1:0:229:0|h|h"] = 
                            {
                                ["itemName"] = "Coward's Gear Battle Axe",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [4] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:133555:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Spring-Loaded Infusion",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [42] = 71,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["30151"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30151:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Emetic Russula",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30151] = 284,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:61079:122:1:0:0:0:0:0:0:0:0:0:0:0:65:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Repair Kit",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [37] = 10,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:94582:363:50:26582:370:50:18:0:0:0:0:0:0:0:1:67:0:1:0:5878:0|h|h"] = 
                            {
                                ["itemName"] = "Grothdarr's Visage",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["135144"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135144:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Electrum Ounce",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135144] = 143,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["166988"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:166988:0:0:0:0:0:0:0:0:0:0:0:0:0:0:106:0:0:0:0:0|h|h",
                                ["itemName"] = "Thorn Sigil",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [166988] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119695:5:1:0:0:0:35:190:4:408:25:95:0:0:0:0:0:0:0:0:234000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Clothier Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [15] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119693:5:1:0:0:0:68275:0:0:0:0:0:0:0:0:0:0:0:0:0:20000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Provisioning Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [49] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:54341:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:327680|h|h"] = 
                            {
                                ["itemName"] = "Essence of Stamina",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [54] = 2,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [52] = 3,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [10] = 13,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [50] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:37845:30:20:0:0:0:0:0:0:0:0:0:0:0:16:0:0:0:1:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alik'r Beets with Goat Cheese",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [33] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["54178"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:54178:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pitch",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54178] = 246,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:69807:369:50:26582:369:50:0:0:0:0:0:0:0:0:1:1:1:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Breeches of Julianos",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [144] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["87689"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [104] = 2,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Crunchy Spider Skewer",
                                ["itemLink"] = "|H1:item:87689:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["33755"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33755:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Bananas",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33755] = 447,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:167250:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Grave Dancer Mace",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [81] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:139433:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: The Rift",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [76] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:136949:363:50:45883:370:50:31:0:0:0:0:0:0:0:1:73:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Ring",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [11] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:97259:364:50:0:0:0:0:0:0:0:0:0:0:0:1:6:0:1:0:3214:0|h|h"] = 
                            {
                                ["itemName"] = "Epaulets of a Mother's Sorrow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [98] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:149796:362:50:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Lokkestiiz's Amulet",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["23107"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23107:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Orichalcum Ingot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23107] = 351,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:43692:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Stros M'Kai Treasure Map II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [58] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:43509:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Glenumbra Treasure Map V",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [94] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:118048:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Common Table, Slanted",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [120] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 21,
                            },
                            ["811"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:811:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jute",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [811] = 540,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["33753"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33753:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Fish",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33753] = 1348,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:167248:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Grave Dancer Maul",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [112] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119680:5:1:0:0:0:46:188:4:323:13:132:0:0:0:0:0:0:0:0:63000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Blacksmithing Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [214] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["115961"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:115961:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Diagram: Breton Streetlight, Arched Stone",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [175] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:142703:363:50:68343:370:50:0:0:0:0:0:0:0:0:1:81:0:1:0:9525:0|h|h"] = 
                            {
                                ["itemName"] = "Bright-Throat's Boast Breeches",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["68219"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68219:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Hagraven's Tonic",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [141] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:145510:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Murkmire Treasure Map I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [63] = 1,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [64] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["135141"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135141:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Silver Dust",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135141] = 14,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:152683:363:50:0:0:0:18:0:0:0:0:0:0:0:1:93:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Hollowfang Breeches",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [43] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:142600:364:50:26583:370:50:0:0:0:0:0:0:0:0:1:81:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Bright-Throat's Boast Ring",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [12] = 1,
                                            [11] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["45816"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45816:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Kura",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45816] = 13,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:139425:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Grahtwood",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [67] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:119705:5:1:0:0:0:239:19:3:1:0:0:0:0:0:0:0:0:0:0:20000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Alchemy Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [213] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["64687"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64687:0:0:0:0:0:0:0:0:0:0:0:0:0:0:33:0:0:0:0:0|h|h",
                                ["itemName"] = "Goldscale",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64687] = 20,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119694:5:1:0:0:0:28:194:4:54:14:50:0:0:0:0:0:0:0:0:61750|h|h"] = 
                            {
                                ["itemName"] = "Sealed Clothier Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [16] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["33754"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33754:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "White Meat",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33754] = 607,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119693:5:1:0:0:0:68252:0:0:0:0:0:0:0:1025:0:0:1:0:0:20000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Provisioning Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [94] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["160558"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:160558:0:0:0:0:0:0:0:0:0:0:0:0:0:0:101:0:0:0:0:0|h|h",
                                ["itemName"] = "Bat Oil",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [160558] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:68493:363:50:0:0:0:0:0:0:0:0:0:0:0:1:37:0:1:0:7919:0|h|h"] = 
                            {
                                ["itemName"] = "Briarheart Bracers",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [16] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:45361:365:50:0:0:0:0:0:0:0:0:0:0:0:0:5:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Rubedo Leather Arm Cops",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [195] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:121529:6:1:0:0:0:44:188:5:176:11:2:0:0:0:0:0:0:0:0:779000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Blacksmithing Writ",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [123] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:43746:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clockwork City Treasure Map I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [19] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["30163"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30163:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Mountain Flower",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30163] = 492,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:139427:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Greenshade",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [68] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["181677"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:181677:0:0:0:0:0:0:0:0:0:0:0:0:0:0:128:0:0:0:0:0|h|h",
                                ["itemName"] = "Squid Ink",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [181677] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["82032"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82032:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Maces",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [159] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["33756"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33756:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Small Game",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33756] = 506,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:166198:364:50:54484:370:50:0:0:0:0:0:0:0:0:1:14:0:1:0:310:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Perfected Inferno Staff",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:153739:4:1:0:0:0:18:255:3:78:30:0:0:0:0:0:0:0:0:0:262500|h|h"] = 
                            {
                                ["itemName"] = "Sealed Jewelry Crafter Writ",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [126] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["33255"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33255:0:0:0:0:0:0:0:0:0:0:0:0:0:0:9:0:0:0:0:0|h|h",
                                ["itemName"] = "Moonstone",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33255] = 301,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:135109:123:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Fortifying Meal",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [79] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["46042"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:46042:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Yellow Goblin Tonic",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [227] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["79305"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:79305:0:0:0:0:0:0:0:0:0:0:0:0:0:0:43:0:0:0:0:0|h|h",
                                ["itemName"] = "Boiled Carapace",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [79305] = 10,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["33150"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33150:0:0:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:0:0|h|h",
                                ["itemName"] = "Flint",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33150] = 239,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:156217:370:50:26848:370:50:0:0:0:0:0:0:0:0:1:1:1:1:0:432:0|h|h"] = 
                            {
                                ["itemName"] = "New Moon Acolyte's Lightning Staff",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:45313:365:50:0:0:0:0:0:0:0:0:0:0:0:0:2:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ancestor Silk Shoes",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [54] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:141736:123:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Welkynar Binding",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [6] = 11,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:45349:365:50:0:0:0:0:0:0:0:0:0:0:0:0:5:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ancestor Silk Gloves",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [170] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:104522:363:50:0:0:0:0:0:0:0:0:0:0:0:1:20:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Burning Spellweave Breeches",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["34308"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34308:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Melon",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34308] = 416,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["140452"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140452:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Helmets",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [116] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:125473:124:1:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Research Scroll, Blacksmithing, 1 Day",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [24] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:94441:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Grand Gold Coast Experience Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [62] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:45364:365:50:0:0:0:0:0:0:0:0:0:0:0:0:9:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ruby Ash Inferno Staff",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [64] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:34053:3:20:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Yerba Zinger Tonic",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [131] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68191"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68191:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Lilmoth Garlic Hagfish",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [136] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45830"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45830:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Kude",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45830] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:94845:363:50:0:0:0:0:0:0:0:0:0:0:0:1:67:0:1:0:8538:0|h|h"] = 
                            {
                                ["itemName"] = "Selene's Guise",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:43642:4:1:0:0:0:0:0:0:0:0:0:0:0:16:0:0:0:1:0:0|h|h"] = 
                            {
                                ["itemName"] = "Greenshade Treasure Map VI",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [3] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:149978:362:50:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "False God's Amulet",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [31] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:119694:5:1:0:0:0:32:194:4:48:12:100:0:0:0:0:0:0:0:0:52500|h|h"] = 
                            {
                                ["itemName"] = "Sealed Clothier Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [124] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["139410"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:139410:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Titanium",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [139410] = 10,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:54339:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:66816|h|h"] = 
                            {
                                ["itemName"] = "Essence of Health",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 7,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [66] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["46138"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46138:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Shadowhide",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46138] = 374,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68212"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68212:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Colovian Ginger Beer",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [138] = 7,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:61080:32:1:0:0:0:0:0:0:0:0:0:0:0:65:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Soul Gem",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [64] = 16,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:153645:6:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Glenmoril Wyrd Treasure Map: Reaper's March",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [99] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["75360"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:75360:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Gall",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [75360] = 95,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:171436:364:50:45884:370:50:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ring of the Pale Order",
                                ["itemQuality"] = 6,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [25] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:51543:369:50:26588:370:50:0:0:0:0:0:0:0:0:1:9:1:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Bracers of Hunding's Rage",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [16] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:76826:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:65536|h|h"] = 
                            {
                                ["itemName"] = "Drain Health Poison IX",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 26,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [105] = 13,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["182553"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:182553:0:0:0:0:0:0:0:0:0:0:0:0:0:0:131:0:0:0:0:0|h|h",
                                ["itemName"] = "Stendarr Stamp",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [182553] = 9,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68342"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:68342:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Hakeijo",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [68342] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:97254:359:50:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Shoes of a Mother's Sorrow",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [30] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["81998"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:81998:0:0:0:0:0:0:0:0:0:0:0:0:0:0:27:0:0:0:0:0|h|h",
                                ["itemName"] = "Star Sapphire",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [81998] = 18,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57761:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Eastmarch",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [39] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:64523:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Attribute Respecification Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [121] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["30165"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Nirnroot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30165] = 259,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45843"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45843:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Okori",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45843] = 81,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68195"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68195:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Hearty Garlic Corn Chowder",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [148] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:171738:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Imperial Champion Maul",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [93] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:64707:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Recipe: Psijic Ambrosia, Fragment V",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [99] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["130061"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:130061:0:0:0:0:0:0:0:0:0:0:0:0:0:0:60:0:0:0:0:0|h|h",
                                ["itemName"] = "Polished Rivets",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [130061] = 11,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:149795:363:50:45883:370:50:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Lokkestiiz's Ring",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [25] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["45842"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45842:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Deteri",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45842] = 100,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57823:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Eastmarch",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["71200"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71200:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Raw Ancestor Silk",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71200] = 3922,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["33752"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33752:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Red Meat",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33752] = 581,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:81194:307:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Cloudy Damage Health Poison IX",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [46] = 24,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["5413"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:5413:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Iron Ingot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [5413] = 2437,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45827"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45827:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pode",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45827] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:139430:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Malabal Tor",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [69] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:43669:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Shadowfen Treasure Map III",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [138] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["140458"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140458:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Swords",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [118] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:45361:308:50:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Rubedo Leather Arm Cops",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [173] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:151599:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Northern Elsweyr",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [42] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["124681"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:124681:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 48: Ashlander Belts",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [71] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:133722:362:50:0:0:0:0:0:0:0:0:0:0:0:1:14:0:1:0:275:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Inferno Staff",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [45] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:43600:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Glenumbra Treasure Map IV",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [16] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["46142"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46142:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sanded Nightwood",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46142] = 395,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:64712:123:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Refreshing Drink",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 24,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:167262:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Grave Dancer Axe",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [110] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:69910:369:50:26582:370:50:0:0:0:0:0:0:0:0:1:5:1:1:0:9550:0|h|h"] = 
                            {
                                ["itemName"] = "Gloves of Julianos",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [16] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["54179"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:54179:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Turpen",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54179] = 418,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["114891"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:114891:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Clean Pelt",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [114891] = 327,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["75370"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:75370:0:0:0:0:0:0:0:0:0:0:0:0:0:0:11:0:0:0:0:0|h|h",
                                ["itemName"] = "Fine Chalk",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [75370] = 24,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119696:5:1:0:0:0:199:2:11:21:0:0:0:0:0:0:0:0:0:0:50000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Alchemy Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [121] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["33194"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33194:0:0:0:0:0:0:0:0:0:0:0:0:0:0:8:0:0:0:0:0|h|h",
                                ["itemName"] = "Bone",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33194] = 221,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["139414"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:139414:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Slaughterstone",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [139414] = 28,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:151603:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Northern Elsweyr",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [70] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["135145"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135145:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Platinum Dust",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135145] = 3130,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:147660:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Prophet's Breeches",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [108] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["808"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:808:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Iron Ore",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [808] = 119,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["96388"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:96388:0:0:0:0:0:0:0:0:0:0:0:0:0:0:42:0:0:0:0:0|h|h",
                                ["itemName"] = "Wolfsbane Incense",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [96388] = 7,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68227"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:68227:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Rosy Disposition Tonic",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [209] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119564:5:1:0:0:0:26591:207:4:0:0:0:0:0:0:0:0:0:0:0:20000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Enchanting Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [62] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["81995"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:81995:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Oxblood Fungus Spore",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [81995] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["71582"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71582:0:0:0:0:0:0:0:0:0:0:0:0:0:0:21:0:0:0:0:0|h|h",
                                ["itemName"] = "Auric Tusk",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71582] = 27,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23099"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23099:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Leather",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23099] = 151,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:59632:363:50:26582:370:50:0:0:0:0:0:0:0:0:1:67:0:1:0:8500:0|h|h"] = 
                            {
                                ["itemName"] = "Valkyn Skoria's Visage",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:114947:175:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Plume Dazzler",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [149] = 12,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119695:5:1:0:0:0:40:190:4:176:18:12:0:0:0:0:0:0:0:0:56375|h|h"] = 
                            {
                                ["itemName"] = "Sealed Clothier Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [14] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:136997:362:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:300:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Dagger",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [34] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["68204"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:68204:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Chevre-Radish Salad with Pumpkin Seeds",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [147] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:149795:362:50:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Lokkestiiz's Ring",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [21] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["75364"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:75364:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Night-Oil",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [75364] = 14,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119695:5:1:0:0:0:39:190:4:325:18:75:0:0:1025:0:0:1:0:0:90000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Clothier Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [96] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57789:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Shadowfen",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [30] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:43558:365:50:0:0:0:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ruby Ash Ice Staff",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [144] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["813"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:813:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Turquoise",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [813] = 274,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:43658:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Stonefalls Treasure Map IV",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [51] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["135151"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:135151:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Terne Grains",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135151] = 152,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["150731"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:150731:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Dragon's Blood",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [150731] = 41,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68193"] = 
                            {
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [226] = 4,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [113] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Thrice-Baked Gorapple Pie",
                                ["itemLink"] = "|H1:item:68193:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:71779:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Counterfeit Pardon Edict",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [0] = 10,
                                        },
                                    },
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [88] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:54515:365:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Platinum Necklace",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [2] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["69556"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:69556:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Cassiterite Sand",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [69556] = 11,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:153739:4:1:0:0:0:24:255:3:439:31:0:0:0:0:0:0:0:0:0:288750|h|h"] = 
                            {
                                ["itemName"] = "Sealed Jewelry Crafter Writ",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [33] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["46140"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46140:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sanded Ash",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46140] = 536,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:112428:123:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Gold Coast Warrior Elixir",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [7] = 10,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["178713"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:178713:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 108: Fargrave Guardian Gloves",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [87] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["33772"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33772:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Coffee",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33772] = 718,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["77581"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:77581:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Torchbug Thorax",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [77581] = 124,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["77583"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:77583:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Beetle Scuttle",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [77583] = 129,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["140454"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140454:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Maces",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [53] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119681:5:1:0:0:0:71:192:4:351:8:22:0:0:0:0:0:0:0:0:63000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Woodworking Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [39] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:166037:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blackreach: Greymoor Caverns CE Treasure Map II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [21] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["33257"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33257:0:0:0:0:0:0:0:0:0:0:0:0:0:0:3:0:0:0:0:0|h|h",
                                ["itemName"] = "Manganese",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33257] = 623,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45852"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:45852:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Denata",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45852] = 719,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["135155"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135155:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Cobalt",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135155] = 31,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:114946:175:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Sparkwreath Dazzler",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [153] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57774:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Greenshade",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:137169:359:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Siroria's Gloves",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [74] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:71295:363:50:45883:370:50:0:0:0:0:0:0:0:0:1:37:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Briarheart Band",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [12] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:171739:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Imperial Champion Greatsword",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [83] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["77584"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:77584:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Spider Egg",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [77584] = 114,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:149823:364:50:0:0:0:7:0:0:0:0:0:0:0:1:86:0:1:0:329:0|h|h"] = 
                            {
                                ["itemName"] = "Lokkestiiz's Dagger",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [29] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:45354:308:50:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ancestor Silk Sash",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [153] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:57776:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Rivenspire",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [13] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["82000"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:82000:0:0:0:0:0:0:0:0:0:0:0:0:0:0:59:0:0:0:0:0|h|h",
                                ["itemName"] = "Amber Marble",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [82000] = 49,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["30149"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30149:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Stinkhorn",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30149] = 267,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68223"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [115] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Wide-Eye Double Rye",
                                ["itemLink"] = "|H1:item:68223:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["140455"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140455:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Shields",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [52] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:121550:124:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Scroll of Pelinal's Ferocity",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [106] = 1,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [19] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:71085:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Wrothgar III",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [36] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:145572:4:1:0:0:0:118012:0:0:0:0:0:0:0:0:0:0:0:0:0:10000|h|h"] = 
                            {
                                ["itemName"] = "New Life Charity Writ",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [27] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["521"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:521:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rough Oak",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [521] = 60,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["151908"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:151908:0:0:0:0:0:0:0:0:0:0:0:0:0:0:83:0:0:0:0:0|h|h",
                                ["itemName"] = "Auroran Dust",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [151908] = 7,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["139411"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:139411:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Aurbic Amber",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [139411] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:100211:363:50:0:0:0:0:0:0:0:0:0:0:0:1:5:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Fiord's Ring",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [12] = 1,
                                            [11] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:134909:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Mushrooms, Puspocket Group",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [119] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 21,
                            },
                            ["|H1:item:45314:365:50:0:0:0:0:0:0:0:0:0:0:0:0:8:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ancestor Silk Gloves",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [59] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:57758:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Shadowfen",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [45] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["71738"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71738:0:0:0:0:0:0:0:0:0:0:0:0:0:0:25:0:0:0:0:0|h|h",
                                ["itemName"] = "Eagle Feather",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71738] = 92,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:81166:364:50:0:0:0:0:0:0:0:0:0:0:0:1:35:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ring Of The Infallible Aether",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [58] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:167251:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Grave Dancer Sword",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [141] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:94439:124:1:0:0:0:0:0:0:0:0:0:0:0:129:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Gold Coast Experience Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [50] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:166459:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Western Skyrim",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [17] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["45857"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45857:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jera",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45857] = 188,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:28358:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Roast Pig",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [10] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:133704:364:50:54484:370:50:4:0:0:0:0:0:0:0:1:14:0:1:0:197:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Bow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:87952:364:50:0:0:0:7:0:0:0:0:0:0:0:1:24:0:1:0:178:0|h|h"] = 
                            {
                                ["itemName"] = "Deadly Dagger",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [125] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:69912:369:50:26582:370:50:0:0:0:0:0:0:0:0:1:45:1:1:0:9200:0|h|h"] = 
                            {
                                ["itemName"] = "Breeches of Julianos",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:147512:363:50:45883:370:50:31:0:0:0:0:0:0:0:1:24:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Deadly Ring",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [84] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:119682:5:1:0:0:0:65:192:4:78:12:97:0:0:0:0:0:0:0:0:65000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Woodworking Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [129] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["77590"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:77590:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Nightshade",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [77590] = 186,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["119211"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [63] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Diagram: Redguard Streetlamps, Paired",
                                ["itemLink"] = "|H1:item:119211:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57802:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Greenshade",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [55] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:147317:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Sai Sahan's Guards",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [231] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57794:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: The Rift",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [32] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["4463"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:4463:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Flax",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [4463] = 928,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:68239:309:50:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Hearty Garlic Corn Chowder",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 1,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [2] = 2,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [109] = 2,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [108] = 1,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["130059"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:130059:0:0:0:0:0:0:0:0:0:0:0:0:0:0:49:0:0:0:0:0|h|h",
                                ["itemName"] = "Refined Bonemold Resin",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [130059] = 25,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:64524:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Skill Respecification Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [177] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:119693:5:1:0:0:0:68276:0:0:0:0:0:0:0:0:0:0:0:0:0:20000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Provisioning Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [70] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["82027"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82027:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Chests",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [156] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:43624:4:1:0:0:0:0:0:0:0:0:0:0:0:16:0:0:0:1:0:0|h|h"] = 
                            {
                                ["itemName"] = "Bangkorai Treasure Map VI",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [127] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["135154"] = 
                            {
                                ["itemQuality"] = 5,
                                ["itemLink"] = "|H1:item:135154:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Chromium Grains",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135154] = 22,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["64688"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64688:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ancient Scale",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64688] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:166465:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Western Skyrim",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [96] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:114945:175:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Cherry Blossom Twig",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [143] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:61080:32:1:0:0:0:0:0:0:0:0:0:0:0:129:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Soul Gem",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [116] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["46130"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46130:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Voidstone Ingot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46130] = 470,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68216"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68216:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Muthsera's Remorse",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [180] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:139423:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Glenumbra",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [98] = 1,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [41] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:86780:363:50:26582:370:50:0:0:0:0:0:0:0:0:1:6:0:1:0:7161:0|h|h"] = 
                            {
                                ["itemName"] = "Shoes of Necropotence",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [72] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["28666"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:28666:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Seaweed",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [28666] = 927,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["82035"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82035:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Staves",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [162] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["34329"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34329:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Barley",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34329] = 568,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119564:5:1:0:0:0:26848:225:4:0:0:0:0:0:0:0:0:0:0:0:22000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Enchanting Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [104] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:156215:369:50:26844:370:50:0:0:0:0:0:0:0:0:1:8:1:1:0:148:0|h|h"] = 
                            {
                                ["itemName"] = "New Moon Acolyte's Inferno Staff",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [4] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["33251"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33251:0:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0|h|h",
                                ["itemName"] = "Molybdenum",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33251] = 100,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["121518"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:121518:0:0:0:0:0:0:0:0:0:0:0:0:0:0:52:0:0:0:0:0|h|h",
                                ["itemName"] = "Volcanic Viridian",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [121518] = 19,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:45359:365:50:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Rubedo Leather Helmet",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [134] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:71083:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Wrothgar I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [37] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:64710:123:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Tri-Restoration Potion",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [119] = 200,
                                            [49] = 95,
                                            [54] = 200,
                                            [115] = 200,
                                        },
                                    },
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [21] = 135,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["883"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:883:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Natural Water",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [883] = 281,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23173"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23173:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sapphire",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23173] = 537,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["150670"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:150670:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Vile Coagulant",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [150670] = 61,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:121303:6:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "\"Room to Spare\" Housing Brochure",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [77] = 1,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [76] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:76827:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:131072|h|h"] = 
                            {
                                ["itemName"] = "Damage Health Poison IX",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [104] = 14,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [37] = 8,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [2] = 77,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [54] = 9,
                                        },
                                    },
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [112] = 13,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [135] = 15,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["114984"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:114984:0:0:0:0:0:0:0:0:0:0:0:0:0:0:57:0:0:0:0:0|h|h",
                                ["itemName"] = "Leviathan Scrimshaw",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [114984] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:45359:308:50:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Rubedo Leather Helmet",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [168] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["87682"] = 
                            {
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [108] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Recipe: Sweet Sanguine Apples",
                                ["itemLink"] = "|H1:item:87682:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["45851"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:45851:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jejota",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45851] = 1292,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["57665"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:57665:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Dwemer Scrap",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [57665] = 7,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["4464"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:4464:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Raw Flax",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [4464] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:166038:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blackreach: Greymoor Caverns Treasure Map I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [92] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:43648:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Malabal Tor Treasure Map VI",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [57] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["810"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:810:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jade",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [810] = 210,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119695:5:1:0:0:0:37:190:4:385:17:55:0:0:0:0:0:0:0:0:90000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Clothier Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [13] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["30158"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30158:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Lady's Smock",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30158] = 310,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:159473:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Jephrine Paladin Greaves",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [90] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["178722"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:178722:0:0:0:0:0:0:0:0:0:0:0:0:0:0:126:0:0:0:0:0|h|h",
                                ["itemName"] = "Indigo Lucent",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [178722] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:126112:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Vvardenfell",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [95] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["71736"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71736:0:0:0:0:0:0:0:0:0:0:0:0:0:0:44:0:0:0:0:0|h|h",
                                ["itemName"] = "Ancient Sandstone",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71736] = 53,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["793"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:793:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rawhide Scraps",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [793] = 58,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23131"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23131:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Raw Ebonthread",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23131] = 20,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["46132"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46132:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ironthread",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46132] = 261,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:59637:363:50:0:0:0:0:0:0:0:0:0:0:0:1:67:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Valkyn Skoria's Visage",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [42] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:97218:363:50:26583:370:50:0:0:0:0:0:0:0:0:1:6:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Necklace of a Mother's Sorrow",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [50] = 1,
                                            [120] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:135114:123:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Tri-Restoration Potion",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [66] = 23,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [69] = 11,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:45349:365:50:0:0:0:0:0:0:0:0:0:0:0:0:7:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ancestor Silk Gloves",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [166] = 1,
                                            [172] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:129556:364:50:0:0:0:18:0:0:0:0:0:0:0:1:67:0:1:0:7151:0|h|h"] = 
                            {
                                ["itemName"] = "Zaan's Epaulets",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [3] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:45356:365:50:0:0:0:0:0:0:0:0:0:0:0:0:8:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Rubedo Leather Jack",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [171] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:97035:363:50:45884:370:50:0:0:0:0:0:0:0:0:1:1:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Plague Doctor's Ring",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [101] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["157533"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:157533:0:0:0:0:0:0:0:0:0:0:0:0:0:0:97:0:0:0:0:0|h|h",
                                ["itemName"] = "Fryse Willow",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [157533] = 7,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:129545:363:50:26582:370:50:18:0:0:0:0:0:0:0:1:67:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Zaan's Pauldron",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [135] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["45847"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45847:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Taderi",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45847] = 66,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:139432:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Reaper's March",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [71] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["4486"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:4486:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ruby",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [4486] = 262,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["82033"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82033:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Shields",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [160] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:104483:363:50:0:0:0:0:0:0:0:0:0:0:0:1:20:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Burning Spellweave Necklace",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [7] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:152602:363:50:0:0:0:18:0:0:0:0:0:0:0:1:93:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Hollowfang Sash",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [45] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:126113:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Vvardenfell",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [16] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["30161"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30161:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Corn Flower",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30161] = 315,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119695:5:1:0:0:0:43:190:4:161:17:85:0:0:0:0:0:0:0:0:66000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Clothier Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [69] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45806"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45806:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jejora",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45806] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:80256:363:50:0:0:0:0:0:0:0:0:0:0:0:1:35:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Breeches Of The Infallible Aether",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [54] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["81994"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:81994:0:0:0:0:0:0:0:0:0:0:0:0:0:0:39:0:0:0:0:0|h|h",
                                ["itemName"] = "Oxblood Fungus",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [81994] = 10,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:68492:363:50:0:0:0:0:0:0:0:0:0:0:0:1:37:0:1:0:7260:0|h|h"] = 
                            {
                                ["itemName"] = "Briarheart Boots",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:57779:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Alik'r",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [50] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["76914"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:76914:0:0:0:0:0:0:0:0:0:0:0:0:0:0:41:0:0:0:0:0|h|h",
                                ["itemName"] = "Polished Shilling",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [76914] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["46134"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46134:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Void Cloth",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46134] = 523,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["42873"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:42873:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Fish Roe, Foul Bait",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [42873] = 76,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:68260:309:50:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Muthsera's Remorse",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [84] = 2,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [41] = 2,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [182] = 1,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [39] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:104519:363:50:0:0:0:0:0:0:0:0:0:0:0:1:20:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Burning Spellweave Shoes",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [4] = 1,
                                            [5] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["114894"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:114894:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Decorative Wax",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [114894] = 266,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["152109"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:152109:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Praxis: Elsweyr Wall, Curved Masonry",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [203] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:45349:308:50:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ancestor Silk Gloves",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [169] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["77591"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:77591:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Mudcrab Chitin",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [77591] = 74,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57828:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Coldharbour I",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 1,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [111] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:57809:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: The Rift",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [59] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["51565"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:51565:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 12: Barbaric Style",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [97] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:57762:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Alik'r",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [39] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["68218"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68218:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Old Hegathe Lemon Kaveh",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [142] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:94440:124:1:0:0:0:0:0:0:0:0:0:0:0:129:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Major Gold Coast Experience Scroll",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [120] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:166319:363:50:0:0:0:0:0:0:0:0:0:0:0:1:14:0:1:0:400:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Perfected Inferno Staff",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [132] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:64708:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Recipe: Psijic Ambrosia, Fragment VI",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [11] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:153872:124:1:0:0:0:0:0:0:0:0:0:0:0:1025:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Attunable Woodworking Station, Bound",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [113] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:30016:18:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Folded Note",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [60] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:152551:362:50:0:0:0:0:0:0:0:0:0:0:0:1:93:0:1:0:300:0|h|h"] = 
                            {
                                ["itemName"] = "Hollowfang Restoration Staff",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [29] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["71538"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:71538:0:0:0:0:0:0:0:0:0:0:0:0:0:0:47:0:0:0:0:0|h|h",
                                ["itemName"] = "Rogue's Soot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [71538] = 12,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:139429:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Rivenspire",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [72] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["150789"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:150789:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Dragon's Bile",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [150789] = 72,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["77585"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:77585:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Butterfly Wing",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [77585] = 187,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57754:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Grahtwood",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [51] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:139443:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Wrothgar III",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [80] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["147288"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:147288:0:0:0:0:0:0:0:0:0:0:0:0:0:0:80:0:0:0:0:0|h|h",
                                ["itemName"] = "Red Diamond Seal",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [147288] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["27063"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:27063:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Saltrice",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [27063] = 1321,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45831"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45831:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Oko",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45831] = 99,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:97036:363:50:45884:370:50:0:0:0:0:0:0:0:0:1:1:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Plague Doctor's Necklace",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [100] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:152617:363:50:0:0:0:18:0:0:0:0:0:0:0:1:93:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Hollowfang Shoes",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [46] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:152679:363:50:0:0:0:18:0:0:0:0:0:0:0:1:93:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Hollowfang Robe",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [44] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["45820"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45820:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Tade",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45820] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["156589"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:156589:0:0:0:0:0:0:0:0:0:0:0:0:0:0:89:0:0:0:0:0|h|h",
                                ["itemName"] = "Oath Cord",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [156589] = 7,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["64508"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64508:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jehade",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64508] = 227,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["23219"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23219:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Diamond",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23219] = 498,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["114983"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:114983:0:0:0:0:0:0:0:0:0:0:0:0:0:0:56:0:0:0:0:0|h|h",
                                ["itemName"] = "Distilled Slowsilver",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [114983] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:64515:2:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Dominion Cold Fire Ballista",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [145] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:57771:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Grahtwood",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["151622"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:151622:0:0:0:0:0:0:0:0:0:0:0:0:0:0:85:0:0:0:0:0|h|h",
                                ["itemName"] = "Dragonthread",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [151622] = 15,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["139020"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:139020:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Clam Gall",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [139020] = 53,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:45328:308:50:0:0:0:0:0:0:0:0:0:0:0:0:3:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ruby Ash Shield",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [68] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:57812:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Coldharbour II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [22] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["30357"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:30357:175:1:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h",
                                ["itemName"] = "Lockpick",
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [80] = 6,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 1,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [31] = 22,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [62] = 3,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [126] = 13,
                                            [77] = 21,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["64713"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64713:0:0:0:0:0:0:0:0:0:0:0:0:0:0:26:0:0:0:0:0|h|h",
                                ["itemName"] = "Laurel",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64713] = 37,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:81228:121:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Spirit Stone",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [155] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["23101"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23101:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Fell Hide",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23101] = 77,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:188196:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: High Isle",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [6] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:27039:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:1245443|h|h"] = 
                            {
                                ["itemName"] = "Essence of Immovability",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [27] = 81,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["130060"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:130060:0:0:0:0:0:0:0:0:0:0:0:0:0:0:48:0:0:0:0:0|h|h",
                                ["itemName"] = "Polished Scarab Elytra",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [130060] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45815"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45815:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Rekura",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45815] = 191,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:167246:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Grave Dancer Shield",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [143] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["64685"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:64685:0:0:0:0:0:0:0:0:0:0:0:0:0:0:35:0:0:0:0:0|h|h",
                                ["itemName"] = "Ferrous Salts",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [64685] = 22,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:64704:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Recipe: Psijic Ambrosia, Fragment II",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [60] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["23221"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23221:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Almandine",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23221] = 622,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["800"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:800:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Superb Hide Scraps",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [800] = 7,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45855"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45855:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jora",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45855] = 293,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:153641:6:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Glenmoril Wyrd Treasure Map: Bangkorai",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [66] = 1,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [75] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["45821"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45821:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Jayde",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45821] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119693:5:1:0:0:0:71058:0:0:0:0:0:0:0:0:0:0:0:0:0:20000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Provisioning Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [63] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["135140"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135140:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Copper Ounce",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135140] = 472,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:43662:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Deshaan Treasure Map II",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [18] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:27036:307:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Essence of Health",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [70] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68189"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68189:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Garlic-and-Pepper Venison Steak",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [137] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["26802"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:26802:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Frost Mirriam",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [26802] = 678,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["140267"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:140267:0:0:0:0:0:0:0:0:0:0:0:0:0:0:75:0:0:0:0:0|h|h",
                                ["itemName"] = "Sea Serpent Hide",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [140267] = 44,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:112425:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Lava Foot Soup-and-Saltrice",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [6] = 38,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["137953"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:137953:0:0:0:0:0:0:0:0:0:0:0:0:0:0:72:0:0:0:0:0|h|h",
                                ["itemName"] = "Culanda Lacquer",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [137953] = 44,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["132619"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:132619:0:0:0:0:0:0:0:0:0:0:0:0:0:0:62:0:0:0:0:0|h|h",
                                ["itemName"] = "Minotaur Bezoar",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [132619] = 18,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:64710:123:1:0:0:0:0:0:0:0:0:0:0:0:129:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Tri-Restoration Potion",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [119] = 35,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:51545:369:50:26588:370:50:0:0:0:0:0:0:0:0:1:9:1:1:0:4502:0|h|h"] = 
                            {
                                ["itemName"] = "Guards of Hunding's Rage",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [81] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:59652:363:50:26582:370:50:0:0:0:0:0:0:0:0:1:67:0:1:0:9375:0|h|h"] = 
                            {
                                ["itemName"] = "Valkyn Skoria's Pauldron",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [3] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["132617"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:132617:0:0:0:0:0:0:0:0:0:0:0:0:0:0:65:0:0:0:0:0|h|h",
                                ["itemName"] = "Tempered Brass",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [132617] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:45349:365:50:0:0:0:0:0:0:0:0:0:0:0:0:2:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ancestor Silk Gloves",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [167] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["33254"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33254:0:0:0:0:0:0:0:0:0:0:0:0:0:0:34:0:0:0:0:0|h|h",
                                ["itemName"] = "Nickel",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33254] = 105,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["116167"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:116167:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Blueprint: Nord Trunk, Faded",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [200] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:51541:369:50:26588:370:50:0:0:0:0:0:0:0:0:1:1:1:1:0:5871:0|h|h"] = 
                            {
                                ["itemName"] = "Jack of Hunding's Rage",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [82] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:153642:6:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Glenmoril Wyrd Treasure Map: Glenumbra",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [164] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["140446"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:140446:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 63: Dremora Belts",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [114] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:147323:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Sai Sahan's Sword",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [88] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:54339:30:3:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:66304|h|h"] = 
                            {
                                ["itemName"] = "Sip of Health",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [230] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["30221"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:30221:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sardonyx",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30221] = 612,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:64711:123:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Crown Fortifying Meal",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [22] = 10,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [88] = 38,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["150669"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:150669:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Chaurus Egg",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [150669] = 42,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:69911:369:50:26582:370:50:0:0:0:0:0:0:0:0:1:5:1:1:0:9550:0|h|h"] = 
                            {
                                ["itemName"] = "Sash of Julianos",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [6] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:57763:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Reaper's March",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [43] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["23135"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23135:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Voidstone Ore",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23135] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["68211"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68211:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Kragenmoor Zinger Mazte",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [207] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["137951"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:137951:0:0:0:0:0:0:0:0:0:0:0:0:0:0:71:0:0:0:0:0|h|h",
                                ["itemName"] = "Vitrified Malondo",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [137951] = 8,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57801:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Blacksmith Survey: Eastmarch",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [23] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:71779:4:1:0:0:0:0:0:0:0:0:0:0:0:17:0:0:1:1:0:0|h|h"] = 
                            {
                                ["itemName"] = "Counterfeit Pardon Edict",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:33909:3:40:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Skyrim Jazbay Crostata",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [13] = 60,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:95260:363:50:0:0:0:15:0:0:0:0:0:0:0:2049:67:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Grothdarr's Arm Cops",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [146] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:100266:363:50:0:0:0:0:0:0:0:0:0:0:0:1:5:0:1:0:2972:0|h|h"] = 
                            {
                                ["itemName"] = "Fiord's Jack",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [2] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:54511:2:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Pewter Ring",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [90] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["75371"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:75371:30:1:0:0:0:0:0:0:0:0:0:0:0:16:0:0:0:1:0:0|h|h",
                                ["itemName"] = "Coarse Chalk",
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [132] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["30153"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30153:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Namira's Rot",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30153] = 336,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:64520:2:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:184500:0|h|h"] = 
                            {
                                ["itemName"] = "Dominion Cold Stone Trebuchet",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [47] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:156196:367:50:45884:370:50:0:0:0:0:0:0:0:0:1:0:1:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "New Moon Acolyte's Amulet",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [1] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:153629:6:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Bewitched Sugar Skulls",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [122] = 72,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["59923"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:59923:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Ashes of Remorse",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [59923] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:156195:367:50:45884:370:50:0:0:0:0:0:0:0:0:1:0:1:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "New Moon Acolyte's Ring",
                                ["itemQuality"] = 2,
                                ["locations"] = 
                                {
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [12] = 1,
                                            [11] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:119564:5:1:0:0:0:26841:225:4:0:0:0:0:0:0:0:0:0:0:0:22000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Enchanting Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [215] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["812"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:812:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Raw Jute",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [812] = 28,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:97225:364:50:0:0:0:3:0:0:0:0:0:0:0:2049:6:0:1:0:500:0|h|h"] = 
                            {
                                ["itemName"] = "Dagger of a Mother's Sorrow",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [136] = 1,
                                            [137] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:150071:362:50:0:0:0:0:0:0:0:0:0:0:0:1:86:0:1:0:21:0|h|h"] = 
                            {
                                ["itemName"] = "False God's Inferno Staff",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [74] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["33252"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33252:0:0:0:0:0:0:0:0:0:0:0:0:0:0:7:0:0:0:0:0|h|h",
                                ["itemName"] = "Adamantite",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33252] = 340,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:149836:363:50:0:0:0:0:0:0:0:0:0:0:0:1:86:0:1:0:4600:0|h|h"] = 
                            {
                                ["itemName"] = "Lokkestiiz's Belt",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [32] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["54175"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:54175:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Embroidery",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54175] = 616,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:167169:5:1:0:0:0:120410:0:0:0:0:0:0:0:0:0:0:0:0:0:10000|h|h"] = 
                            {
                                ["itemName"] = "Imperial Charity Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [26] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:166461:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Western Skyrim",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [48] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:139428:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Shadowfen",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [73] = 2,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [18] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:147300:2:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Revelry Pie",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [150] = 70,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["44879"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:44879:121:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h",
                                ["itemName"] = "Grand Repair Kit",
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [33] = 88,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [35] = 29,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [192] = 7,
                                            [37] = 200,
                                        },
                                    },
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [66] = 60,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:45331:365:50:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Ruby Ash Lightning Staff",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [132] = 1,
                                            [133] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:136949:363:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Ring",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [57] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["45818"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45818:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Notade",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45818] = 22,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["181668"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:181668:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 110: Dreadsails Gloves",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [107] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["23126"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:23126:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Spidersilk",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [23126] = 327,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57746:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: Stonefalls",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [14] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["135137"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:135137:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Pewter Dust",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [135137] = 800,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:119819:5:1:0:0:0:199:18:10:2:0:0:0:0:0:0:0:0:0:0:50000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Alchemy Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [76] = 1,
                                            [109] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["45841"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45841:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Haoko",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45841] = 125,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:120763:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Dubious Camoran Throne",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [140] = 15,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:114948:175:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Spiral Dazzler",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [154] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["82026"] = 
                            {
                                ["itemQuality"] = 4,
                                ["itemLink"] = "|H1:item:82026:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Crafting Motif 42: Hollowjack Bows",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [155] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["30160"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30160:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Bugloss",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30160] = 490,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["33220"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33220:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Raw Void Bloom",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33220] = 3,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["45812"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45812:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Denara",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45812] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:81174:364:50:0:0:0:0:0:0:0:0:0:0:0:1:35:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Necklace Of The Infallible Aether",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [56] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 25,
                            },
                            ["|H1:item:81195:307:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Cloudy Gradual Ravage Health Poison IX",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [69] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["46150"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46150:0:0:0:0:0:0:0:0:0:0:0:0:0:0:19:0:0:0:0:0|h|h",
                                ["itemName"] = "Argentum",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46150] = 219,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:135125:123:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Gold Coast Spellcaster Elixir",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [28] = 25,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [59] = 25,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:95253:364:50:0:0:0:0:0:0:0:0:0:0:0:1:67:0:1:0:7798:0|h|h"] = 
                            {
                                ["itemName"] = "Selene's Arm Cops",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [3] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["45849"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45849:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Kaderi",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45849] = 101,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57805:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Enchanter Survey: Malabal Tor",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:57740:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Clothier Survey: Stonefalls",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [25] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:151930:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alliance Standard-Bearer's Emblem",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [38] = 12,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["75365"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:75365:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Alkahest",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [75365] = 5026,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:69802:369:50:26582:369:50:0:0:0:0:0:0:0:0:1:1:1:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Robe of Julianos",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [103] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["33253"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:33253:0:0:0:0:0:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h",
                                ["itemName"] = "Obsidian",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [33253] = 244,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:166200:364:50:0:0:0:0:0:0:0:0:0:0:0:1:14:0:1:0:500:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Perfected Lightning Staff",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [133] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["45856"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:45856:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Porade",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [45856] = 37,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57782:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Alchemist Survey: The Rift",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [15] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["46131"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:46131:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Kresh Fiber",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [46131] = 385,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:139434:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Jewelry Crafting Survey: Bangkorai",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [18] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:133639:364:50:54484:370:50:0:0:0:0:0:0:0:0:1:14:0:1:0:472:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Lightning Staff",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["30159"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30159:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Wormwood",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30159] = 602,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["30157"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:30157:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Blessed Thistle",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [30157] = 560,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["4447"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:4447:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Hide",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [4447] = 513,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["34323"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34323:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Corn",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34323] = 614,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:159472:124:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Style Page: Jephrine Paladin Helm",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [229] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:151616:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Northern Elsweyr Treasure Map IV",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [73] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["34333"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:34333:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Guarana",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [34333] = 684,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["166045"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:166045:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Indeko",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [166045] = 6,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:136988:363:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:5867:0|h|h"] = 
                            {
                                ["itemName"] = "Relequen's Guards",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [8] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["141820"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:141820:0:0:0:0:0:0:0:0:0:0:0:0:0:0:77:0:0:0:0:0|h|h",
                                ["itemName"] = "Bloodscent Dew",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [141820] = 20,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:45349:365:50:0:0:0:0:0:0:0:0:0:0:0:0:4:0:0:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Ancestor Silk Gloves",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [185] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:139018:6:1:0:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Artaeum Takeaway Broth",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [87] = 2,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["132167"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [89] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Praxis: Hagraven Cauldron, Ritual",
                                ["itemLink"] = "|H1:item:132167:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:123404:363:50:0:0:0:0:0:0:0:0:0:0:0:1:50:0:1:0:5443:0|h|h"] = 
                            {
                                ["itemName"] = "Coward's Gear Boots",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [9] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["167206"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:167206:0:0:0:0:0:0:0:0:0:0:0:0:0:0:109:0:0:0:0:0|h|h",
                                ["itemName"] = "Etched Molybdenum",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [167206] = 12,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:30145:308:50:0:0:0:0:0:0:0:0:0:0:0:0:36:1:0:0:0:724739|h|h"] = 
                            {
                                ["itemName"] = "Essence of Spell Power",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [91] = 45,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [44] = 7,
                                        },
                                    },
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [107] = 146,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["42872"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:42872:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Insect Parts, River Bait",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [42872] = 801,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["|H1:item:153739:4:1:0:0:0:18:255:3:353:22:0:0:0:0:0:0:0:0:0:275000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Jewelry Crafter Writ",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [127] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["184145"] = 
                            {
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [85] = 1,
                                        },
                                    },
                                },
                                ["itemName"] = "Praxis: Fargrave Facade, Huge",
                                ["itemLink"] = "|H1:item:184145:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["filterType"] = 3,
                            },
                            ["|H1:item:166303:363:50:0:0:0:0:0:0:0:0:0:0:0:1:14:0:1:0:400:0|h|h"] = 
                            {
                                ["itemName"] = "The Maelstrom's Perfected Restoration Staff",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [18] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 1,
                            },
                            ["|H1:item:119682:5:1:0:0:0:65:192:4:437:13:66:0:0:0:0:0:0:0:0:72000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Woodworking Writ",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [32] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:27037:307:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Essence of Magicka",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [31] = 4,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:27138:175:1:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Keep Wall Masonry Repair Kit",
                                ["itemQuality"] = 1,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [35] = 16,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["68190"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:68190:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Recipe: Millet and Beef Stuffed Peppers",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [181] = 5,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:142704:363:50:68343:370:50:0:0:0:0:0:0:0:0:1:81:0:1:0:9800:0|h|h"] = 
                            {
                                ["itemName"] = "Bright-Throat's Boast Jerkin",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["8796093057561649"] = 
                                    {
                                        ["bagID"] = 0,
                                        ["bagSlot"] = 
                                        {
                                            [2] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:137172:364:50:0:0:0:0:0:0:0:0:0:0:0:1:73:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Siroria's Jerkin",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [128] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["|H1:item:121528:6:1:0:0:0:68344:225:5:0:0:0:0:0:0:0:0:0:0:0:396000|h|h"] = 
                            {
                                ["itemName"] = "Sealed Enchanting Writ",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 6,
                                        ["bagSlot"] = 
                                        {
                                            [152] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["|H1:item:94696:363:50:0:0:0:0:0:0:0:0:0:0:0:1:67:0:1:0:10000:0|h|h"] = 
                            {
                                ["itemName"] = "Pirate Skeleton's Pauldrons",
                                ["itemQuality"] = 4,
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [151] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["54177"] = 
                            {
                                ["itemQuality"] = 5,
                                ["itemLink"] = "|H1:item:54177:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Dreugh Wax",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [54177] = 34,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:94477:364:50:0:0:0:0:0:0:0:0:0:0:0:1:67:0:1:0:2840:0|h|h"] = 
                            {
                                ["itemName"] = "Swarm Mother's Visage",
                                ["itemQuality"] = 5,
                                ["locations"] = 
                                {
                                    ["8796093060264765"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [94] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 2,
                            },
                            ["533"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:533:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Sanded Oak",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [533] = 1616,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["28603"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:28603:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Tomato",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [28603] = 586,
                                        },
                                    },
                                },
                                ["filterType"] = 4,
                            },
                            ["|H1:item:57819:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h"] = 
                            {
                                ["itemName"] = "Woodworker Survey: Greenshade",
                                ["itemQuality"] = 3,
                                ["locations"] = 
                                {
                                    ["8796093058809737"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [88] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["42869"] = 
                            {
                                ["itemQuality"] = 1,
                                ["itemLink"] = "|H1:item:42869:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Worms, Saltwater Bait",
                                ["locations"] = 
                                {
                                    ["CraftBag"] = 
                                    {
                                        ["bagID"] = 5,
                                        ["bagSlot"] = 
                                        {
                                            [42869] = 792,
                                        },
                                    },
                                },
                                ["filterType"] = 5,
                            },
                            ["44874"] = 
                            {
                                ["itemQuality"] = 2,
                                ["itemLink"] = "|H1:item:44874:121:1:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h",
                                ["itemName"] = "Petty Repair Kit",
                                ["locations"] = 
                                {
                                    ["8796093061464499"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [20] = 12,
                                        },
                                    },
                                    ["8796093057729085"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [17] = 30,
                                        },
                                    },
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [30] = 65,
                                        },
                                    },
                                    ["8796093059852051"] = 
                                    {
                                        ["bagID"] = 1,
                                        ["bagSlot"] = 
                                        {
                                            [32] = 62,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                            ["126844"] = 
                            {
                                ["itemQuality"] = 3,
                                ["itemLink"] = "|H1:item:126844:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["itemName"] = "Diagram: Daedric Pedestal, Ritual",
                                ["locations"] = 
                                {
                                    ["Bank"] = 
                                    {
                                        ["bagID"] = 2,
                                        ["bagSlot"] = 
                                        {
                                            [191] = 1,
                                        },
                                    },
                                },
                                ["filterType"] = 3,
                            },
                        },
                    },
                    ["TooltipFontFace"] = "EsoUI/Common/Fonts/Univers57.otf",
                    ["dontFocusSearch"] = false,
                    ["FCOISshowMarkerIcons"] = false,
                    ["fontList"] = 
                    {
                        [101038] = 
                        {
                            [1] = "Tooltip Default",
                            [2] = "Custom",
                            [3] = "CraftStoreFixedFont",
                            [4] = "CraftStoreFixedInsp",
                            [5] = "ZoFontAlert",
                            [6] = "ZoFontAnnounce",
                            [7] = "ZoFontAnnounceLarge",
                            [8] = "ZoFontAnnounceLargeNoShadow",
                            [9] = "ZoFontAnnounceMedium",
                            [10] = "ZoFontAnnounceMessage",
                            [11] = "ZoFontBookLetter",
                            [12] = "ZoFontBookLetterTitle",
                            [13] = "ZoFontBookMetal",
                            [14] = "ZoFontBookMetalTitle",
                            [15] = "ZoFontBookNote",
                            [16] = "ZoFontBookNoteTitle",
                            [17] = "ZoFontBookPaper",
                            [18] = "ZoFontBookPaperTitle",
                            [19] = "ZoFontBookRubbing",
                            [20] = "ZoFontBookRubbingTitle",
                            [21] = "ZoFontBookScroll",
                            [22] = "ZoFontBookScrollTitle",
                            [23] = "ZoFontBookSkin",
                            [24] = "ZoFontBookSkinTitle",
                            [25] = "ZoFontBookTablet",
                            [26] = "ZoFontBookTabletTitle",
                            [27] = "ZoFontCallout",
                            [28] = "ZoFontCallout2",
                            [29] = "ZoFontCallout3",
                            [30] = "ZoFontCenterScreenAnnounceLarge",
                            [31] = "ZoFontCenterScreenAnnounceSmall",
                            [32] = "ZoFontChat",
                            [33] = "ZoFontConversationName",
                            [34] = "ZoFontConversationOption",
                            [35] = "ZoFontConversationQuestReward",
                            [36] = "ZoFontConversationText",
                            [37] = "ZoFontCreditsHeader",
                            [38] = "ZoFontCreditsText",
                            [39] = "ZoFontDialogKeybindDescription",
                            [40] = "ZoFontEdit",
                            [41] = "ZoFontEdit20NoShadow",
                            [42] = "ZoFontEditChat",
                            [43] = "ZoFontGame",
                            [44] = "ZoFontGameBold",
                            [45] = "ZoFontGameLarge",
                            [46] = "ZoFontGameLargeBold",
                            [47] = "ZoFontGameLargeBoldShadow",
                            [48] = "ZoFontGameMedium",
                            [49] = "ZoFontGameOutline",
                            [50] = "ZoFontGamepad18",
                            [51] = "ZoFontGamepad20",
                            [52] = "ZoFontGamepad22",
                            [53] = "ZoFontGamepad25",
                            [54] = "ZoFontGamepad27",
                            [55] = "ZoFontGamepad27NoShadow",
                            [56] = "ZoFontGamepad34",
                            [57] = "ZoFontGamepad36",
                            [58] = "ZoFontGamepad36ThickOutline",
                            [59] = "ZoFontGamepad42",
                            [60] = "ZoFontGamepad42NoShadow",
                            [61] = "ZoFontGamepad54",
                            [62] = "ZoFontGamepad61",
                            [63] = "ZoFontGamepadBold18",
                            [64] = "ZoFontGamepadBold20",
                            [65] = "ZoFontGamepadBold22",
                            [66] = "ZoFontGamepadBold25",
                            [67] = "ZoFontGamepadBold27",
                            [68] = "ZoFontGamepadBold34",
                            [69] = "ZoFontGamepadBold48",
                            [70] = "ZoFontGamepadBold54",
                            [71] = "ZoFontGamepadBookLetter",
                            [72] = "ZoFontGamepadBookLetterTitle",
                            [73] = "ZoFontGamepadBookMetal",
                            [74] = "ZoFontGamepadBookMetalTitle",
                            [75] = "ZoFontGamepadBookNote",
                            [76] = "ZoFontGamepadBookNoteTitle",
                            [77] = "ZoFontGamepadBookPaper",
                            [78] = "ZoFontGamepadBookPaperTitle",
                            [79] = "ZoFontGamepadBookRubbing",
                            [80] = "ZoFontGamepadBookRubbingTitle",
                            [81] = "ZoFontGamepadBookScroll",
                            [82] = "ZoFontGamepadBookScrollTitle",
                            [83] = "ZoFontGamepadBookSkin",
                            [84] = "ZoFontGamepadBookSkinTitle",
                            [85] = "ZoFontGamepadBookTablet",
                            [86] = "ZoFontGamepadBookTabletTitle",
                            [87] = "ZoFontGamepadChat",
                            [88] = "ZoFontGamepadCondensed25",
                            [89] = "ZoFontGamepadCondensed27",
                            [90] = "ZoFontGamepadCondensed34",
                            [91] = "ZoFontGamepadCondensed36",
                            [92] = "ZoFontGamepadCondensed42",
                            [93] = "ZoFontGamepadCondensed54",
                            [94] = "ZoFontGamepadCondensed61",
                            [95] = "ZoFontGamepadEditChat",
                            [96] = "ZoFontGamepadHeaderDataValue",
                            [97] = "ZoFontGameShadow",
                            [98] = "ZoFontGameSmall",
                            [99] = "ZoFontHeader",
                            [100] = "ZoFontHeader2",
                            [101] = "ZoFontHeader3",
                            [102] = "ZoFontHeader4",
                            [103] = "ZoFontHeaderNoShadow",
                            [104] = "ZoFontKeybindStripDescription",
                            [105] = "ZoFontKeybindStripKey",
                            [106] = "ZoFontKeyboard18ThickOutline",
                            [107] = "ZoFontKeyboard24ThickOutline",
                            [108] = "ZoFontKeyboard28ThickOutline",
                            [109] = "ZoFontSubtitleText",
                            [110] = "ZoFontTooltipSubtitle",
                            [111] = "ZoFontTooltipTitle",
                            [112] = "ZoFontTributeAntique20",
                            [113] = "ZoFontTributeAntique20NoShadow",
                            [114] = "ZoFontTributeAntique30",
                            [115] = "ZoFontTributeAntique30NoShadow",
                            [116] = "ZoFontTributeAntique40",
                            [117] = "ZoFontTributeAntique52",
                            [118] = "ZoFontWindowSubtitle",
                            [119] = "ZoFontWindowTitle",
                            [120] = "ZoFontWinH1",
                            [121] = "ZoFontWinH2",
                            [122] = "ZoFontWinH3",
                            [123] = "ZoFontWinH3SoftShadowThin",
                            [124] = "ZoFontWinH4",
                            [125] = "ZoFontWinH5",
                            [126] = "ZoFontWinT1",
                            [127] = "ZoFontWinT2",
                            [128] = "ZoInteractionPrompt",
                            [129] = "ZoMarketAnnouncementCalloutFont",
                            [130] = "ZoMarketGamepadCalloutFont",
                        },
                    },
                    ["ignoredCharInventories"] = 
                    {
                    },
                    ["saveSettingsGlobally"] = true,
                    ["houseChestSpace"] = 
                    {
                    },
                    ["assets"] = 
                    {
                        ["8796093061464499"] = 
                        {
                            ["wv"] = 0,
                            ["tv"] = 0,
                            ["ap"] = 0,
                            ["spaceUsed"] = 31,
                            ["gold"] = 146574,
                            ["spaceMax"] = 121,
                        },
                        ["8796093057729085"] = 
                        {
                            ["wv"] = 0,
                            ["tv"] = 0,
                            ["ap"] = 0,
                            ["spaceUsed"] = 34,
                            ["gold"] = 141115,
                            ["spaceMax"] = 118,
                        },
                        ["8796093057561649"] = 
                        {
                            ["wv"] = 2,
                            ["tv"] = 135,
                            ["ap"] = 0,
                            ["spaceUsed"] = 44,
                            ["gold"] = 24494,
                            ["spaceMax"] = 200,
                        },
                        ["8796093058809737"] = 
                        {
                            ["wv"] = 0,
                            ["tv"] = 210,
                            ["ap"] = 0,
                            ["spaceUsed"] = 123,
                            ["gold"] = 133397,
                            ["spaceMax"] = 149,
                        },
                        ["8796093059852051"] = 
                        {
                            ["wv"] = 0,
                            ["tv"] = 0,
                            ["ap"] = 0,
                            ["spaceUsed"] = 27,
                            ["gold"] = 132282,
                            ["spaceMax"] = 110,
                        },
                        ["8796093060264765"] = 
                        {
                            ["wv"] = 124,
                            ["tv"] = 1100,
                            ["ap"] = 10650,
                            ["spaceUsed"] = 37,
                            ["gold"] = 305380,
                            ["spaceMax"] = 146,
                        },
                    },
                    ["version"] = 1,
                    ["BagSpaceAlert"] = 
                    {
                        ["threshold"] = 95,
                        ["b"] = 0,
                        ["g"] = 1,
                        ["r"] = 1,
                    },
                    ["bDebug"] = false,
                    ["TextColorsToon"] = "3399ff",
                    ["collectHouseData"] = 
                    {
                    },
                    ["TextColorsHouse"] = "3399ff",
                    ["bAddContextMenuEntrySearchInIIfA"] = true,
                    ["ShowToolTipWhen"] = "Always",
                    ["bFilterOnSetName"] = false,
                    ["showItemStats"] = false,
                    ["lastLang"] = "en",
                    ["TextColorsCraftBag"] = "3399ff",
                    ["BagSpaceFull"] = 
                    {
                        ["b"] = 0,
                        ["g"] = 0,
                        ["r"] = 255,
                    },
                    ["in2DefaultInventoryFrameView"] = "All",
                    ["TooltipFontEffect"] = "soft-shadow-thin",
                    ["TooltipFontSize"] = 18,
                    ["bInSeparateFrame"] = true,
                    ["TextColorsHouseChest"] = "3399ff",
                    ["bCollectGuildBankData"] = false,
                    ["hideCloseButton"] = false,
                    ["showItemCountOnRight"] = true,
                    ["ignoredCharEquipment"] = 
                    {
                    },
                    ["TextColorsBank"] = "3399ff",
                    ["showStyleInfo"] = true,
                    ["frameSettings"] = 
                    {
                        ["store"] = 
                        {
                            ["locked"] = false,
                            ["height"] = 798,
                            ["docked"] = true,
                            ["width"] = 380,
                            ["lastY"] = 300,
                            ["hidden"] = false,
                            ["lastX"] = 400,
                            ["minimized"] = false,
                        },
                        ["alchemy"] = 
                        {
                            ["locked"] = false,
                            ["height"] = 798,
                            ["docked"] = true,
                            ["width"] = 380,
                            ["lastY"] = 300,
                            ["hidden"] = false,
                            ["lastX"] = 400,
                            ["minimized"] = false,
                        },
                        ["guildBank"] = 
                        {
                            ["locked"] = false,
                            ["height"] = 798,
                            ["docked"] = true,
                            ["width"] = 380,
                            ["lastY"] = 300,
                            ["hidden"] = false,
                            ["lastX"] = 400,
                            ["minimized"] = false,
                        },
                        ["stables"] = 
                        {
                            ["locked"] = false,
                            ["height"] = 798,
                            ["docked"] = true,
                            ["width"] = 380,
                            ["lastY"] = 300,
                            ["hidden"] = false,
                            ["lastX"] = 400,
                            ["minimized"] = false,
                        },
                        ["smithing"] = 
                        {
                            ["locked"] = false,
                            ["height"] = 798,
                            ["docked"] = true,
                            ["width"] = 380,
                            ["lastY"] = 300,
                            ["hidden"] = false,
                            ["lastX"] = 400,
                            ["minimized"] = false,
                        },
                        ["inventory"] = 
                        {
                            ["locked"] = false,
                            ["height"] = 798,
                            ["docked"] = true,
                            ["width"] = 380,
                            ["lastY"] = 300,
                            ["hidden"] = true,
                            ["lastX"] = 400,
                            ["minimized"] = false,
                        },
                        ["hud"] = 
                        {
                            ["locked"] = false,
                            ["height"] = 798,
                            ["docked"] = false,
                            ["width"] = 380,
                            ["lastY"] = 300,
                            ["hidden"] = true,
                            ["lastX"] = 400,
                            ["minimized"] = false,
                        },
                        ["trade"] = 
                        {
                            ["locked"] = false,
                            ["height"] = 798,
                            ["docked"] = true,
                            ["width"] = 380,
                            ["lastY"] = 300,
                            ["hidden"] = false,
                            ["lastX"] = 400,
                            ["minimized"] = false,
                        },
                        ["bank"] = 
                        {
                            ["locked"] = false,
                            ["height"] = 798,
                            ["docked"] = true,
                            ["width"] = 380,
                            ["lastY"] = 300,
                            ["hidden"] = true,
                            ["lastX"] = 400,
                            ["minimized"] = false,
                        },
                        ["tradinghouse"] = 
                        {
                            ["locked"] = false,
                            ["height"] = 798,
                            ["docked"] = true,
                            ["width"] = 380,
                            ["lastY"] = 300,
                            ["hidden"] = false,
                            ["lastX"] = 400,
                            ["minimized"] = false,
                        },
                    },
                    ["BagSpaceWarn"] = 
                    {
                        ["threshold"] = 85,
                        ["b"] = 0,
                        ["g"] = 0.5098039216,
                        ["r"] = 0.9019607843,
                    },
                    ["showToolTipWhen"] = "Always",
                    ["TextColorsGBank"] = "3399ff",
                    ["b_collectHouses"] = false,
                    ["in2TooltipsFont"] = "ZoFontGame",
                    ["bFilterOnSetNameToo"] = false,
                    ["NA-guildBanks"] = 
                    {
                        ["Fellow Travelers Alliance"] = 
                        {
                            ["items"] = 0,
                            ["bCollectData"] = false,
                            ["lastCollected"] = "",
                        },
                        ["Whispering Fang Syndicate"] = 
                        {
                            ["items"] = 0,
                            ["bCollectData"] = false,
                            ["lastCollected"] = "",
                        },
                    },
                },
            },
        },
    },
}
