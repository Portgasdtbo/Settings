BUI_VARS =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["PlayerBuffs"] = true,
                ["SynergyCdSize"] = 44,
                ["RaidWidth"] = 220,
                ["ReticleMode"] = 1,
                ["ReticleDpS"] = false,
                ["ProcAnimation"] = true,
                ["FrameStaminaColor"] = 
                {
                    [4] = 1,
                    [1] = 0,
                    [2] = 0.5490196078,
                    [3] = 0.1176470588,
                },
                ["BUI_TargetFrame"] = 
                {
                    [4] = 200,
                    [1] = 3,
                    [2] = 128,
                    [3] = 250,
                },
                ["DecimalValues"] = true,
                ["MinimumDuration"] = 3,
                ["ZoomGlobal"] = 3,
                ["BlockAnnouncement"] = false,
                ["FastTravel"] = false,
                ["ReportScale"] = 1,
                ["RaidHeight"] = 32,
                ["ZoomSubZone"] = 30,
                ["RaidLevels"] = true,
                ["RaidSplit"] = 0,
                ["BossFrame"] = true,
                ["BuiltInGlobalCooldown"] = false,
                ["RaidFrames"] = true,
                ["LastVersion"] = 4.3350000000,
                ["FrameStaminaColor1"] = 
                {
                    [4] = 1,
                    [1] = 0,
                    [2] = 0.8235294118,
                    [3] = 0.0784313725,
                },
                ["CustomBuffsPSide"] = "right",
                ["CastbyPlayer"] = true,
                ["FramePercents"] = false,
                ["StatsMiniSpeed"] = false,
                ["AdvancedSynergy"] = false,
                ["StatsFontSize"] = 18,
                ["QuickSlots"] = true,
                ["BuffsPassives"] = "On additional panel",
                ["BUI_BuffsP"] = 
                {
                    [4] = 345,
                    [1] = 128,
                    [2] = 128,
                    [3] = 0,
                },
                ["PlayerBuffsAlign"] = 128,
                ["MiniMap"] = true,
                ["CustomEdgeColor"] = 
                {
                    [4] = 1,
                    [1] = 0,
                    [2] = 0.0700000000,
                    [3] = 0.0700000000,
                },
                ["ConfirmLocked"] = false,
                ["ZoomZone"] = 60,
                ["TargetBuffSize"] = 44,
                ["SelfColor"] = true,
                ["TargetFrame"] = false,
                ["QuickSlotsShow"] = 4,
                ["InitialDialog"] = false,
                ["RaidSort"] = 1,
                ["EnableSynergyCd"] = false,
                ["FrameHealthColor1"] = 
                {
                    [4] = 1,
                    [1] = 1,
                    [2] = 0.1568627451,
                    [3] = 0.2745098039,
                },
                ["ZoomImperialCity"] = 80,
                ["WidgetSound2"] = "CrownCrates_Manifest_Selected",
                ["Widgets"] = 
                {
                    [61919] = true,
                    ["Major Courage"] = true,
                    ["Major Resolve"] = true,
                    [110067] = true,
                    ["Major Brutality"] = true,
                    [107141] = true,
                    [110118] = true,
                    [46327] = true,
                    [61927] = true,
                    ["Major Sorcery"] = true,
                    [104538] = true,
                    ["Immovable"] = true,
                    [109084] = true,
                    [126941] = true,
                    [110142] = true,
                    [110143] = true,
                },
                ["FramesFade"] = false,
                ["MarkerLeader"] = false,
                ["Theme"] = 2,
                ["NotificationsGroup"] = true,
                ["StatsShareDPS"] = true,
                ["CustomBuffsPWidth"] = 120,
                ["CustomBuffSize"] = 44,
                ["ZoomMountRatio"] = 70,
                ["EnableXPBar"] = true,
                ["FrameHorisontal"] = true,
                ["EnableCustomBuffs"] = false,
                ["ActionsFontSize"] = 16,
                ["CustomBar"] = 
                {
                    ["Enable"] = false,
                    ["Leader"] = 
                    {
                        [1] = false,
                        [2] = false,
                        [3] = false,
                        [4] = false,
                        [5] = false,
                        [6] = false,
                    },
                    ["Slash"] = 
                    {
                        [1] = 
                        {
                            ["command"] = "/reloadui",
                            ["icon"] = "/esoui/art/mounts/ridingskill_ready.dds",
                            ["enable"] = true,
                        },
                        [2] = 
                        {
                            ["command"] = "/script StartChatInput('/z Guild [name] recruits new members!')",
                            ["icon"] = "/esoui/art/icons/ability_warrior_010.dds",
                            ["enable"] = false,
                        },
                        [3] = 
                        {
                            ["command"] = "/dancedunmer",
                            ["icon"] = "/esoui/art/icons/ability_mage_066.dds",
                            ["enable"] = false,
                        },
                        [4] = 
                        {
                            ["command"] = "/script ZO_CompassFrame:SetHidden(not ZO_CompassFrame:IsHidden())",
                            ["icon"] = "/esoui/art/icons/ability_rogue_062.dds",
                            ["enable"] = true,
                        },
                        [5] = 
                        {
                            ["command"] = "/mimewall",
                            ["icon"] = "/esoui/art/icons/emote_mimewall.dds",
                            ["enable"] = false,
                        },
                        [6] = 
                        {
                            ["command"] = "/script UseCollectible(336)",
                            ["icon"] = "/esoui/art/icons/quest_gemstone_tear_0002.dds",
                            ["enable"] = true,
                        },
                        [7] = 
                        {
                            ["command"] = "/jumptoleader",
                            ["icon"] = "/esoui/art/tutorial/gamepad/gp_playermenu_icon_store.dds",
                            ["enable"] = false,
                        },
                        [8] = 
                        {
                            ["command"] = "/script zo_callLater(function() local name=GetUnitDisplayName('reticleover') if name then StartChatInput('/w '..name..' ') else a('No target') end end,100)",
                            ["icon"] = "esoui/art/tutorial/chat-notifications_up.dds",
                            ["enable"] = false,
                        },
                        [9] = 
                        {
                            ["command"] = "/script d(AreAnyItemsStolen(BAG_BACKPACK) and 'Have stolen items' or 'Have no stolen items')",
                            ["icon"] = "/esoui/art/inventory/gamepad/gp_inventory_icon_stolenitem.dds",
                            ["enable"] = false,
                        },
                        [10] = 
                        {
                            ["command"] = "/script local _,i=GetAbilityProgressionXPInfoFromAbilityId(40232) local _,m,r=GetAbilityProgressionInfo(i) local _,_,index=GetAbilityProgressionAbilityInfo(i,m,r) CallSecureProtected('SelectSlotAbility', index, 3)",
                            ["icon"] = "/esoui/art/icons/ability_ava_005_a.dds",
                            ["enable"] = false,
                        },
                        [11] = 
                        {
                            ["command"] = "/script BUI.Vars.EnableWidgets=not BUI.Vars.EnableWidgets BUI.Frames.Widgets_Init() d('Widgets are now '..(BUI.Vars.EnableWidgets and '|c33EE33enabled|r' or '|EE3333disabled|r'))",
                            ["icon"] = "/esoui/art/progression/morph_up.dds",
                            ["enable"] = false,
                        },
                        [12] = 
                        {
                            ["command"] = "/script local text='Another sample'd(text) a(text)",
                            ["icon"] = "Text",
                            ["enable"] = false,
                        },
                    },
                },
                ["RepeatableQuests"] = false,
                ["TargetHeight"] = 22,
                ["SmallGroupScale"] = 120,
                ["ContainerHandler"] = false,
                ["BUI_Minimap"] = 
                {
                    [4] = -585,
                    [1] = 128,
                    [2] = 128,
                    [3] = 1133,
                },
                ["FramesTexture"] = "rounded",
                ["version"] = 3,
                ["QuickSlotsInventory"] = true,
                ["CurvedDepth"] = 0.8000000000,
                ["ShowDots"] = false,
                ["TargetWidth"] = 280,
                ["DefaultPlayerFrames"] = false,
                ["CurvedFrame"] = 0,
                ["MiniMapTitle"] = true,
                ["InCombatReticle"] = true,
                ["StatShareUlt"] = 3,
                ["MiniMapDimensions"] = 250,
                ["PlayerFrame"] = true,
                ["NotificationSound_1"] = "Champion_PointsCommitted",
                ["Actions"] = false,
                ["StatsMiniGroupDps"] = true,
                ["ZO_PlayerAttributeStamina"] = 
                {
                    [4] = 592,
                    [1] = 2,
                    [2] = 128,
                    [3] = 1,
                },
                ["StatsMiniMeter"] = true,
                ["UseSwapPanel"] = true,
                ["DefaultTargetFrame"] = true,
                ["BUI_PlayerFrame"] = 
                {
                    [4] = 200,
                    [1] = 9,
                    [2] = 128,
                    [3] = -250,
                },
                ["GroupDeathSound"] = "Lockpicking_unlocked",
                ["CurvedStatValues"] = true,
                ["JumpToLeader"] = false,
                ["CollapseNormalDungeon"] = false,
                ["PassiveProgress"] = false,
                ["StatShare"] = true,
                ["SynergyCdPSide"] = "right",
                ["FrameShieldColor"] = 
                {
                    [4] = 1,
                    [1] = 0.9803921569,
                    [2] = 0.3921568627,
                    [3] = 0.0784313725,
                },
                ["TauntTimer"] = 1,
                ["DeleteMail"] = false,
                ["ReticleResist"] = 3,
                ["HousePins"] = 4,
                ["CurvedHeight"] = 360,
                ["FrameShowMax"] = false,
                ["SynergyCdDirection"] = "vertical",
                ["FrameShieldColor1"] = 
                {
                    [4] = 1,
                    [1] = 0.9019607843,
                    [2] = 0.3921568627,
                    [3] = 0.0784313725,
                },
                ["ZoomCyrodiil"] = 45,
                ["ColorRoles"] = true,
                ["PlayerBuffSize"] = 44,
                ["PinScale"] = 75,
                ["PvPmode"] = true,
                ["ImpactAnimation"] = true,
                ["ExpiresAnimation"] = true,
                ["StatsSplitElements"] = true,
                ["FrameFontSize"] = 15,
                ["Log"] = false,
                ["DeveloperMode"] = false,
                ["Glyphs"] = true,
                ["DodgeFatigue"] = false,
                ["PlayerToPlayer"] = false,
                ["SidePanel"] = 
                {
                    ["Trader"] = true,
                    ["VeteranDifficulty"] = true,
                    ["Armorer"] = true,
                    ["Teleporter"] = true,
                    ["SubSampling"] = true,
                    ["Minimap"] = true,
                    ["LeaderArrow"] = true,
                    ["AllowOther"] = true,
                    ["WPamA"] = true,
                    ["Smuggler"] = true,
                    ["Settings"] = true,
                    ["Compass"] = true,
                    ["Statistics"] = true,
                    ["Ragpicker"] = true,
                    ["Share"] = true,
                    ["Banker"] = true,
                    ["LFG_Role"] = true,
                    ["Enable"] = true,
                    ["HealerHelper"] = true,
                    ["Widgets"] = true,
                    ["DismissPets"] = true,
                    ["GearManager"] = true,
                },
                ["LargeRaidScale"] = 80,
                ["ExecuteThreshold"] = 40,
                ["BUI_BuffsC"] = 
                {
                    [4] = 300,
                    [1] = 128,
                    [2] = 128,
                    [3] = 0,
                },
                ["FrameHealthColor"] = 
                {
                    [4] = 1,
                    [1] = 0.5882352941,
                    [2] = 0.1176470588,
                    [3] = 0.2352941176,
                },
                ["FrameNameFormat"] = 2,
                ["PassiveBuffSize"] = 36,
                ["GroupSynergy"] = 3,
                ["WidgetPotion"] = true,
                ["FrameHealerColor"] = 
                {
                    [1] = 1,
                    [2] = 0.7568627451,
                    [3] = 0.4980392157,
                },
                ["FrameOpacityOut"] = 80,
                ["NotificationFood"] = true,
                ["EnableBlackList"] = true,
                ["RepositionFrames"] = true,
                ["GroupSynergyCount"] = 2,
                ["FrameWidth"] = 280,
                ["Meter_Power"] = false,
                ["RaidColumnSize"] = 6,
                ["DefaultTargetFrameText"] = true,
                ["PreferredTarget"] = true,
                ["BUI_BuffsT"] = 
                {
                    [4] = -350,
                    [1] = 128,
                    [2] = 128,
                    [3] = 0,
                },
                ["BUI_BossFrame"] = 
                {
                    [4] = -545,
                    [1] = 128,
                    [2] = 128,
                    [3] = 0,
                },
                ["NotificationSound_2"] = "No_Sound",
                ["CustomBuffsProgress"] = true,
                ["CustomBuffs"] = 
                {
                },
                ["BUI_GroupDPS"] = 
                {
                    [4] = 120,
                    [1] = 3,
                    [2] = 1,
                    [3] = -400,
                },
                ["CastBar"] = 3,
                ["PassivePSide"] = "left",
                ["NotificationsSize"] = 32,
                ["FoodBuff"] = true,
                ["BossWidth"] = 280,
                ["WidgetSound1"] = "CrownCrates_Manifest_Chosen",
                ["Meter_Crit"] = false,
                ["FrameFont2"] = "esobold",
                ["ProcSound"] = "Ability_Ultimate_Ready_Sound",
                ["EnableStats"] = true,
                ["CustomBuffsDirection"] = "vertical",
                ["AttackersWidth"] = 280,
                ["Reports"] = 
                {
                },
                ["Meter_Exp"] = false,
                ["StatsUpdateDPS"] = false,
                ["CurvedHitAnimation"] = true,
                ["EnableWidgets"] = false,
                ["StatsGroupDPS"] = false,
                ["FrameOpacityIn"] = 90,
                ["Meter_DPS"] = false,
                ["StatsMiniHealing"] = false,
                ["UndauntedPledges"] = false,
                ["PinColor"] = 
                {
                    [40] = 
                    {
                        [4] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                    },
                    [1] = 
                    {
                        [4] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                    },
                    [2] = 
                    {
                        [4] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 0,
                    },
                    [204] = 
                    {
                        [4] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                    },
                    [12] = 
                    {
                        [4] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                    },
                },
                ["GroupLeave"] = false,
                ["FrameMagickaColor"] = 
                {
                    [4] = 1,
                    [1] = 0,
                    [2] = 0.1176470588,
                    [3] = 0.8627450980,
                },
                ["ReticleInvul"] = false,
                ["FriendStatus"] = false,
                ["SynergyCdPWidth"] = 120,
                ["BUI_OnScreenS"] = 
                {
                    [4] = -210,
                    [1] = 128,
                    [2] = 128,
                    [3] = 360,
                },
                ["StatsTransparent"] = false,
                ["NotificationsWorld"] = true,
                ["LargeGroupAnnoucement"] = true,
                ["StatsGroupDPSframe"] = false,
                ["BuffsImportant"] = true,
                ["ExecuteSound"] = true,
                ["ActionsPrecise"] = false,
                ["MiniMeterAplha"] = 0.8000000000,
                ["FrameDamageColor"] = 
                {
                    [1] = 0.8784313725,
                    [2] = 0.1098039216,
                    [3] = 0.1098039216,
                },
                ["OnScreenPriorDeath"] = true,
                ["PassivePWidth"] = 100,
                ["BuffsBlackList"] = 
                {
                    [63601] = true,
                    [14890] = true,
                    [76667] = true,
                },
                ["EnableNameplate"] = true,
                ["GroupAnimation"] = true,
                ["UltimateOrder"] = 2,
                ["StatsBuffs"] = true,
                ["NotificationsTimer"] = 3000,
                ["GroupElection"] = true,
                ["ZoomDungeon"] = 60,
                ["GroupBuffs"] = false,
                ["ZO_PlayerAttributeMagicka"] = 
                {
                    [4] = 592,
                    [1] = 8,
                    [2] = 128,
                    [3] = 0,
                },
                ["AdvancedThemeColor"] = 
                {
                    [4] = 0.9000000000,
                    [1] = 0.5000000000,
                    [2] = 0.6000000000,
                    [3] = 1,
                },
                ["CurvedDistance"] = 220,
                ["Champion"] = 
                {
                    [1] = 
                    {
                    },
                    [2] = 
                    {
                    },
                    [3] = 
                    {
                    },
                },
                ["BUI_BuffsPas"] = 
                {
                    [4] = 409.5000000000,
                    [1] = 128,
                    [2] = 128,
                    [3] = 1261,
                },
                ["FrameTankColor"] = 
                {
                    [1] = 0.8588235294,
                    [2] = 0.5607843137,
                    [3] = 1,
                },
                ["FramesBorder"] = 1,
                ["RaidFontSize"] = 17,
                ["Books"] = false,
                ["WidgetsSize"] = 44,
                ["NotificationsTrial"] = true,
                ["BUI_RaidFrame"] = 
                {
                    [4] = 160,
                    [1] = 3,
                    [2] = 3,
                    [3] = 50,
                },
                ["PassiveOakFilter"] = true,
                ["LeaderArrow"] = false,
                ["CurvedOffset"] = -100,
                ["Meter_Speed"] = false,
                ["BuffsOtherHide"] = true,
                ["BUI_BuffsS"] = 
                {
                    [4] = 200,
                    [1] = 128,
                    [2] = 128,
                    [3] = -300,
                },
                ["FrameMagickaColor1"] = 
                {
                    [4] = 1,
                    [1] = 0,
                    [2] = 0.4784313725,
                    [3] = 1,
                },
                ["StatTriggerHeals"] = false,
                ["DarkBrotherhoodSpree"] = false,
                ["BUI_MiniMeter"] = 
                {
                    [4] = 626,
                    [1] = 128,
                    [2] = 128,
                    [3] = 2.5000000000,
                },
                ["AutoQueue"] = false,
                ["FrameFont1"] = "esobold",
                ["StatusIcons"] = true,
                ["ZoomImperialsewer"] = 60,
                ["BUI_OnScreen"] = 
                {
                    [4] = -110,
                    [1] = 128,
                    [2] = 128,
                    [3] = 0,
                },
                ["SynergyCdProgress"] = true,
                ["TargetBuffsAlign"] = 128,
                ["HideSwapPanel"] = true,
                ["EffectVisualisation"] = true,
                ["WidgetsPWidth"] = 120,
                ["TargetBuffs"] = true,
                ["ZO_FocusedQuestTrackerPanel"] = 
                {
                    [4] = -449,
                    [1] = 128,
                    [2] = 128,
                    [3] = 1124.5000000000,
                },
                ["FrameHeight"] = 22,
                ["AttackersHeight"] = 28,
                ["BUI_HPlayerFrame"] = 
                {
                    [4] = 410,
                    [1] = 128,
                    [2] = 128,
                    [3] = 0,
                },
                ["BossHeight"] = 28,
                ["MarkerSize"] = 40,
                ["LargeGroupInvite"] = true,
            },
        },
    },
}
BUI_REPORTS =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["data"] = 
                {
                },
                ["version"] = 1,
            },
        },
    },
}
