MP_SavedVars =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["Bujin Yamato"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = false,
                [5] = true,
                [6] = false,
                [7] = true,
                [8] = true,
                [9] = false,
                [10] = false,
                [11] = false,
                [12] = false,
                [13] = false,
                [14] = false,
                [15] = false,
                [16] = false,
                [17] = false,
                [18] = false,
                [19] = false,
                [21] = true,
                ["TimeBreachClosed"] = 
                {
                },
                ["version"] = 2,
            },
            ["Sorc deez Frags"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = false,
                [5] = true,
                [6] = false,
                [7] = true,
                [8] = true,
                [9] = false,
                [10] = false,
                [11] = false,
                [12] = false,
                [13] = false,
                [14] = false,
                [15] = false,
                [16] = false,
                [17] = false,
                [18] = false,
                [19] = false,
                [21] = true,
                ["TimeBreachClosed"] = 
                {
                },
                ["version"] = 2,
            },
            ["His Swoliness"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = false,
                [5] = true,
                [6] = false,
                [7] = true,
                [8] = true,
                [9] = false,
                [10] = false,
                [11] = false,
                [12] = false,
                [13] = false,
                [14] = false,
                [15] = false,
                [16] = false,
                [17] = false,
                [18] = false,
                [19] = false,
                [21] = true,
                ["TimeBreachClosed"] = 
                {
                },
                ["version"] = 2,
            },
            ["Sweepy Mcsweeperson"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = false,
                [5] = true,
                [6] = false,
                [7] = true,
                [8] = true,
                [9] = false,
                [10] = false,
                [11] = false,
                [12] = false,
                [13] = false,
                [14] = false,
                [15] = false,
                [16] = false,
                [17] = false,
                [18] = false,
                [19] = false,
                [21] = true,
                ["TimeBreachClosed"] = 
                {
                },
                ["version"] = 2,
            },
            ["Big depression"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = false,
                [5] = true,
                [6] = false,
                [7] = true,
                [8] = true,
                [9] = false,
                [10] = false,
                [11] = false,
                [12] = false,
                [13] = false,
                [14] = false,
                [15] = false,
                [16] = false,
                [17] = false,
                [18] = false,
                [19] = false,
                [21] = true,
                ["TimeBreachClosed"] = 
                {
                },
                ["version"] = 2,
            },
            ["Sneaky lil Snake"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = false,
                [5] = true,
                [6] = false,
                [7] = true,
                [8] = true,
                [9] = false,
                [10] = false,
                [11] = false,
                [12] = false,
                [13] = false,
                [14] = false,
                [15] = false,
                [16] = false,
                [17] = false,
                [18] = false,
                [19] = false,
                [21] = true,
                ["TimeBreachClosed"] = 
                {
                },
                ["version"] = 2,
            },
        },
    },
}
MP_SavedGlobal =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["pinsize"] = 20,
                ["version"] = 1,
            },
        },
    },
}
MP_ChestData =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 2,
            },
        },
    },
}
MP_ThievesTrove =
{
    ["Default"] = 
    {
        ["@portgasdtbo"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 2,
            },
        },
    },
}
