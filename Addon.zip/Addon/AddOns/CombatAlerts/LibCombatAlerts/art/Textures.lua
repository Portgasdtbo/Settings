LibCombatAlertsInternal.Textures = {
	["arrow-ccw"] = "Arrows/ccw.dds",
	["arrow-cw"] = "Arrows/cw.dds",
	["screenborder-center"] = "ScreenBorder/center.dds",
	["screenborder-edge"] = "ScreenBorder/edge.dds",
}
