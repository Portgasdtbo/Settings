# DolgubonsLazyWritCreator
Optional, because let's face it, you're not going to read this

Dolgubon's Lazy Writ Crafter is an addon for the Elder Scrolls Online (ESO). 
The main purpose is to automate Crafting Writs, which are a daily quest in ESO.
A secondary purpose is to automate Master Writs, which are a repeatable (but non daily) quest
which requires more advanced items to be crafted.

The addon fully supports smithing (Blacksmithing, CLothing, and Woodworking) and Enchanting writs.
Alchemy and Provisioning are not fully supported, however the addon will withdraw items required for
those writs from the player's bank.

Other time saving features are:
 - Automatically going through quest dialog
 - Automatic exiting of the crafting interface when crafting is complete
 - Automatic looting of the writ rewards