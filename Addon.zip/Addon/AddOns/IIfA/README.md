# InventoryInsight

This is the git repository for the eso addon [InventoryInsight](http://www.esoui.com/downloads/info731-InventoryInsight.html "IIfA on esoui.com")
