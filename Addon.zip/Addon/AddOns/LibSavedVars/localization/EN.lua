LIBSAVEDVARS_STRINGS = {
    ["SI_LSV_ACCOUNT_WIDE"]    = "Account-wide Settings",
    ["SI_LSV_ACCOUNT_WIDE_TT"] = "All the settings below will be the same for each of your characters.",
}